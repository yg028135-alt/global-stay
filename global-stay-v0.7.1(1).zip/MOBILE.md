# تحويل Global Stay إلى تطبيق موبايل (APK / Android / iPhone)

> كل الطرق تحتاج أن يكون الموقع **منشورًا على رابط HTTPS** أولًا (انظر `DEPLOY.md`).
> المشروع جاهز كـ PWA (manifest + service worker + أيقونات + Web Push)، فلا حاجة لإعادة كتابة أي شيء.

## 0) بدون APK (دقيقتان) — الأسهل
- **Android (Chrome):** افتحي الرابط ← ⋮ ← «تثبيت التطبيق». يظهر بأيقونة وبملء الشاشة ويستقبل الإشعارات.
- **iPhone (Safari):** زر المشاركة ← «إضافة إلى الشاشة الرئيسية» (الإشعارات تعمل على iOS 16.4+ بعد التثبيت فقط).

## 1) ملف APK/AAB عبر PWABuilder (بدون كود) — موصى به
1. افتحي https://www.pwabuilder.com وأدخلي رابط موقعك.
2. اضغطي **Package for stores ← Android** (يُنشئ تطبيق TWA يفتح موقعك بملء الشاشة).
3. نزّلي الملف المضغوط: فيه `app.apk` للتجربة و`app.aab` لمتجر Google Play، وملف `signing.keystore` **احتفظي به دائمًا** (بدونه لا تستطيعين تحديث التطبيق).
4. خذي بصمة `SHA-256` من الملف المرافق وضعيها في `public/.well-known/assetlinks.json` بالشكل:
```json
[{"relation":["delegate_permission/common.handle_all_urls"],
  "target":{"namespace":"android_app","package_name":"<اسم الحزمة>","sha256_cert_fingerprints":["<البصمة>"]}}]
```
5. أعيدي نشر الموقع، ثم ثبّتي `app.apk` على الجوال (فعّلي «تثبيت من مصادر غير معروفة»).
   بدون هذا الملف يظهر شريط عنوان المتصفح أعلى التطبيق.
6. لنشره على Google Play: حساب مطوّر (25$ مرة واحدة) ثم ارفعي `app.aab`.

## 2) بديل: Bubblewrap (سطر أوامر)
```
npx @bubblewrap/cli init --manifest https://دومينك/manifest.webmanifest
npx @bubblewrap/cli build        # يُخرج app-release-signed.apk و .aab
```
يحمّل JDK وAndroid SDK تلقائيًا عند أول تشغيل.

## 3) Capacitor (فقط إن احتجتِ وصولًا عميقًا لإمكانيات الجهاز)
```
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init GlobalStay com.globalstay.app --web-dir=public
# في capacitor.config: server: { url: "https://دومينك" }
npx cap add android && npx cap open android   # ثم Build APK من Android Studio
```
تنبيه: Web Push لا يعمل داخل WebView، وتحتاجين Firebase (FCM) للإشعارات — لذلك **الطريقة 1 أفضل لهذا المشروع**.

## أي طريقة أختار؟
| الحاجة | الأنسب |
|---|---|
| تجربة سريعة على جوالك | 0 (تثبيت من Chrome) |
| ملف APK لتوزيعه على الموظفين | 1 (PWABuilder) |
| النشر على Google Play | 1 أو 2 (AAB) |
| iPhone | 0 (إضافة للشاشة الرئيسية)؛ App Store يحتاج Mac وحساب 99$/سنة |
