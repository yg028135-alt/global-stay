import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createECDH, randomBytes, hkdfSync, createDecipheriv, createPublicKey, verify } from 'node:crypto';
import { addBusinessMs, businessMsBetween, zonedToUtc, defaultBusiness } from '../server/biz.mjs';
import { encryptPayload, vapidHeader, makeVapid, validEndpoint } from '../server/push.mjs';

const M = 60000, H = 60 * M;
const cfg = { ...defaultBusiness(), enabled: true, tz: 'Africa/Cairo', start: '08:00', end: '22:00', days: [0, 1, 2, 3, 4, 5, 6] };
const at = (y, m, d, h, mi = 0) => zonedToUtc(y, m, d, h, mi, 'Africa/Cairo');

test('وقت داخل ساعات العمل: لا تغيير', () => {
  assert.equal(addBusinessMs(at(2026, 11, 20, 10), 2 * H, cfg), at(2026, 11, 20, 12));
});
test('يمتد إلى صباح اليوم التالي عند تجاوز نهاية الدوام', () => {
  // 21:00 + 3 ساعات: ساعة واحدة اليوم ثم ساعتان من 08:00 → 10:00
  assert.equal(addBusinessMs(at(2026, 11, 20, 21), 3 * H, cfg), at(2026, 11, 21, 10));
});
test('البدء خارج الدوام يُحسب من فتح الدوام', () => {
  assert.equal(addBusinessMs(at(2026, 11, 20, 3), 1 * H, cfg), at(2026, 11, 20, 9));
});
test('يتخطى الأيام غير العاملة', () => {
  const noFri = { ...cfg, days: [0, 1, 2, 3, 4, 6] }; // بدون الجمعة (5)
  // 2026-11-20 جمعة → أول يوم عمل السبت 21
  assert.equal(addBusinessMs(at(2026, 11, 20, 10), 1 * H, noFri), at(2026, 11, 21, 9));
});
test('معطّل = دقائق متصلة', () => {
  assert.equal(addBusinessMs(1000, 5 * M, { ...cfg, enabled: false }), 1000 + 5 * M);
});
test('businessMsBetween تتجاهل وقت الإغلاق', () => {
  assert.equal(businessMsBetween(at(2026, 11, 20, 21), at(2026, 11, 21, 9), cfg), 2 * H);
});

test('Web Push: تشفير aes128gcm يُفكّ عند المستلم (RFC 8291)', () => {
  const ua = createECDH('prime256v1'); ua.generateKeys(); const auth = randomBytes(16);
  const body = encryptPayload(JSON.stringify({ body: 'مرحبا ✓' }), ua.getPublicKey().toString('base64url'), auth.toString('base64url'));
  const salt = body.subarray(0, 16), idlen = body[20], asPub = body.subarray(21, 21 + idlen), ct = body.subarray(21 + idlen);
  const secret = ua.computeSecret(asPub);
  const ikm = Buffer.from(hkdfSync('sha256', secret, auth, Buffer.concat([Buffer.from('WebPush: info\0'), ua.getPublicKey(), asPub]), 32));
  const cek = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16));
  const nonce = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12));
  const d = createDecipheriv('aes-128-gcm', cek, nonce); d.setAuthTag(ct.subarray(-16));
  const plain = Buffer.concat([d.update(ct.subarray(0, -16)), d.final()]);
  assert.equal(plain.at(-1), 2);
  assert.equal(JSON.parse(plain.subarray(0, -1).toString()).body, 'مرحبا ✓');
});
test('VAPID: التوقيع ES256 صالح بالمفتاح العام', () => {
  const store = {}; const vapid = makeVapid((k, d) => store[k] ?? d, (k, v) => { store[k] = v; });
  const h = vapidHeader('https://push.example.com/abc', vapid, 'mailto:a@b.c');
  const [, jwt, pub] = /t=([^,]+), k=(.+)$/.exec(h);
  const [head, claims, sig] = jwt.split('.');
  const raw = Buffer.from(pub, 'base64url');
  const key = createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: raw.subarray(1, 33).toString('base64url'), y: raw.subarray(33).toString('base64url') }, format: 'jwk' });
  assert.ok(verify('sha256', Buffer.from(`${head}.${claims}`), { key, dsaEncoding: 'ieee-p1363' }, Buffer.from(sig, 'base64url')));
  assert.equal(JSON.parse(Buffer.from(claims, 'base64url')).aud, 'https://push.example.com');
});

test('Push: نقاط النهاية غير الآمنة مرفوضة (SSRF)', () => {
  assert.ok(validEndpoint('https://fcm.googleapis.com/fcm/send/abc'));
  for (const bad of ['http://fcm.googleapis.com/x', 'https://localhost/x', 'https://127.0.0.1/x', 'https://10.0.0.5/x', 'https://192.168.1.2/x', 'https://169.254.169.254/latest', 'ftp://x.com/y', 'not a url']) assert.equal(validEndpoint(bad), false, bad);
  assert.equal(validEndpoint('http://127.0.0.1:9/x'), false);           // مرفوض افتراضيًا
  assert.ok(validEndpoint('http://127.0.0.1:9/x', true));                // مسموح للاختبار فقط
});
