// حساب مهلة SLA بساعات العمل (بتوقيت منطقة الفندق). عند التعطيل يتصرف كدقائق متصلة.
const M = 60000;
const fmts = new Map();
const fmt = (tz) => { let f = fmts.get(tz); if (!f) { f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' }); fmts.set(tz, f); } return f; };
export const validTz = (tz) => { try { fmt(tz); return typeof tz === 'string' && tz.length < 60; } catch { return false; } };
export function localParts(ms, tz) { const p = Object.fromEntries(fmt(tz).formatToParts(new Date(ms)).map((x) => [x.type, x.value])); return { y: +p.year, m: +p.month, d: +p.day, h: +p.hour % 24, min: +p.minute, s: +p.second }; }
const offsetAt = (ms, tz) => { const p = localParts(ms, tz); return Date.UTC(p.y, p.m - 1, p.d, p.h, p.min, p.s) - Math.floor(ms / 1000) * 1000; };
export function zonedToUtc(y, m, d, h, min, tz) { const guess = Date.UTC(y, m - 1, d, h, min); const t = guess - offsetAt(guess, tz); return guess - offsetAt(t, tz); }
const hm = (s) => { const [h, m] = s.split(':').map(Number); return [h, m]; };

export const defaultBusiness = () => ({ enabled: false, tz: 'Africa/Cairo', start: '08:00', end: '22:00', days: [0, 1, 2, 3, 4, 5, 6], urgent24x7: true });
// إعداد فعّال لأولوية معينة (العاجل يمكن أن يعمل 24/7)
export const cfgFor = (b, priority) => ({ ...b, enabled: !!b.enabled && !(priority === 'urgent' && b.urgent24x7) });

function* windows(fromMs, b) {
  const { y, m, d } = localParts(fromMs, b.tz), [sh, sm] = hm(b.start), [eh, em] = hm(b.end);
  for (let i = 0; i < 800; i++) {
    const dt = new Date(Date.UTC(y, m - 1, d + i));
    if (!b.days.includes(dt.getUTCDay())) continue;
    const yy = dt.getUTCFullYear(), mm = dt.getUTCMonth() + 1, dd = dt.getUTCDate();
    yield [zonedToUtc(yy, mm, dd, sh, sm, b.tz), zonedToUtc(yy, mm, dd, eh, em, b.tz)];
  }
}
// الموعد النهائي بعد إضافة durMs من وقت العمل ابتداءً من startMs
export function addBusinessMs(startMs, durMs, b) {
  if (!b.enabled) return startMs + durMs;
  let cur = startMs, rem = durMs;
  for (const [ws, we] of windows(startMs, b)) {
    const from = Math.max(cur, ws); if (from >= we) continue;
    const avail = we - from;
    if (rem <= avail) return from + rem;
    rem -= avail; cur = we;
  }
  return cur + rem;
}
// مقدار وقت العمل بين a و b
export function businessMsBetween(a, bEnd, b) {
  if (bEnd <= a) return 0;
  if (!b.enabled) return bEnd - a;
  let total = 0;
  for (const [ws, we] of windows(a, b)) {
    if (ws >= bEnd) break;
    const lo = Math.max(a, ws), hi = Math.min(bEnd, we);
    if (hi > lo) total += hi - lo;
  }
  return total;
}
export { M };
