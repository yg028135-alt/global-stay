import { randomUUID } from 'node:crypto';
import { HttpError } from './tickets.mjs';

const iso = () => new Date().toISOString();
const id = (prefix) => `${prefix}_${randomUUID().replaceAll('-', '').slice(0, 18)}`;
const text = (v, max, field, required = false) => {
  const s = typeof v === 'string' ? v.trim() : '';
  if (required && !s) throw new HttpError(400, `الحقل مطلوب: ${field}`);
  if (s.length > max) throw new HttpError(400, `قيمة غير صالحة للحقل: ${field}`);
  return s;
};
const date = (v, field) => {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(Date.parse(`${v}T00:00:00Z`)) || new Date(`${v}T00:00:00Z`).toISOString().slice(0, 10) !== v) throw new HttpError(400, `تاريخ غير صالح: ${field}`);
  return v;
};
const currencies = new Set(['EGP', 'USD', 'EUR', 'SAR']);
const money = (v, field, allowZero = false) => {
  if (typeof v !== 'number' || !Number.isFinite(v) || v < (allowZero ? 0 : 0.01) || v > 10_000_000) throw new HttpError(400, `مبلغ غير صالح: ${field}`);
  return Math.round(v * 100);
};
const mapReservation = (r) => ({ ...r, nightlyRate: r.nightly_rate_minor / 100, subtotal: r.subtotal_minor / 100, commission: r.commission_minor / 100, commissionRate: r.commission_rate, total: r.total_minor / 100, nightly_rate_minor: undefined, subtotal_minor: undefined, commission_minor: undefined, total_minor: undefined });

export function makeApartments(db) {
  const properties = () => db.prepare('SELECT * FROM properties ORDER BY name').all();
  const units = (propertyId) => db.prepare(`SELECT u.*,p.name property_name FROM units u JOIN properties p ON p.id=u.property_id ${propertyId ? 'WHERE u.property_id=?' : ''} ORDER BY p.name,u.code`).all(...(propertyId ? [propertyId] : []));
  const guests = (q = '') => db.prepare('SELECT id,full_name,phone,email,nationality,document_type,document_last4,notes,created_at FROM guests WHERE full_name LIKE ? OR phone LIKE ? ORDER BY created_at DESC LIMIT 200').all(`%${q}%`, `%${q}%`);
  const reservation = (rid) => {
    const r = db.prepare(`SELECT r.*,u.code unit_code,p.name property_name,g.full_name guest_name,g.phone guest_phone FROM reservations r JOIN units u ON u.id=r.unit_id JOIN properties p ON p.id=r.property_id JOIN guests g ON g.id=r.guest_id WHERE r.id=?`).get(rid);
    if (!r) throw new HttpError(404, 'الحجز غير موجود');
    const entries = db.prepare('SELECT id,entry_type type,amount_minor/100.0 amount,currency,method,reference,description,created_at createdAt FROM folio_entries WHERE reservation_id=? ORDER BY created_at,id').all(rid);
    const sameCurrency = entries.filter(e => e.currency === r.currency);
    const paid = sameCurrency.filter(e => e.type === 'stay_payment').reduce((n,e) => n + e.amount, 0);
    const charges = sameCurrency.filter(e => ['stay_charge','adjustment'].includes(e.type)).reduce((n,e) => n + e.amount, 0);
    const depositHeld = sameCurrency.filter(e => e.type === 'deposit_received').reduce((n,e) => n + e.amount, 0) - sameCurrency.filter(e => e.type === 'deposit_refund').reduce((n,e) => n + e.amount, 0);
    return { ...mapReservation(r), entries, paid: Number(paid.toFixed(2)), balance: Number((r.total_minor / 100 + charges - paid).toFixed(2)), depositHeld: Number(depositHeld.toFixed(2)) };
  };
  function createProperty(b) {
    const name = text(b.name, 100, 'اسم العقار', true), propertyId = id('prop');
    db.prepare('INSERT INTO properties(id,name,address,city,country,timezone,created_at) VALUES(?,?,?,?,?,?,?)').run(propertyId, name, text(b.address, 250, 'العنوان'), text(b.city, 80, 'المدينة'), text(b.country || 'Egypt', 80, 'الدولة'), text(b.timezone || 'Africa/Cairo', 80, 'المنطقة الزمنية'), iso());
    return db.prepare('SELECT * FROM properties WHERE id=?').get(propertyId);
  }
  function createUnit(b) {
    const propertyId = text(b.propertyId, 40, 'العقار', true);
    if (!db.prepare('SELECT 1 FROM properties WHERE id=? AND active=1').get(propertyId)) throw new HttpError(404, 'العقار غير موجود أو غير نشط');
    const code = text(b.code, 30, 'كود الوحدة', true), currency = text(b.currency || 'EGP', 3, 'العملة');
    if (!currencies.has(currency)) throw new HttpError(400, 'العملة غير مدعومة');
    const unitId = id('unit');
    try { db.prepare('INSERT INTO units(id,property_id,code,unit_type,bedrooms,bathrooms,capacity,floor,status,default_currency,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(unitId, propertyId, code, text(b.type || 'apartment', 40, 'نوع الوحدة'), int(b.bedrooms, 0, 20, 1, 'غرف النوم'), int(b.bathrooms, 0, 20, 1, 'الحمامات'), int(b.capacity, 1, 30, 2, 'السعة'), text(b.floor, 20, 'الدور'), 'ready', currency, text(b.notes, 1000, 'ملاحظات'), iso()); }
    catch (e) { if (String(e.message).includes('UNIQUE')) throw new HttpError(409, 'كود الوحدة مستخدم بالفعل داخل العقار'); throw e; }
    return db.prepare('SELECT * FROM units WHERE id=?').get(unitId);
  }
  function int(v, min, max, fallback, field) { if (v === undefined || v === null || v === '') return fallback; if (!Number.isInteger(v) || v < min || v > max) throw new HttpError(400, `قيمة غير صالحة: ${field}`); return v; }
  function createGuest(b) {
    const fullName = text(b.fullName, 120, 'اسم النزيل', true), guestId = id('guest');
    db.prepare('INSERT INTO guests(id,full_name,phone,email,nationality,document_type,document_last4,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(guestId, fullName, text(b.phone, 40, 'الهاتف'), text(b.email, 120, 'البريد'), text(b.nationality, 80, 'الجنسية'), text(b.documentType, 30, 'نوع الهوية'), text(b.documentLast4, 4, 'آخر أربعة أرقام'), text(b.notes, 1000, 'ملاحظات'), iso());
    return db.prepare('SELECT * FROM guests WHERE id=?').get(guestId);
  }
  function createReservation(b, user) {
    const unitId = text(b.unitId, 40, 'الوحدة', true), guestId = text(b.guestId, 40, 'النزيل', true);
    const unit = db.prepare("SELECT * FROM units WHERE id=? AND status!='inactive'").get(unitId);
    if (!unit) throw new HttpError(404, 'الوحدة غير موجودة أو غير متاحة للحجز');
    if (unit.status === 'maintenance') throw new HttpError(409, 'الوحدة تحت الصيانة ولا يمكن حجزها حاليًا');
    if (!db.prepare('SELECT 1 FROM guests WHERE id=?').get(guestId)) throw new HttpError(404, 'النزيل غير موجود');
    const checkIn = date(b.checkIn, 'الدخول'), checkOut = date(b.checkOut, 'الخروج');
    const nights = (Date.parse(`${checkOut}T00:00:00Z`) - Date.parse(`${checkIn}T00:00:00Z`)) / 86400000;
    if (nights < 1 || nights > 730) throw new HttpError(400, 'مدة الإقامة يجب أن تكون من ليلة إلى 730 ليلة');
    const conflict = db.prepare(`SELECT id FROM reservations WHERE unit_id=? AND status IN('pending','confirmed','checked_in') AND check_in < ? AND check_out > ? LIMIT 1`).get(unitId, checkOut, checkIn);
    if (conflict) throw new HttpError(409, `يوجد تعارض مع الحجز ${conflict.id}`);
    const currency = text(b.currency || unit.default_currency, 3, 'العملة');
    if (!currencies.has(currency)) throw new HttpError(400, 'العملة غير مدعومة');
    const rate = money(b.nightlyRate, 'سعر الليلة', true), subtotal = rate * nights;
    const commissionRate = b.commissionRate === undefined ? 10 : b.commissionRate;
    if (typeof commissionRate !== 'number' || commissionRate < 0 || commissionRate > 100) throw new HttpError(400, 'نسبة العمولة غير صالحة');
    const commission = Math.round(subtotal * commissionRate / 100), total = subtotal + commission;
    const rid = id('res'), timestamp = iso();
    db.prepare(`INSERT INTO reservations(id,property_id,unit_id,guest_id,check_in,check_out,status,source,currency,nightly_rate_minor,nights,subtotal_minor,commission_rate,commission_minor,total_minor,adults,children,notes,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(rid, unit.property_id, unitId, guestId, checkIn, checkOut, b.status === 'pending' ? 'pending' : 'confirmed', text(b.source || 'direct', 40, 'مصدر الحجز'), currency, rate, nights, subtotal, commissionRate, commission, total, int(b.adults, 1, 30, 1, 'البالغون'), int(b.children, 0, 20, 0, 'الأطفال'), text(b.notes, 2000, 'ملاحظات'), user.id, timestamp, timestamp);
    return reservation(rid);
  }
  function updateReservation(rid, b) {
    const current = db.prepare('SELECT * FROM reservations WHERE id=?').get(rid);
    if (!current) throw new HttpError(404, 'الحجز غير موجود');
    if (!['pending','confirmed','checked_in'].includes(current.status)) throw new HttpError(409, 'لا يمكن تعديل حجز ملغي أو مكتمل المغادرة');
    const unitId = b.unitId === undefined ? current.unit_id : text(b.unitId, 40, 'الوحدة', true);
    const guestId = b.guestId === undefined ? current.guest_id : text(b.guestId, 40, 'النزيل', true);
    const unit = db.prepare("SELECT * FROM units WHERE id=? AND status!='inactive'").get(unitId);
    if (!unit) throw new HttpError(404, 'الوحدة غير موجودة أو غير متاحة');
    if (unit.status === 'maintenance') throw new HttpError(409, 'الوحدة تحت الصيانة ولا يمكن نقل الحجز إليها');
    if (current.status === 'checked_in' && unitId !== current.unit_id) throw new HttpError(409, 'لا يمكن نقل وحدة الإقامة بعد تسجيل الوصول؛ استخدم إجراء نقل إقامة مخصصًا');
    if (!db.prepare('SELECT 1 FROM guests WHERE id=?').get(guestId)) throw new HttpError(404, 'النزيل غير موجود');
    const checkIn = b.checkIn === undefined ? current.check_in : date(b.checkIn, 'الدخول');
    const checkOut = b.checkOut === undefined ? current.check_out : date(b.checkOut, 'الخروج');
    const nights = (Date.parse(`${checkOut}T00:00:00Z`) - Date.parse(`${checkIn}T00:00:00Z`)) / 86400000;
    if (nights < 1 || nights > 730) throw new HttpError(400, 'مدة الإقامة يجب أن تكون من ليلة إلى 730 ليلة');
    const conflict = db.prepare(`SELECT id FROM reservations WHERE unit_id=? AND id<>? AND status IN('pending','confirmed','checked_in') AND check_in < ? AND check_out > ? LIMIT 1`).get(unitId, rid, checkOut, checkIn);
    if (conflict) throw new HttpError(409, `يوجد تعارض مع الحجز ${conflict.id}`);
    const currency = text(b.currency === undefined ? current.currency : b.currency, 3, 'العملة');
    if (!currencies.has(currency)) throw new HttpError(400, 'العملة غير مدعومة');
    const hasEntries = !!db.prepare('SELECT 1 FROM folio_entries WHERE reservation_id=? LIMIT 1').get(rid);
    if (hasEntries && currency !== current.currency) throw new HttpError(409, 'لا يمكن تغيير العملة بعد تسجيل حركات مالية');
    const rate = b.nightlyRate === undefined ? current.nightly_rate_minor : money(b.nightlyRate, 'سعر الليلة', true);
    const commissionRate = b.commissionRate === undefined ? current.commission_rate : b.commissionRate;
    if (typeof commissionRate !== 'number' || !Number.isFinite(commissionRate) || commissionRate < 0 || commissionRate > 100) throw new HttpError(400, 'نسبة العمولة غير صالحة');
    const subtotal = rate * nights, commission = Math.round(subtotal * commissionRate / 100), total = subtotal + commission;
    db.prepare(`UPDATE reservations SET property_id=?,unit_id=?,guest_id=?,check_in=?,check_out=?,source=?,currency=?,nightly_rate_minor=?,nights=?,subtotal_minor=?,commission_rate=?,commission_minor=?,total_minor=?,adults=?,children=?,notes=?,updated_at=? WHERE id=?`).run(unit.property_id, unitId, guestId, checkIn, checkOut, text(b.source === undefined ? current.source : b.source, 40, 'مصدر الحجز'), currency, rate, nights, subtotal, commissionRate, commission, total, int(b.adults, 1, 30, current.adults, 'البالغون'), int(b.children, 0, 20, current.children, 'الأطفال'), text(b.notes === undefined ? current.notes : b.notes, 2000, 'ملاحظات'), iso(), rid);
    return reservation(rid);
  }
  function financialSummary(filters = {}) {
    const from = filters.from ? date(filters.from, 'من تاريخ') : '';
    const to = filters.to ? date(filters.to, 'إلى تاريخ') : '';
    if (from && to && from >= to) throw new HttpError(400, 'نطاق التاريخ غير صحيح');
    const clauses = [], args = [];
    if (from) { clauses.push("substr(created_at,1,10)>=?"); args.push(from); }
    if (to) { clauses.push("substr(created_at,1,10)<?"); args.push(to); }
    const where = clauses.length ? 'WHERE ' + clauses.join(' AND ') : '';
    const rows = db.prepare(`SELECT currency,entry_type type,SUM(amount_minor) amount_minor,COUNT(*) count FROM folio_entries ${where} GROUP BY currency,entry_type ORDER BY currency,entry_type`).all(...args);
    const byCurrency = {};
    for (const row of rows) {
      const c = byCurrency[row.currency] ||= { currency: row.currency, stayPayments: 0, stayCharges: 0, depositsReceived: 0, depositsRefunded: 0, adjustments: 0, transactions: 0 };
      const amount = row.amount_minor / 100;
      if (row.type === 'stay_payment') c.stayPayments += amount;
      if (row.type === 'stay_charge') c.stayCharges += amount;
      if (row.type === 'deposit_received') c.depositsReceived += amount;
      if (row.type === 'deposit_refund') c.depositsRefunded += amount;
      if (row.type === 'adjustment') c.adjustments += amount;
      c.transactions += row.count;
    }
    for (const c of Object.values(byCurrency)) {
      c.depositHeld = Number((c.depositsReceived - c.depositsRefunded).toFixed(2));
      for (const k of ['stayPayments','stayCharges','depositsReceived','depositsRefunded','adjustments']) c[k] = Number(c[k].toFixed(2));
    }
    const rClauses = [], rArgs = [];
    if (from) { rClauses.push('substr(created_at,1,10)>=?'); rArgs.push(from); }
    if (to) { rClauses.push('substr(created_at,1,10)<?'); rArgs.push(to); }
    rClauses.push("status!='cancelled'");
    const booked = db.prepare(`SELECT currency,COUNT(*) reservation_count,SUM(subtotal_minor) subtotal_minor,SUM(commission_minor) commission_minor,SUM(total_minor) total_minor FROM reservations WHERE ${rClauses.join(' AND ')} GROUP BY currency ORDER BY currency`).all(...rArgs).map(r => ({ currency:r.currency, reservationCount:r.reservation_count, accommodationSubtotal:r.subtotal_minor/100, companyCommission:r.commission_minor/100, bookingTotal:r.total_minor/100 }));
    const eClauses = [], eArgs = [];
    if (from) { eClauses.push('substr(created_at,1,10)>=?'); eArgs.push(from); }
    if (to) { eClauses.push('substr(created_at,1,10)<?'); eArgs.push(to); }
    const expenseRows = db.prepare(`SELECT currency,status,SUM(amount_minor) amount_minor,COUNT(*) count FROM expenses ${eClauses.length?'WHERE '+eClauses.join(' AND '):''} GROUP BY currency,status ORDER BY currency,status`).all(...eArgs);
    const expenseSummary = {};
    for (const row of expenseRows) {
      const e = expenseSummary[row.currency] ||= { currency: row.currency, pending: 0, approved: 0, rejected: 0, paid: 0, count: 0 };
      e[row.status] = row.amount_minor / 100; e.count += row.count;
    }
    return { from, to, currencies: Object.values(byCurrency), bookings: booked, expenses: Object.values(expenseSummary), note: 'الحجوزات محسوبة حسب تاريخ إنشائها، والحركات حسب تاريخ تسجيلها، والمصروفات حسب تاريخ طلبها. الأرقام مجمعة حسب العملة؛ التأمينات ليست إيرادًا، والمدفوعات لا تُجمع مع العملات الأخرى.' };
  }

  function addEntry(rid, b, user) {
    const r = db.prepare('SELECT * FROM reservations WHERE id=?').get(rid);
    if (!r) throw new HttpError(404, 'الحجز غير موجود');
    const type = text(b.type, 30, 'نوع الحركة', true);
    if (!['stay_payment','stay_charge','deposit_received','deposit_refund','adjustment'].includes(type)) throw new HttpError(400, 'نوع الحركة غير صالح');
    const currency = text(b.currency || r.currency, 3, 'العملة');
    if (!currencies.has(currency) || currency !== r.currency) throw new HttpError(400, 'عملة الحركة يجب أن تطابق عملة الحجز');
    const amount = money(b.amount, 'المبلغ');
    if (type === 'deposit_refund') {
      const current = reservation(rid).depositHeld;
      if (amount / 100 > current + 0.001) throw new HttpError(400, 'قيمة رد التأمين أكبر من التأمين المحتجز');
    }
    if (type === 'stay_payment') {
      const current = reservation(rid).balance;
      if (amount / 100 > current + 0.001) throw new HttpError(400, 'قيمة التحصيل أكبر من المبلغ المستحق');
    }
    const eid = id('folio');
    db.prepare('INSERT INTO folio_entries(id,reservation_id,entry_type,amount_minor,currency,method,reference,description,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(eid, rid, type, amount, currency, text(b.method, 30, 'طريقة الدفع'), text(b.reference, 100, 'مرجع العملية'), text(b.description, 300, 'الوصف'), user.id, iso());
    return reservation(rid);
  }
  function updateStatus(rid, status) {
    if (!['confirmed','checked_in','checked_out','cancelled'].includes(status)) throw new HttpError(400, 'حالة الحجز غير صالحة');
    const r = db.prepare('SELECT * FROM reservations WHERE id=?').get(rid);
    if (!r) throw new HttpError(404, 'الحجز غير موجود');
    const allowed = { confirmed: ['checked_in','cancelled'], checked_in: ['checked_out'], checked_out: [], cancelled: [], pending: ['confirmed','cancelled'] };
    if (!allowed[r.status]?.includes(status)) throw new HttpError(409, `لا يمكن تغيير الحالة من ${r.status} إلى ${status}`);
    db.prepare('UPDATE reservations SET status=?,updated_at=? WHERE id=?').run(status, iso(), rid);
    if (status === 'checked_in') db.prepare("UPDATE units SET status='occupied' WHERE id=?").run(r.unit_id);
    if (status === 'checked_out') {
      db.prepare("UPDATE units SET status='cleaning' WHERE id=? AND status!='maintenance'").run(r.unit_id);
      db.prepare(`INSERT INTO pms_housekeeping_tasks(id,reservation_id,property_id,unit_id,task_type,status,priority,notes,created_at)
        VALUES(?,?,?,?, 'checkout_cleaning','open','normal','تنظيف بعد مغادرة النزيل',?)`).run(id('hkt'),rid,r.property_id,r.unit_id,iso());
    }
    return reservation(rid);
  }
  function transferReservation(rid, b, user) {
    const r = db.prepare('SELECT * FROM reservations WHERE id=?').get(rid);
    if (!r) throw new HttpError(404, 'الحجز غير موجود');
    if (r.status !== 'checked_in') throw new HttpError(409, 'نقل الوحدة متاح للإقامة التي تم تسجيل وصولها فقط');
    const toUnitId = text(b.toUnitId,40,'الوحدة الجديدة',true);
    if (toUnitId === r.unit_id) throw new HttpError(400,'الوحدة الجديدة هي نفس الوحدة الحالية');
    const target = db.prepare("SELECT * FROM units WHERE id=? AND status!='inactive'").get(toUnitId);
    if (!target) throw new HttpError(404,'الوحدة الجديدة غير موجودة أو غير نشطة');
    if (target.status !== 'ready') throw new HttpError(409,'الوحدة الجديدة ليست جاهزة للاستقبال');
    const conflict = db.prepare(`SELECT id FROM reservations WHERE unit_id=? AND id<>? AND status IN('pending','confirmed','checked_in') AND check_in < ? AND check_out > ? LIMIT 1`).get(toUnitId,rid,r.check_out,r.check_in);
    if (conflict) throw new HttpError(409,`يوجد تعارض حجز على الوحدة الجديدة: ${conflict.id}`);
    const oldUnitId = r.unit_id, oldPropertyId=r.property_id, timestamp=iso();
    db.prepare('UPDATE reservations SET unit_id=?,property_id=?,updated_at=? WHERE id=?').run(toUnitId,target.property_id,timestamp,rid);
    db.prepare("UPDATE units SET status='cleaning' WHERE id=? AND status!='maintenance'").run(oldUnitId);
    db.prepare("UPDATE units SET status='occupied' WHERE id=?").run(toUnitId);
    db.prepare('INSERT INTO reservation_transfers(id,reservation_id,from_unit_id,to_unit_id,moved_by,reason,created_at) VALUES(?,?,?,?,?,?,?)')
      .run(id('move'),rid,oldUnitId,toUnitId,user?.id||null,text(b.reason,500,'سبب النقل'),timestamp);
    db.prepare(`INSERT INTO pms_housekeeping_tasks(id,reservation_id,property_id,unit_id,task_type,status,priority,notes,created_at)
      VALUES(?,?,?,?,'transfer_cleaning','open','normal',?,?)`).run(id('hkt'),rid,oldPropertyId,oldUnitId,'تنظيف الوحدة بعد نقل النزيل',timestamp);
    return {reservation:reservation(rid),transferHistory:transferHistory(rid)};
  }
  function transferHistory(rid) {
    return db.prepare(`SELECT t.id,t.reason,t.created_at createdAt,fu.code fromUnitCode,tu.code toUnitCode,u.name movedBy FROM reservation_transfers t JOIN units fu ON fu.id=t.from_unit_id JOIN units tu ON tu.id=t.to_unit_id LEFT JOIN users u ON u.id=t.moved_by WHERE t.reservation_id=? ORDER BY t.created_at`).all(rid);
  }
  function listHousekeepingTasks(filters={}) {
    const where=[],args=[];
    if(filters.status){where.push('t.status=?');args.push(text(filters.status,20,'الحالة'));}
    if(filters.propertyId){where.push('t.property_id=?');args.push(text(filters.propertyId,40,'العقار'));}
    return db.prepare(`SELECT t.id,t.reservation_id reservationId,t.property_id propertyId,p.name propertyName,t.unit_id unitId,u.code unitCode,t.task_type taskType,t.status,t.priority,t.notes,t.created_at createdAt,t.completed_at completedAt,cu.name completedBy,r.id reservationCode FROM pms_housekeeping_tasks t JOIN properties p ON p.id=t.property_id JOIN units u ON u.id=t.unit_id JOIN reservations r ON r.id=t.reservation_id LEFT JOIN users cu ON cu.id=t.completed_by ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY CASE t.priority WHEN 'urgent' THEN 0 ELSE 1 END,t.created_at DESC LIMIT 500`).all(...args);
  }
  function updateHousekeepingTask(taskId,status,user) {
    if(!['in_progress','done'].includes(status)) throw new HttpError(400,'حالة مهمة النظافة غير صالحة');
    const task=db.prepare('SELECT * FROM pms_housekeeping_tasks WHERE id=?').get(taskId);
    if(!task) throw new HttpError(404,'مهمة النظافة غير موجودة');
    if(task.status==='done') throw new HttpError(409,'تم إغلاق هذه المهمة بالفعل');
    db.prepare('UPDATE pms_housekeeping_tasks SET status=?,completed_at=?,completed_by=? WHERE id=?').run(status,status==='done'?iso():null,status==='done'?user.id:null,taskId);
    if(status==='done') {
      const active=db.prepare("SELECT 1 FROM reservations WHERE unit_id=? AND status='checked_in' LIMIT 1").get(task.unit_id);
      if(!active) db.prepare("UPDATE units SET status='ready' WHERE id=? AND status='cleaning'").run(task.unit_id);
    }
    return listHousekeepingTasks().find(t=>t.id===taskId);
  }
  function propertyUnitReport(filters={}) {
    const from=date(filters.from,'من تاريخ'),to=date(filters.to,'إلى تاريخ');
    if(to<=from) throw new HttpError(400,'تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
    const params=[]; let propertyFilter='';
    if(filters.propertyId){propertyFilter=' AND p.id=?';params.push(text(filters.propertyId,40,'العقار'));}
    const units=db.prepare(`SELECT u.id unitId,u.code unitCode,p.id propertyId,p.name propertyName,u.status FROM units u JOIN properties p ON p.id=u.property_id WHERE u.status!='inactive'${propertyFilter} ORDER BY p.name,u.code`).all(...params);
    const totalDays=(Date.parse(`${to}T00:00:00Z`)-Date.parse(`${from}T00:00:00Z`))/86400000;
    const rows=[];
    for(const unit of units){
      const bookings=db.prepare(`SELECT currency,COALESCE(SUM(subtotal_minor),0) gross,COALESCE(SUM(commission_minor),0) commission,COUNT(*) bookingCount FROM reservations WHERE unit_id=? AND status!='cancelled' AND check_out>? AND check_in<? GROUP BY currency`).all(unit.unitId,from,to);
      const nights=db.prepare(`SELECT COALESCE(SUM(MAX(0,(julianday(MIN(check_out,?))-julianday(MAX(check_in,?))))),0) nights FROM reservations WHERE unit_id=? AND status!='cancelled' AND check_out>? AND check_in<?`).get(to,from,unit.unitId,from,to).nights;
      for(const b of bookings){rows.push({...unit,currency:b.currency,bookingCount:b.bookingCount,accommodationGross:b.gross/100,companyCommission:b.commission/100,occupiedNights:Number(nights.toFixed(2)),periodDays:totalDays,occupancyPercent:Number(Math.min(100,nights/totalDays*100).toFixed(1)),netBeforePropertyExpenses:(b.gross-b.commission)/100});}
      if(!bookings.length) rows.push({...unit,currency:'—',bookingCount:0,accommodationGross:0,companyCommission:0,occupiedNights:Number(nights.toFixed(2)),periodDays:totalDays,occupancyPercent:Number(Math.min(100,nights/totalDays*100).toFixed(1)),netBeforePropertyExpenses:0});
    }
    const propertyExpenses=db.prepare(`SELECT e.property_id propertyId,p.name propertyName,e.currency,COALESCE(SUM(e.amount_minor),0) paidExpenses,COUNT(*) expenseCount FROM expenses e JOIN properties p ON p.id=e.property_id WHERE e.status='paid' AND substr(e.paid_at,1,10)>=? AND substr(e.paid_at,1,10)<? ${filters.propertyId?'AND e.property_id=?':''} GROUP BY e.property_id,e.currency ORDER BY p.name,e.currency`).all(...(filters.propertyId?[from,to,text(filters.propertyId,40,'العقار')]:[from,to])).map(e=>({...e,paidExpenses:e.paidExpenses/100}));
    return {from,to,rows,propertyExpenses,note:'بيانات الإيرادات والعمولة والإشغال على مستوى الوحدة. مصروفات التشغيل المرتبطة بالعقار تظهر مرة واحدة في ملخص مصروفات العقارات ولا توزّع تلقائيًا على الوحدات لتجنب تكرارها أو افتراض نسب توزيع غير معتمدة.'};
  }

  function listReservations(filters = {}) {
    const where = [], args = [];
    if (filters.from) { where.push('r.check_out>?'); args.push(date(filters.from, 'من تاريخ')); }
    if (filters.to) { where.push('r.check_in<?'); args.push(date(filters.to, 'إلى تاريخ')); }
    if (filters.unitId) { where.push('r.unit_id=?'); args.push(text(filters.unitId, 40, 'الوحدة')); }
    if (filters.status) { where.push('r.status=?'); args.push(text(filters.status, 20, 'الحالة')); }
    return db.prepare(`SELECT r.id,r.unit_id unitId,r.property_id propertyId,r.check_in checkIn,r.check_out checkOut,r.status,r.source,r.currency,r.nights,r.total_minor/100.0 total,u.code unitCode,g.full_name guestName FROM reservations r JOIN units u ON u.id=r.unit_id JOIN guests g ON g.id=r.guest_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY r.check_in DESC LIMIT 500`).all(...args);
  }
  function createExpense(b, user) {
    const category = text(b.category, 60, 'تصنيف المصروف', true);
    const description = text(b.description, 300, 'وصف المصروف', true);
    const currency = text(b.currency || 'EGP', 3, 'العملة');
    if (!currencies.has(currency)) throw new HttpError(400, 'العملة غير مدعومة');
    const method = text(b.paymentMethod || 'cash', 30, 'طريقة الدفع');
    if (!['cash','instapay','bank_transfer','card','other'].includes(method)) throw new HttpError(400, 'طريقة الدفع غير صالحة');
    const propertyId = b.propertyId ? text(b.propertyId, 40, 'العقار') : null;
    if (propertyId && !db.prepare('SELECT 1 FROM properties WHERE id=?').get(propertyId)) throw new HttpError(404, 'العقار غير موجود');
    const expenseId = id('exp');
    db.prepare(`INSERT INTO expenses(id,property_id,category,description,amount_minor,currency,payment_method,requested_by,notes,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?)`).run(expenseId, propertyId, category, description, money(b.amount, 'المبلغ'), currency, method, user.id, text(b.notes, 1000, 'ملاحظات'), iso());
    return db.prepare(`SELECT e.*,p.name property_name,u.name requested_name FROM expenses e LEFT JOIN properties p ON p.id=e.property_id JOIN users u ON u.id=e.requested_by WHERE e.id=?`).get(expenseId);
  }
  function listExpenses(filters = {}) {
    const where = [], args = [];
    if (filters.status) { where.push('e.status=?'); args.push(text(filters.status, 20, 'الحالة')); }
    if (filters.from) { where.push('substr(e.created_at,1,10)>=?'); args.push(date(filters.from, 'من تاريخ')); }
    if (filters.to) { where.push('substr(e.created_at,1,10)<?'); args.push(date(filters.to, 'إلى تاريخ')); }
    return db.prepare(`SELECT e.id,e.property_id propertyId,p.name propertyName,e.category,e.description,e.amount_minor/100.0 amount,e.currency,e.payment_method paymentMethod,e.status,e.notes,e.created_at createdAt,e.approved_at approvedAt,e.paid_at paidAt,u.name requestedBy,au.name approvedBy,pu.name paidBy FROM expenses e LEFT JOIN properties p ON p.id=e.property_id JOIN users u ON u.id=e.requested_by LEFT JOIN users au ON au.id=e.approved_by LEFT JOIN users pu ON pu.id=e.paid_by ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY e.created_at DESC LIMIT 500`).all(...args);
  }
  function reviewExpense(expenseId, decision, user) {
    if (!['approved','rejected'].includes(decision)) throw new HttpError(400, 'قرار الاعتماد غير صالح');
    const e = db.prepare('SELECT * FROM expenses WHERE id=?').get(expenseId);
    if (!e) throw new HttpError(404, 'المصروف غير موجود');
    if (e.requested_by === user.id) throw new HttpError(403, 'لا يمكن اعتماد أو رفض مصروف قدمته بنفسك');
    if (e.status !== 'pending') throw new HttpError(409, 'تمت مراجعة هذا المصروف بالفعل');
    db.prepare('UPDATE expenses SET status=?,approved_by=?,approved_at=? WHERE id=?').run(decision, user.id, iso(), expenseId);
    return listExpenses().find(x => x.id === expenseId);
  }
  function payExpense(expenseId, user) {
    const e = db.prepare('SELECT * FROM expenses WHERE id=?').get(expenseId);
    if (!e) throw new HttpError(404, 'المصروف غير موجود');
    if (e.status !== 'approved') throw new HttpError(409, 'يجب اعتماد المصروف قبل تسجيل صرفه');
    db.prepare("UPDATE expenses SET status='paid',paid_by=?,paid_at=? WHERE id=?").run(user.id, iso(), expenseId);
    return listExpenses().find(x => x.id === expenseId);
  }
  function cashClosingPreview(userId, businessDate, currency) {
    const day = date(businessDate, 'تاريخ الوردية');
    if (!currencies.has(currency)) throw new HttpError(400, 'العملة غير مدعومة');
    const incoming = db.prepare(`SELECT COALESCE(SUM(amount_minor),0) amount FROM folio_entries WHERE created_by=? AND substr(created_at,1,10)=? AND currency=? AND method='cash' AND entry_type IN('stay_payment','deposit_received')`).get(userId, day, currency).amount;
    const refunds = db.prepare(`SELECT COALESCE(SUM(amount_minor),0) amount FROM folio_entries WHERE created_by=? AND substr(created_at,1,10)=? AND currency=? AND method='cash' AND entry_type='deposit_refund'`).get(userId, day, currency).amount;
    const expensesPaid = db.prepare(`SELECT COALESCE(SUM(amount_minor),0) amount FROM expenses WHERE paid_by=? AND substr(paid_at,1,10)=? AND currency=? AND payment_method='cash' AND status='paid'`).get(userId, day, currency).amount;
    const out = refunds + expensesPaid;
    return { businessDate: day, currency, cashIn: incoming / 100, cashOut: out / 100, expectedCash: (incoming - out) / 100, expenseCash: expensesPaid / 100, depositRefunds: refunds / 100 };
  }
  function createCashClosing(b, user) {
    const preview = cashClosingPreview(user.id, b.businessDate, text(b.currency || 'EGP', 3, 'العملة'));
    if (db.prepare('SELECT 1 FROM cash_closings WHERE user_id=? AND business_date=? AND currency=?').get(user.id, preview.businessDate, preview.currency)) throw new HttpError(409, 'تم إغلاق هذه الوردية والعملة من قبل');
    const counted = money(b.countedCash, 'النقدية المعدودة', true);
    const closingId = id('close');
    db.prepare(`INSERT INTO cash_closings(id,user_id,business_date,currency,cash_in_minor,cash_out_minor,expected_minor,counted_minor,difference_minor,notes,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(closingId,user.id,preview.businessDate,preview.currency,Math.round(preview.cashIn*100),Math.round(preview.cashOut*100),Math.round(preview.expectedCash*100),counted,counted-Math.round(preview.expectedCash*100),text(b.notes,1000,'ملاحظات'),iso());
    return { id: closingId, ...preview, countedCash: counted/100, difference: (counted-Math.round(preview.expectedCash*100))/100, notes: text(b.notes,1000,'ملاحظات') };
  }
  function listCashClosings(filters = {}) {
    const where = [], args = [];
    if (filters.from) { where.push('c.business_date>=?'); args.push(date(filters.from, 'من تاريخ')); }
    if (filters.to) { where.push('c.business_date<?'); args.push(date(filters.to, 'إلى تاريخ')); }
    return db.prepare(`SELECT c.id,c.user_id userId,u.name userName,c.business_date businessDate,c.currency,c.cash_in_minor/100.0 cashIn,c.cash_out_minor/100.0 cashOut,c.expected_minor/100.0 expectedCash,c.counted_minor/100.0 countedCash,c.difference_minor/100.0 difference,c.notes,c.created_at createdAt FROM cash_closings c JOIN users u ON u.id=c.user_id ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY c.business_date DESC,c.created_at DESC LIMIT 500`).all(...args);
  }

  function listOwners() {
    return db.prepare(`SELECT o.id,o.full_name fullName,o.phone,o.email,o.national_id_last4 nationalIdLast4,o.notes,o.active,o.created_at createdAt,
      COUNT(po.id) propertyCount FROM owners o LEFT JOIN property_owners po ON po.owner_id=o.id GROUP BY o.id ORDER BY o.full_name`).all();
  }
  function createOwner(b) {
    const fullName = text(b.fullName, 120, 'اسم المالك', true);
    const ownerId = id('owner');
    db.prepare('INSERT INTO owners(id,full_name,phone,email,national_id_last4,notes,created_at) VALUES(?,?,?,?,?,?,?)')
      .run(ownerId, fullName, text(b.phone,40,'الهاتف'), text(b.email,120,'البريد'), text(b.nationalIdLast4,4,'آخر أربعة أرقام'), text(b.notes,1000,'ملاحظات'), iso());
    return listOwners().find(o => o.id === ownerId);
  }
  function assignOwner(b) {
    const propertyId = text(b.propertyId,40,'العقار',true), ownerId = text(b.ownerId,40,'المالك',true);
    if (!db.prepare('SELECT 1 FROM properties WHERE id=? AND active=1').get(propertyId)) throw new HttpError(404,'العقار غير موجود');
    if (!db.prepare('SELECT 1 FROM owners WHERE id=? AND active=1').get(ownerId)) throw new HttpError(404,'المالك غير موجود');
    const share = b.sharePercent;
    if (typeof share !== 'number' || !Number.isFinite(share) || share <= 0 || share > 100) throw new HttpError(400,'نسبة الملكية يجب أن تكون أكبر من صفر وحتى 100%');
    const existing = db.prepare('SELECT id,share_percent FROM property_owners WHERE property_id=? AND owner_id=?').get(propertyId,ownerId);
    const total = db.prepare('SELECT COALESCE(SUM(share_percent),0) total FROM property_owners WHERE property_id=? AND owner_id<>?').get(propertyId,ownerId).total;
    if (total + share > 100.000001) throw new HttpError(409,'إجمالي نسب ملكية العقار لا يمكن أن يتجاوز 100%');
    if (existing) db.prepare('UPDATE property_owners SET share_percent=? WHERE id=?').run(share,existing.id);
    else db.prepare('INSERT INTO property_owners(id,property_id,owner_id,share_percent,created_at) VALUES(?,?,?,?,?)').run(id('pown'),propertyId,ownerId,share,iso());
    return db.prepare(`SELECT po.id,po.property_id propertyId,p.name propertyName,po.owner_id ownerId,o.full_name ownerName,po.share_percent sharePercent FROM property_owners po JOIN properties p ON p.id=po.property_id JOIN owners o ON o.id=po.owner_id WHERE po.property_id=? AND po.owner_id=?`).get(propertyId,ownerId);
  }
  function ownerStatement(ownerId, filters = {}) {
    const from = date(filters.from,'من تاريخ'), to = date(filters.to,'إلى تاريخ');
    if (from >= to) throw new HttpError(400,'تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
    const owner = db.prepare('SELECT id,full_name fullName,phone,email FROM owners WHERE id=? AND active=1').get(ownerId);
    if (!owner) throw new HttpError(404,'المالك غير موجود');
    const links = db.prepare(`SELECT po.property_id propertyId,p.name propertyName,po.share_percent sharePercent FROM property_owners po JOIN properties p ON p.id=po.property_id WHERE po.owner_id=? ORDER BY p.name`).all(ownerId);
    const rows = [];
    for (const link of links) {
      if (filters.propertyId && filters.propertyId !== link.propertyId) continue;
      const reservations = db.prepare(`SELECT currency,COALESCE(SUM(subtotal_minor),0) subtotal,COALESCE(SUM(commission_minor),0) commission,COUNT(*) bookings FROM reservations WHERE property_id=? AND status!='cancelled' AND check_out>=? AND check_out<? GROUP BY currency`).all(link.propertyId,from,to);
      const expenses = db.prepare(`SELECT currency,COALESCE(SUM(amount_minor),0) amount,COUNT(*) count FROM expenses WHERE property_id=? AND status='paid' AND substr(paid_at,1,10)>=? AND substr(paid_at,1,10)<? GROUP BY currency`).all(link.propertyId,from,to);
      const currenciesInPeriod = new Set([...reservations.map(x=>x.currency),...expenses.map(x=>x.currency)]);
      for (const currency of currenciesInPeriod) {
        const r = reservations.find(x=>x.currency===currency) || {subtotal:0,commission:0,bookings:0};
        const e = expenses.find(x=>x.currency===currency) || {amount:0,count:0};
        const share = link.sharePercent / 100;
        const gross = Math.round(r.subtotal * share), commission = Math.round(r.commission * share), allocatedExpenses = Math.round(e.amount * share);
        const net = gross - commission - allocatedExpenses;
        const paid = db.prepare(`SELECT COALESCE(SUM(amount_minor),0) amount FROM owner_settlements WHERE owner_id=? AND property_id=? AND period_from=? AND period_to=? AND currency=?`).get(ownerId,link.propertyId,from,to,currency).amount;
        rows.push({propertyId:link.propertyId,propertyName:link.propertyName,sharePercent:link.sharePercent,currency,bookings:r.bookings,accommodationGross:gross/100,companyCommission:commission/100,allocatedExpenses:allocatedExpenses/100,netEntitlement:net/100,paidToOwner:paid/100,outstanding:(net-paid)/100,expenseCount:e.count});
      }
    }
    return {owner,from,to,rows,note:'يتم احتساب الحجوزات بتاريخ المغادرة داخل الفترة، والمصروفات المدفوعة بتاريخ الصرف. العمولة والمصروفات موزعة حسب نسبة الملكية، وكل عملة مستقلة.'};
  }
  function settleOwner(b,user) {
    const ownerId = text(b.ownerId,40,'المالك',true), propertyId = text(b.propertyId,40,'العقار',true);
    const from = date(b.from,'من تاريخ'), to = date(b.to,'إلى تاريخ'), currency = text(b.currency,3,'العملة');
    if (!currencies.has(currency)) throw new HttpError(400,'العملة غير مدعومة');
    const statement = ownerStatement(ownerId,{from,to,propertyId});
    const row = statement.rows.find(x=>x.currency===currency);
    if (!row || row.outstanding <= 0) throw new HttpError(409,'لا يوجد مستحق قائم لهذا المالك والعقار والعملة في الفترة المحددة');
    const amount = money(b.amount,'مبلغ التسوية');
    if (amount > Math.round(row.outstanding*100)) throw new HttpError(400,'مبلغ الصرف أكبر من المستحق المتبقي');
    const method = text(b.method || 'bank_transfer',30,'طريقة الدفع');
    if (!['cash','instapay','bank_transfer','card','other'].includes(method)) throw new HttpError(400,'طريقة الدفع غير صالحة');
    const settlementId=id('oset');
    db.prepare('INSERT INTO owner_settlements(id,owner_id,property_id,period_from,period_to,currency,amount_minor,method,reference,notes,paid_by,paid_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(settlementId,ownerId,propertyId,from,to,currency,amount,method,text(b.reference,100,'المرجع'),text(b.notes,1000,'ملاحظات'),user.id,iso());
    return {id:settlementId,ownerId,propertyId,from,to,currency,amount:amount/100,method,reference:text(b.reference,100,'المرجع'),paidAt:iso()};
  }
  function listOwnerSettlements(filters={}) {
    const where=[],args=[];
    if(filters.ownerId){where.push('s.owner_id=?');args.push(text(filters.ownerId,40,'المالك'));}
    if(filters.from){where.push('s.period_from>=?');args.push(date(filters.from,'من تاريخ'));}
    if(filters.to){where.push('s.period_to<=?');args.push(date(filters.to,'إلى تاريخ'));}
    return db.prepare(`SELECT s.id,s.owner_id ownerId,o.full_name ownerName,s.property_id propertyId,p.name propertyName,s.period_from periodFrom,s.period_to periodTo,s.currency,s.amount_minor/100.0 amount,s.method,s.reference,s.notes,s.paid_at paidAt,u.name paidBy FROM owner_settlements s JOIN owners o ON o.id=s.owner_id JOIN properties p ON p.id=s.property_id JOIN users u ON u.id=s.paid_by ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY s.paid_at DESC LIMIT 500`).all(...args);
  }
  function reservationDocument(rid,kind='invoice',entryId='',user=null) {
    if(!['invoice','receipt'].includes(kind)) throw new HttpError(400,'نوع المستند غير صالح');
    const r=reservation(rid);
    let entry=null;
    if(kind==='receipt') {
      entry=entryId ? r.entries.find(e=>e.id===entryId) : [...r.entries].reverse().find(e=>['stay_payment','deposit_received','deposit_refund'].includes(e.type));
      if(!entry) throw new HttpError(404,'لا توجد حركة مالية لإصدار إيصال عنها');
    }
    let doc = kind==='invoice'
      ? db.prepare("SELECT document_number documentNumber,issued_at issuedAt FROM reservation_documents WHERE reservation_id=? AND document_type='invoice'").get(rid)
      : db.prepare("SELECT document_number documentNumber,issued_at issuedAt FROM reservation_documents WHERE folio_entry_id=? AND document_type='receipt'").get(entry.id);
    if(!doc) {
      const next = db.prepare(`INSERT INTO document_counters(document_type,next_number) VALUES(?,1) ON CONFLICT(document_type) DO UPDATE SET next_number=next_number+1 RETURNING next_number`).get(kind).next_number;
      const number=`GS-${kind==='invoice'?'INV':'RCT'}-${String(next).padStart(6,'0')}`, issuedAt=iso();
      db.prepare('INSERT INTO reservation_documents(id,reservation_id,folio_entry_id,document_type,document_number,issued_by,issued_at) VALUES(?,?,?,?,?,?,?)').run(id('doc'),rid,entry?.id||null,kind,number,user?.id||null,issuedAt);
      doc={documentNumber:number,issuedAt};
    }
    return {kind,documentNumber:doc.documentNumber,issuedAt:doc.issuedAt,reservation:r,entry};
  }

  return { properties, units, guests, createProperty, createUnit, createGuest, createReservation, updateReservation, financialSummary, addEntry, updateStatus, transferReservation, transferHistory, listHousekeepingTasks, updateHousekeepingTask, propertyUnitReport, reservation, listReservations, createExpense, listExpenses, reviewExpense, payExpense, cashClosingPreview, createCashClosing, listCashClosings, listOwners, createOwner, assignOwner, ownerStatement, settleOwner, listOwnerSettlements, reservationDocument };
}
