// بيانات الفندق (الغرف/الطلبات/المهام) في جداول حقيقية بدل مستند JSON واحد. المزامنة على مستوى الصف.
import { HttpError } from './tickets.mjs';
const KINDS = { rooms: 'asc', requests: 'desc', tasks: 'desc' }; // ترتيب العرض: الغرف بالإدخال، والبقية الأحدث أولًا
const iso = () => new Date().toISOString();
const MAX_ROW = 8000;

export function makeHotel(db) {
  const read = (kind) => db.prepare(`SELECT data FROM ${kind} ORDER BY ord ${KINDS[kind] === 'asc' ? 'ASC' : 'DESC'}`).all().map((r) => JSON.parse(r.data));
  const count = (kind) => db.prepare(`SELECT COUNT(*) c FROM ${kind}`).get().c;
  const hasData = () => count('rooms') + count('requests') + count('tasks') > 0;
  const roomExists = (id) => !!db.prepare('SELECT 1 FROM rooms WHERE id=?').get(id);
  const roomCount = () => count('rooms');
  function readAll() { return hasData() ? { rooms: read('rooms'), requests: read('requests'), tasks: read('tasks') } : null; }

  function clean(kind, row) {
    if (!row || typeof row !== 'object' || typeof row.id !== 'string' || !row.id || row.id.length > 40) throw new HttpError(400, `صف غير صالح في ${kind}`);
    const data = JSON.stringify(row);
    if (data.length > MAX_ROW) throw new HttpError(400, 'حجم الصف أكبر من المسموح');
    return { id: row.id, status: typeof row.status === 'string' ? row.status.slice(0, 30) : null, data };
  }
  // changes: { upsert: {rooms:[...], requests:[...], tasks:[...]}, remove: {rooms:[ids]...} } — يُستدعى داخل معاملة
  function apply(changes) {
    let n = 0;
    for (const kind of Object.keys(KINDS)) {
      const rows = changes?.upsert?.[kind] ?? [], dels = changes?.remove?.[kind] ?? [];
      if (!Array.isArray(rows) || !Array.isArray(dels) || rows.length > 500 || dels.length > 500) throw new HttpError(400, 'تغييرات غير صالحة');
      for (const row of rows) {
        const c = clean(kind, row), ex = db.prepare(`SELECT ord FROM ${kind} WHERE id=?`).get(c.id);
        if (ex) db.prepare(`UPDATE ${kind} SET status=?,data=?,updated_at=? WHERE id=?`).run(c.status, c.data, iso(), c.id);
        else db.prepare(`INSERT INTO ${kind}(id,ord,status,data,updated_at) VALUES(?,?,?,?,?)`).run(c.id, db.prepare(`SELECT COALESCE(MAX(ord),0)+1 o FROM ${kind}`).get().o, c.status, c.data, iso());
        n++;
      }
      for (const id of dels) if (typeof id === 'string') { db.prepare(`DELETE FROM ${kind} WHERE id=?`).run(id); n++; }
    }
    return n;
  }
  // ترحيل المستند القديم (kv) إلى الجداول مرة واحدة
  function migrate(kvGet, kvDelete) {
    const doc = kvGet('hotel', null);
    if (!doc || hasData()) return false;
    for (const kind of Object.keys(KINDS)) {
      const arr = Array.isArray(doc[kind]) ? doc[kind] : [], n = arr.length;
      arr.forEach((row, i) => {
        const c = clean(kind, row);
        db.prepare(`INSERT OR IGNORE INTO ${kind}(id,ord,status,data,updated_at) VALUES(?,?,?,?,?)`).run(c.id, KINDS[kind] === 'asc' ? i + 1 : n - i, c.status, c.data, iso());
      });
    }
    kvDelete('hotel'); return true;
  }
  return { readAll, apply, roomExists, roomCount, migrate };
}
