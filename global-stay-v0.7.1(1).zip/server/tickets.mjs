// محرك التذاكر على الخادم: التوجيه، الإسناد، دورة الحياة، SLA. الخادم هو مصدر الوقت والحقيقة.
import { addBusinessMs, businessMsBetween, cfgFor, defaultBusiness, validTz } from './biz.mjs';
const M = 60000;
export class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
export const DEPTS = { customer_service: 'خدمة العملاء', guest_relations: 'علاقات النزلاء', reception: 'الاستقبال', accounting: 'المحاسبة', housekeeping: 'التدبير المنزلي', maintenance: 'الصيانة', operations: 'إدارة التشغيل' };
export const CATS = {
  complaint: ['شكوى', 'customer_service'], inquiry: ['استفسار', 'customer_service'],
  booking: ['حجز', 'reception'], checkin: ['تسكين', 'reception'], checkout: ['مغادرة', 'reception'],
  maintenance: ['صيانة', 'operations'], cleaning: ['نظافة', 'operations'], preparation: ['تجهيز', 'operations']
};
export const PRI = { urgent: 'عاجل', high: 'مرتفع', medium: 'متوسط', low: 'منخفض' };
const defaults = () => ({ strategy: 'least_busy', acceptMinutes: 5, autoReassign: false, sla: { urgent: 30, high: 120, medium: 360, low: 1440 }, business: defaultBusiness() });
const iso = (ms) => new Date(ms).toISOString();
const ms = (s) => Date.parse(s);
const str = (v, max, name, required = true) => {
  const s = typeof v === 'string' ? v.trim() : '';
  if (required && !s) throw new HttpError(400, `الحقل مطلوب: ${name}`);
  if (s.length > max) throw new HttpError(400, `الحقل أطول من المسموح: ${name}`);
  return s;
};

export function createEngine({ db, emit, notifyUser }) {
  const kvGet = (k, def = null) => { const r = db.prepare('SELECT value FROM kv WHERE key=?').get(k); return r ? JSON.parse(r.value) : def; };
  const kvSet = (k, v) => db.prepare('INSERT INTO kv(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at').run(k, JSON.stringify(v), iso(Date.now()));
  const settings = () => { const d = defaults(), s = kvGet('ticketSettings', {}); return { ...d, ...s, sla: { ...d.sla, ...(s.sla || {}) }, business: { ...d.business, ...(s.business || {}) } }; };
  const load = (id) => { const r = db.prepare('SELECT data FROM tickets WHERE id=?').get(id); return r ? JSON.parse(r.data) : null; };
  const store = (t) => db.prepare('UPDATE tickets SET status=?,department=?,agent_id=?,data=? WHERE id=?').run(t.status, t.department, t.assignedAgentId, JSON.stringify(t), t.id);
  const insert = (t) => {
    const seq = Number(t.id.replace(/\D/g, ''));
    db.prepare('INSERT INTO tickets(id,seq,status,department,agent_id,created_at,data) VALUES(?,?,?,?,?,?,?)').run(t.id, seq, t.status, t.department, t.assignedAgentId, t.timestamps.createdAt, JSON.stringify(t));
  };
  const nextId = () => `TKT-${Math.max(1000, db.prepare('SELECT COALESCE(MAX(seq),0) m FROM tickets').get().m) + 1}`;
  const agents = () => db.prepare("SELECT id,name,dept,online FROM users WHERE role='agent' AND active=1 ORDER BY dept,name").all().map((a) => ({ ...a, online: !!a.online }));
  const managers = () => db.prepare("SELECT id FROM users WHERE role='manager' AND active=1").all().map((m) => m.id);
  const log = (t, type, actor, text) => (t.activityLog ||= []).push({ at: iso(Date.now()), type, actor, text });
  const notifyManagers = (t, kind, text) => managers().forEach((id) => notifyUser(id, t.id, kind, text));

  const slaInfo = (t, now = Date.now()) => {
    const total = t.slaSpanMs || t.slaMinutes * M, deadline = ms(t.timestamps.slaDeadline);
    const done = t.status === 'resolved', paused = t.status === 'on_hold' && !!t.timestamps.heldAt;
    const ref = done ? ms(t.timestamps.resolvedAt) : paused ? ms(t.timestamps.heldAt) : now;
    const remaining = deadline - ref, ratio = Math.max(0, Math.min(1, remaining / total));
    return { remaining, ratio, level: remaining < 0 ? 'breached' : ratio < 0.25 ? 'warning' : 'on_track' };
  };

  function pickAgent(dept, exclude) {
    const S = settings(), rr = kvGet('rr', {});
    const all = agents().filter((a) => a.dept === dept);
    if (!all.length) return null;
    const last = all.findIndex((a) => a.id === rr[dept]);
    const cands = all.map((_, i) => all[(last + 1 + i) % all.length]).filter((a) => a.online && a.id !== exclude);
    if (!cands.length) return null;
    if (S.strategy === 'round_robin') return cands[0];
    const load = (a) => db.prepare("SELECT COUNT(*) c FROM tickets WHERE agent_id=? AND status NOT IN ('resolved','new')").get(a.id).c;
    return cands.reduce((best, a) => load(a) < load(best) ? a : best);
  }
  function assign(t, agent, reason) {
    t.assignedAgentId = agent.id; t.status = 'assigned';
    t.timestamps.assignedAt = iso(Date.now()); t.timestamps.acceptedAt = null; t.timestamps.startedAt = null; t.acceptOverdueAt = null;
    kvSet('rr', { ...kvGet('rr', {}), [agent.dept]: agent.id });
    log(t, 'assigned', 'النظام', `${reason || 'إسناد تلقائي'} ← ${agent.name}`);
    notifyUser(agent.id, t.id, 'assigned', `تيكيت جديد ${t.id}: ${t.title}`);
  }
  function unpause(t) {
    if (!t.timestamps.heldAt) return;
    const held = ms(t.timestamps.heldAt), now = Date.now(), dl = ms(t.timestamps.slaDeadline), cfg = cfgFor(settings().business, t.priority);
    // المتبقي من وقت العمل لحظة التعليق يُستأنف من الآن (وإن كان انتهى سابقًا فيُزاح الموعد بمدة التعليق كما هو)
    t.timestamps.slaDeadline = iso(dl > held ? addBusinessMs(now, businessMsBetween(held, dl, cfg), cfg) : dl + (now - held));
    t.slaSpanMs = Math.max(t.slaSpanMs || t.slaMinutes * M, ms(t.timestamps.slaDeadline) - now);
    t.pausedMs = (t.pausedMs || 0) + (now - held); t.timestamps.heldAt = null;
  }
  const mustAct = (t, actor) => { if (actor.role !== 'manager' && t.assignedAgentId !== actor.id) throw new HttpError(403, 'هذا التيكيت مسند لإيجينت آخر'); };
  const get = (id) => { const t = load(id); if (!t) throw new HttpError(404, 'التيكيت غير موجود'); return t; };

  function create(input, actor) {
    const title = str(input.title, 90, 'العنوان'), description = str(input.description, 300, 'التفاصيل', false), room = str(input.room, 8, 'الغرفة', false);
    if (!CATS[input.category]) throw new HttpError(400, 'تصنيف غير صالح');
    if (!PRI[input.priority]) throw new HttpError(400, 'أولوية غير صالحة');
    const n = Date.now(), S0 = settings(), sla = S0.sla[input.priority], dept = CATS[input.category][1];
    const deadline = addBusinessMs(n, sla * M, cfgFor(S0.business, input.priority));
    const t = { id: nextId(), title, description, category: input.category, priority: input.priority, department: dept, room, assignedAgentId: null, status: 'new', slaMinutes: sla, slaSpanMs: deadline - n,
      timestamps: { createdAt: iso(n), assignedAt: null, acceptedAt: null, startedAt: null, heldAt: null, resolvedAt: null, slaDeadline: iso(deadline) }, slaStatus: 'on_track', activityLog: [] };
    if (input.source) t.source = input.source;
    if (input.fromRequest) t.fromRequest = String(input.fromRequest).slice(0, 20);
    log(t, 'created', actor.name, `إنشاء التيكيت — التصنيف: ${CATS[input.category][0]}، الأولوية: ${PRI[input.priority]}`);
    log(t, 'route', 'النظام', `توجيه تلقائي إلى قسم ${DEPTS[dept]}`);
    const agent = pickAgent(dept);
    if (agent) assign(t, agent); else { log(t, 'system', 'النظام', 'لا يوجد إيجينت متاح حاليًا — التيكيت في قائمة الانتظار'); notifyManagers(t, 'queue', `${t.id} بلا إيجينت متاح في ${DEPTS[dept]}`); }
    insert(t); emit('change', { ticketId: t.id });
    return t;
  }
  const mutate = (id, actor, fn) => { const t = get(id); mustAct(t, actor); fn(t); store(t); emit('change', { ticketId: id }); return t; };
  const bad = (m) => { throw new HttpError(409, m); };

  const ops = {
    accept: (id, actor) => mutate(id, actor, (t) => {
      if (t.status !== 'assigned') bad('لا يمكن قبول هذا التيكيت في حالته الحالية');
      t.status = 'accepted'; t.timestamps.acceptedAt = iso(Date.now());
      log(t, 'accepted', actor.name, actor.role === 'manager' && actor.id !== t.assignedAgentId ? 'قبول الطلب نيابةً عن الإيجينت (بواسطة الإدارة)' : 'قبول الطلب (Accept Ticket)');
    }),
    start: (id, actor) => mutate(id, actor, (t) => {
      if (t.status !== 'accepted') bad('يجب قبول الطلب أولًا');
      t.status = 'in_progress'; t.timestamps.startedAt = iso(Date.now()); log(t, 'started', actor.name, 'بدء التنفيذ');
    }),
    hold: (id, actor, b) => { const reason = str(b.reason, 120, 'سبب التعليق'); return mutate(id, actor, (t) => {
      if (!['accepted', 'in_progress'].includes(t.status)) bad('لا يمكن تعليق هذا التيكيت');
      t.status = 'on_hold'; t.timestamps.heldAt = iso(Date.now()); log(t, 'hold', actor.name, `تعليق الطلب وإيقاف مؤقت الـ SLA — السبب: ${reason}`);
    }); },
    resume: (id, actor) => mutate(id, actor, (t) => {
      if (t.status !== 'on_hold') bad('التيكيت غير معلق');
      unpause(t); t.status = 'in_progress'; t.timestamps.startedAt ||= iso(Date.now()); log(t, 'resume', actor.name, 'استئناف العمل وتشغيل مؤقت الـ SLA');
    }),
    resolve: (id, actor, b) => { const summary = str(b.summary, 240, 'ملخص الحل'); return mutate(id, actor, (t) => {
      if (!['accepted', 'in_progress', 'on_hold'].includes(t.status)) bad('لا يمكن إغلاق هذا التيكيت في حالته الحالية');
      unpause(t); t.status = 'resolved'; t.timestamps.resolvedAt = iso(Date.now()); t.resolution = summary;
      t.slaStatus = ms(t.timestamps.resolvedAt) > ms(t.timestamps.slaDeadline) ? 'breached' : 'on_track';
      log(t, 'resolved', actor.name, `إغلاق الطلب — ملخص الحل: ${summary}`);
    }); },
    transfer: (id, actor, b) => { const reason = str(b.reason, 200, 'سبب التحويل'); if (!DEPTS[b.dept]) throw new HttpError(400, 'قسم غير صالح'); return mutate(id, actor, (t) => {
      if (t.status === 'resolved') bad('التيكيت مغلق');
      if (b.dept === t.department) bad('التيكيت في نفس القسم بالفعل');
      unpause(t); const from = t.department; t.department = b.dept; t.transfers = (t.transfers || 0) + 1;
      log(t, 'transfer', actor.name, `تحويل من ${DEPTS[from]} إلى ${DEPTS[b.dept]} — السبب: ${reason}`);
      const a = pickAgent(b.dept);
      if (a) assign(t, a, 'إسناد بعد التحويل');
      else { t.assignedAgentId = null; t.status = 'new'; t.timestamps.acceptedAt = null; log(t, 'system', 'النظام', 'لا يوجد إيجينت متاح في القسم الجديد'); }
    }); },
    reassign: (id, actor) => mutate(id, actor, (t) => {
      if (t.status !== 'assigned') bad('إعادة التوجيه متاحة قبل القبول فقط');
      const a = pickAgent(t.department, t.assignedAgentId);
      if (!a) bad('لا يوجد إيجينت آخر متاح في القسم');
      assign(t, a, `إعادة توجيه يدوية بواسطة ${actor.name}`);
    }),
    note: (id, actor, b) => { const text = str(b.text, 200, 'الملاحظة'); return mutate(id, actor, (t) => log(t, 'note', actor.name, text)); }
  };

  function sweep() {
    const S = settings(), n = Date.now(); let changed = false;
    const rows = db.prepare("SELECT data FROM tickets WHERE status!='resolved'").all();
    for (const r of rows) {
      const t = JSON.parse(r.data); let dirty = false;
      if (t.status === 'new') { const a = pickAgent(t.department); if (a) { assign(t, a, 'إسناد من قائمة الانتظار'); dirty = true; } }
      else {
        const s = slaInfo(t, n);
        if (t.slaStatus !== s.level) { t.slaStatus = s.level; dirty = true; }
        if (s.level === 'warning' && !t.warnedAt && t.status !== 'on_hold') {
          t.warnedAt = iso(n); log(t, 'sla', 'النظام', 'اقتراب انتهاء مهلة SLA'); dirty = true;
          if (t.assignedAgentId) notifyUser(t.assignedAgentId, t.id, 'sla_warning', `${t.id} يقترب من انتهاء الـ SLA`);
        }
        if (s.level === 'breached' && !t.breachedAt && t.status !== 'on_hold') {
          t.breachedAt = iso(n); log(t, 'sla', 'النظام', 'تم تجاوز مهلة SLA (SLA Breached)'); dirty = true;
          if (t.assignedAgentId) notifyUser(t.assignedAgentId, t.id, 'sla_breach', `تجاوز SLA: ${t.id}`);
          notifyManagers(t, 'sla_breach', `تجاوز SLA: ${t.id} — ${t.title}`);
        }
        if (t.status === 'assigned' && ms(t.timestamps.assignedAt) + S.acceptMinutes * M < n) {
          const next = S.autoReassign ? pickAgent(t.department, t.assignedAgentId) : null;
          if (next) { assign(t, next, `إعادة توجيه تلقائية لتأخر القبول أكثر من ${S.acceptMinutes} دقائق`); dirty = true; }
          else if (!t.acceptOverdueAt) {
            t.acceptOverdueAt = iso(n); log(t, 'sla', 'النظام', 'تأخر في القبول — لم يقبل الإيجينت الطلب خلال المهلة'); dirty = true;
            if (t.assignedAgentId) notifyUser(t.assignedAgentId, t.id, 'accept_late', `تأخر قبول ${t.id}`);
            notifyManagers(t, 'accept_late', `تأخر في قبول ${t.id}`);
          }
        }
      }
      if (dirty) { store(t); changed = true; }
    }
    if (changed) emit('change', {});
  }

  function listFor(user) {
    const rows = user.role === 'manager' ? db.prepare('SELECT data FROM tickets ORDER BY seq DESC LIMIT 2000').all()
      : db.prepare('SELECT data FROM tickets WHERE agent_id=? ORDER BY seq DESC LIMIT 1000').all(user.id);
    return rows.map((r) => JSON.parse(r.data));
  }
  function setSettings(b) {
    const d = defaults(), cur = settings();
    const next = { strategy: ['least_busy', 'round_robin'].includes(b.strategy) ? b.strategy : cur.strategy, acceptMinutes: Math.min(120, Math.max(1, Number(b.acceptMinutes) || cur.acceptMinutes)), autoReassign: !!b.autoReassign, sla: { ...d.sla }, business: { ...cur.business } };
    for (const k of Object.keys(d.sla)) next.sla[k] = Math.min(10080, Math.max(5, Number(b.sla?.[k]) || cur.sla[k]));
    const bh = b.business;
    if (bh && typeof bh === 'object') {
      const t = /^([01]\d|2[0-3]):[0-5]\d$/;
      const days = Array.isArray(bh.days) ? [...new Set(bh.days.map(Number).filter((x) => Number.isInteger(x) && x >= 0 && x <= 6))] : cur.business.days;
      const start = t.test(bh.start) ? bh.start : cur.business.start, end = t.test(bh.end) ? bh.end : cur.business.end;
      if (!!bh.enabled && (start >= end || !days.length)) throw new HttpError(400, 'ساعات العمل غير صالحة: يجب أن تسبق البداية النهاية ويُختار يوم واحد على الأقل');
      next.business = { enabled: !!bh.enabled, tz: validTz(bh.tz) ? bh.tz : cur.business.tz, start, end, days, urgent24x7: !!bh.urgent24x7 };
    }
    kvSet('ticketSettings', next); emit('settings', {}); return next;
  }
  return { create, ops, sweep, listFor, agents, settings, setSettings, kvGet, kvSet, load, store, insert, slaInfo, pickAgent, assign, log, get };
}
