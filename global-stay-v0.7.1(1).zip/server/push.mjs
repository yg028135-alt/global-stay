// Web Push (RFC 8030 + VAPID RFC 8292 + تشفير aes128gcm RFC 8291) بدون أي مكتبات خارجية
import { generateKeyPairSync, createPrivateKey, createECDH, sign, randomBytes, hkdfSync, createCipheriv } from 'node:crypto';
const b64u = (buf) => Buffer.from(buf).toString('base64url');
const unb64u = (s) => Buffer.from(s, 'base64url');

export function makeVapid(kvGet, kvSet) {
  let k = kvGet('vapid', null);
  if (!k) {
    const { publicKey, privateKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
    const j = publicKey.export({ format: 'jwk' });
    k = { pub: b64u(Buffer.concat([Buffer.from([4]), unb64u(j.x), unb64u(j.y)])), priv: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
    kvSet('vapid', k);
  }
  return k;
}
export function vapidHeader(endpoint, vapid, subject) {
  const aud = new URL(endpoint).origin;
  const head = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' })), claims = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject }));
  const sig = sign('sha256', Buffer.from(`${head}.${claims}`), { key: createPrivateKey(vapid.priv), dsaEncoding: 'ieee-p1363' });
  return `vapid t=${head}.${claims}.${b64u(sig)}, k=${vapid.pub}`;
}
export function encryptPayload(payload, p256dh, authSecret) {
  const uaPub = unb64u(p256dh), auth = unb64u(authSecret);
  const ecdh = createECDH('prime256v1'); ecdh.generateKeys();
  const asPub = ecdh.getPublicKey(), secret = ecdh.computeSecret(uaPub), salt = randomBytes(16);
  const ikm = Buffer.from(hkdfSync('sha256', secret, auth, Buffer.concat([Buffer.from('WebPush: info\0'), uaPub, asPub]), 32));
  const cek = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16));
  const nonce = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12));
  const cipher = createCipheriv('aes-128-gcm', cek, nonce);
  const ct = Buffer.concat([cipher.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), cipher.final(), cipher.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPub.length]), asPub, ct]);
}
const privateHost = /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1\]?$|0\.0\.0\.0)/i;
export function validEndpoint(ep, allowHttp = false) {
  try { const u = new URL(ep); if (ep.length > 600) return false; if (allowHttp && u.protocol === 'http:' && /^(127\.0\.0\.1|localhost)$/.test(u.hostname)) return true; return u.protocol === 'https:' && !privateHost.test(u.hostname); } catch { return false; }
}

export function makePush({ db, kvGet, kvSet, subject = 'mailto:admin@example.com' }) {
  const vapid = makeVapid(kvGet, kvSet);
  const allowHttp = process.env.PUSH_ALLOW_HTTP === '1';
  async function sendTo(userId, message) {
    const subs = db.prepare('SELECT * FROM push_subs WHERE user_id=?').all(userId);
    const body = JSON.stringify(message);
    await Promise.all(subs.map(async (s) => {
      try {
        const res = await fetch(s.endpoint, { method: 'POST', signal: AbortSignal.timeout(8000), headers: { 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', TTL: '3600', Urgency: 'high', Authorization: vapidHeader(s.endpoint, vapid, subject) }, body: encryptPayload(body, s.p256dh, s.auth) });
        if (res.status === 404 || res.status === 410) db.prepare('DELETE FROM push_subs WHERE endpoint=?').run(s.endpoint);
      } catch (e) { console.error('push failed:', e.message); }
    }));
  }
  const subscribe = (userId, sub) => {
    const ep = sub?.endpoint, p = sub?.keys?.p256dh, a = sub?.keys?.auth;
    if (!validEndpoint(ep, allowHttp) || typeof p !== 'string' || typeof a !== 'string' || p.length > 200 || a.length > 60) return false;
    db.prepare('INSERT INTO push_subs(endpoint,user_id,p256dh,auth,created_at) VALUES(?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth').run(ep, userId, p, a, new Date().toISOString());
    return true;
  };
  const unsubscribe = (userId, endpoint) => db.prepare('DELETE FROM push_subs WHERE endpoint=? AND user_id=?').run(String(endpoint || ''), userId);
  return { publicKey: vapid.pub, sendTo, subscribe, unsubscribe };
}
