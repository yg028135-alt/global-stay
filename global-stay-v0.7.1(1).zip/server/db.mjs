import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';

export function openDb(dir) {
  mkdirSync(dir, { recursive: true });
  const db = new DatabaseSync(join(dir, 'globalstay.db'));
  db.exec(`
    PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=3000;
    CREATE TABLE IF NOT EXISTS users(
      id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE, name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN('manager','agent')), dept TEXT,
      pass_salt TEXT NOT NULL, pass_hash TEXT NOT NULL,
      online INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(
      token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS tickets(
      id TEXT PRIMARY KEY, seq INTEGER NOT NULL, status TEXT NOT NULL, department TEXT NOT NULL,
      agent_id TEXT, created_at TEXT NOT NULL, data TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_tickets_agent ON tickets(agent_id, status);
    CREATE INDEX IF NOT EXISTS idx_tickets_created ON tickets(created_at);
    CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, ticket_id TEXT, kind TEXT, text TEXT NOT NULL,
      created_at TEXT NOT NULL, read INTEGER NOT NULL DEFAULT 0);
    CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, read);
    CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY, ord INTEGER NOT NULL, status TEXT, data TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY, ord INTEGER NOT NULL, status TEXT, data TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, ord INTEGER NOT NULL, status TEXT, data TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
    CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
    CREATE TABLE IF NOT EXISTS push_subs(endpoint TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, p256dh TEXT NOT NULL, auth TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_push_user ON push_subs(user_id);
    CREATE TABLE IF NOT EXISTS properties(
      id TEXT PRIMARY KEY, name TEXT NOT NULL, address TEXT NOT NULL DEFAULT '', city TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT 'Egypt', timezone TEXT NOT NULL DEFAULT 'Africa/Cairo', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS units(
      id TEXT PRIMARY KEY, property_id TEXT NOT NULL REFERENCES properties(id), code TEXT NOT NULL, unit_type TEXT NOT NULL DEFAULT 'apartment', bedrooms INTEGER NOT NULL DEFAULT 1 CHECK(bedrooms>=0), bathrooms INTEGER NOT NULL DEFAULT 1 CHECK(bathrooms>=0), capacity INTEGER NOT NULL DEFAULT 2 CHECK(capacity>0), floor TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'ready' CHECK(status IN('ready','occupied','cleaning','maintenance','inactive')), default_currency TEXT NOT NULL DEFAULT 'EGP', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, UNIQUE(property_id,code));
    CREATE INDEX IF NOT EXISTS idx_units_property ON units(property_id,status);
    CREATE TABLE IF NOT EXISTS guests(
      id TEXT PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', nationality TEXT NOT NULL DEFAULT '', document_type TEXT NOT NULL DEFAULT '', document_last4 TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_guests_name ON guests(full_name);
    CREATE TABLE IF NOT EXISTS reservations(
      id TEXT PRIMARY KEY, property_id TEXT NOT NULL REFERENCES properties(id), unit_id TEXT NOT NULL REFERENCES units(id), guest_id TEXT NOT NULL REFERENCES guests(id), check_in TEXT NOT NULL, check_out TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN('pending','confirmed','checked_in','checked_out','cancelled')), source TEXT NOT NULL DEFAULT 'direct', currency TEXT NOT NULL DEFAULT 'EGP', nightly_rate_minor INTEGER NOT NULL CHECK(nightly_rate_minor>=0), nights INTEGER NOT NULL CHECK(nights>0), subtotal_minor INTEGER NOT NULL, commission_rate REAL NOT NULL DEFAULT 10, commission_minor INTEGER NOT NULL, total_minor INTEGER NOT NULL, adults INTEGER NOT NULL DEFAULT 1, children INTEGER NOT NULL DEFAULT 0, notes TEXT NOT NULL DEFAULT '', created_by TEXT REFERENCES users(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL, CHECK(check_out>check_in));
    CREATE INDEX IF NOT EXISTS idx_reservations_unit_dates ON reservations(unit_id,check_in,check_out,status);
    CREATE INDEX IF NOT EXISTS idx_reservations_guest ON reservations(guest_id,created_at);
    CREATE TABLE IF NOT EXISTS folio_entries(
      id TEXT PRIMARY KEY, reservation_id TEXT NOT NULL REFERENCES reservations(id), entry_type TEXT NOT NULL CHECK(entry_type IN('stay_payment','stay_charge','deposit_received','deposit_refund','adjustment')), amount_minor INTEGER NOT NULL CHECK(amount_minor>0), currency TEXT NOT NULL, method TEXT NOT NULL DEFAULT '', reference TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '', created_by TEXT REFERENCES users(id), created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_folio_reservation ON folio_entries(reservation_id,created_at);
    CREATE TABLE IF NOT EXISTS expenses(
      id TEXT PRIMARY KEY, property_id TEXT REFERENCES properties(id), category TEXT NOT NULL, description TEXT NOT NULL,
      amount_minor INTEGER NOT NULL CHECK(amount_minor>0), currency TEXT NOT NULL CHECK(currency IN('EGP','USD','EUR','SAR')),
      payment_method TEXT NOT NULL DEFAULT 'cash', status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN('pending','approved','rejected','paid')),
      requested_by TEXT NOT NULL REFERENCES users(id), approved_by TEXT REFERENCES users(id), paid_by TEXT REFERENCES users(id),
      notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, approved_at TEXT, paid_at TEXT);
    CREATE INDEX IF NOT EXISTS idx_expenses_status_date ON expenses(status,created_at);
    CREATE TABLE IF NOT EXISTS cash_closings(
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), business_date TEXT NOT NULL, currency TEXT NOT NULL,
      cash_in_minor INTEGER NOT NULL, cash_out_minor INTEGER NOT NULL, expected_minor INTEGER NOT NULL,
      counted_minor INTEGER NOT NULL, difference_minor INTEGER NOT NULL, notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
      UNIQUE(user_id,business_date,currency));
    CREATE INDEX IF NOT EXISTS idx_cash_closings_date ON cash_closings(business_date,currency);
    CREATE TABLE IF NOT EXISTS owners(
      id TEXT PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', national_id_last4 TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_owners_name ON owners(full_name);
    CREATE TABLE IF NOT EXISTS property_owners(
      id TEXT PRIMARY KEY, property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE CASCADE, owner_id TEXT NOT NULL REFERENCES owners(id), share_percent REAL NOT NULL CHECK(share_percent>0 AND share_percent<=100), created_at TEXT NOT NULL, UNIQUE(property_id,owner_id));
    CREATE INDEX IF NOT EXISTS idx_property_owners_property ON property_owners(property_id);
    CREATE TABLE IF NOT EXISTS document_counters(document_type TEXT PRIMARY KEY CHECK(document_type IN('invoice','receipt')), next_number INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS reservation_documents(
      id TEXT PRIMARY KEY, reservation_id TEXT NOT NULL REFERENCES reservations(id), folio_entry_id TEXT REFERENCES folio_entries(id), document_type TEXT NOT NULL CHECK(document_type IN('invoice','receipt')), document_number TEXT NOT NULL UNIQUE, issued_by TEXT REFERENCES users(id), issued_at TEXT NOT NULL);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_reservation_invoice_once ON reservation_documents(reservation_id) WHERE document_type='invoice';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_reservation_receipt_once ON reservation_documents(folio_entry_id) WHERE document_type='receipt' AND folio_entry_id IS NOT NULL;
    CREATE TABLE IF NOT EXISTS owner_settlements(
      id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES owners(id), property_id TEXT NOT NULL REFERENCES properties(id), period_from TEXT NOT NULL, period_to TEXT NOT NULL, currency TEXT NOT NULL CHECK(currency IN('EGP','USD','EUR','SAR')), amount_minor INTEGER NOT NULL CHECK(amount_minor>0), method TEXT NOT NULL, reference TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', paid_by TEXT NOT NULL REFERENCES users(id), paid_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_owner_settlements_period ON owner_settlements(owner_id,property_id,period_from,period_to,currency);
    CREATE TABLE IF NOT EXISTS reservation_transfers(
      id TEXT PRIMARY KEY, reservation_id TEXT NOT NULL REFERENCES reservations(id), from_unit_id TEXT NOT NULL REFERENCES units(id), to_unit_id TEXT NOT NULL REFERENCES units(id), moved_by TEXT REFERENCES users(id), reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_reservation_transfers_reservation ON reservation_transfers(reservation_id,created_at);
    CREATE TABLE IF NOT EXISTS pms_housekeeping_tasks(
      id TEXT PRIMARY KEY, reservation_id TEXT NOT NULL REFERENCES reservations(id), property_id TEXT NOT NULL REFERENCES properties(id), unit_id TEXT NOT NULL REFERENCES units(id), task_type TEXT NOT NULL DEFAULT 'checkout_cleaning', status TEXT NOT NULL DEFAULT 'open' CHECK(status IN('open','in_progress','done')), priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN('normal','urgent')), notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, completed_at TEXT, completed_by TEXT REFERENCES users(id));
    CREATE INDEX IF NOT EXISTS idx_pms_housekeeping_status ON pms_housekeeping_tasks(status,created_at);
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, user_id TEXT, action TEXT NOT NULL, detail TEXT, ip TEXT);
  `);
  return db;
}

// المعاملات متزامنة (node:sqlite) فتكون كل عملية ذرّية ما دامت بلا await داخلها
export function makeTx(db) {
  return (fn) => {
    db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); db.exec('COMMIT'); return r; }
    catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
  };
}
