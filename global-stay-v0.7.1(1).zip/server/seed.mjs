// بيانات تجريبية اختيارية (SEED_DEMO=1): موظفون وتذاكر بتواريخ نسبية للوقت الحالي
import { CATS, DEPTS, PRI } from './tickets.mjs';
const M = 60000;
const iso = (ms) => new Date(ms).toISOString();
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const TITLES = {
  complaint: ['شكوى من ضوضاء الغرفة المجاورة', 'شكوى من تأخر خدمة الغرف', 'شكوى حول بند في فاتورة الإقامة'],
  inquiry: ['استفسار عن مواعيد الإفطار', 'استفسار عن خدمة النقل للمطار', 'استفسار عن سياسة الإلغاء'],
  booking: ['حجز جناح تنفيذي لثلاث ليالٍ', 'تعديل تاريخ حجز قائم', 'تأكيد حجز مجموعة'],
  checkin: ['تسكين نزيل جديد', 'تسكين مبكر قبل موعد الوصول', 'نقل نزيل إلى غرفة أخرى'],
  checkout: ['إجراءات مغادرة النزيل', 'طلب تمديد وقت المغادرة', 'تسوية الحساب قبل المغادرة'],
  maintenance: ['المكيف لا يبرد', 'تسريب مياه في الحمام', 'عطل في قفل الباب'],
  cleaning: ['تنظيف عاجل بعد المغادرة', 'تغيير مفروشات الغرفة', 'تنظيف ممرات الدور'],
  preparation: ['تجهيز غرفة لوصول ضيف VIP', 'تجهيز قاعة اجتماعات', 'تجهيز سرير إضافي']
};
export const DEMO_AGENTS = [
  ['agent_1', 'salma', 'سلمى', 'customer_service'], ['agent_2', 'hoda', 'هدى', 'customer_service'],
  ['agent_3', 'omar', 'عمر', 'reception'], ['agent_4', 'laila', 'ليلى', 'reception'],
  ['agent_5', 'mona', 'منى', 'operations'], ['agent_6', 'hossam', 'حسام', 'operations'], ['agent_7', 'yasser', 'ياسر', 'operations']
];
export function seedTickets(engine, rooms) {
  const n = Date.now(), R = rng(20261120), S = engine.settings();
  const prof = { agent_1: [0.8, 0.7], agent_2: [1.4, 1.0], agent_3: [0.7, 0.6], agent_4: [1.0, 0.9], agent_5: [1.6, 1.1], agent_6: [0.9, 0.8], agent_7: [1.2, 1.2] };
  const names = Object.fromEntries(DEMO_AGENTS.map((a) => [a[0], { name: a[2], dept: a[3] }]));
  const pick = (a) => a[Math.floor(R() * a.length)];
  const specs = [], cats = Object.keys(CATS);
  for (let i = 0; i < 36; i++) {
    const w = R(), priority = w < 0.12 ? 'urgent' : w < 0.37 ? 'high' : w < 0.77 ? 'medium' : 'low';
    const category = pick(cats), dept = CATS[category][1];
    const ag = pick(DEMO_AGENTS.filter((a) => a[3] === dept)), [fa, fw] = prof[ag[0]];
    specs.push({ createdAgo: Math.pow(R(), 1.6) * 12 * 24 * 60 + 20, category, priority, agent: ag[0], acceptDelay: (1 + R() * 5) * fa, work: S.sla[priority] * (0.15 + R() * 1.25) * fw, hold: R() < 0.12 ? 10 + Math.round(R() * 50) : 0 });
  }
  specs.push({ createdAgo: 52, category: 'maintenance', priority: 'urgent', agent: 'agent_6', acceptDelay: 3, work: 90, hold: 0, title: 'انقطاع الكهرباء عن غرفة مشغولة' });
  specs.push({ createdAgo: 100, category: 'complaint', priority: 'high', agent: 'agent_1', acceptDelay: 2, work: 140, hold: 0, title: 'شكوى من تأخر استلام الأمتعة' });
  specs.push({ createdAgo: 1.2, category: 'maintenance', priority: 'urgent', agent: 'agent_5', acceptDelay: 99999, work: 20, hold: 0, title: 'تسريب مياه في جناح الدور الثاني' });
  specs.push({ createdAgo: 7.5, category: 'complaint', priority: 'high', agent: 'agent_2', acceptDelay: 99999, work: 60, hold: 0, title: 'شكوى عاجلة من نزيل بخصوص الإزعاج' });
  specs.push({ createdAgo: 95, category: 'checkin', priority: 'medium', agent: 'agent_4', acceptDelay: 4, work: 200, hold: 120, title: 'تسكين مجموعة — بانتظار مستندات النزلاء' });
  specs.sort((a, b) => b.createdAgo - a.createdAgo);
  specs.forEach((p, i) => {
    const title = p.title || pick(TITLES[p.category]);
    const room = ['maintenance', 'cleaning', 'preparation', 'checkin', 'checkout', 'complaint'].includes(p.category) && R() < 0.7 && rooms.length ? pick(rooms) : '';
    const sla = S.sla[p.priority];
    const created = n - p.createdAgo * M, assigned = created + 0.2 * M, accepted = assigned + p.acceptDelay * M, started = accepted + 2 * M;
    const holdStart = p.hold ? started + Math.min(p.work * 0.3, 15) * M : 0, holdEnd = holdStart + p.hold * M;
    const resolveAt = started + p.work * M + p.hold * M, ag = names[p.agent];
    const t = { id: `TKT-${1001 + i}`, title, description: `${title}${room ? ` — غرفة ${room}` : ''}. تم تسجيل الطلب عبر نظام التذاكر.`, category: p.category, priority: p.priority, department: CATS[p.category][1], room, assignedAgentId: p.agent, status: 'assigned', slaMinutes: sla,
      timestamps: { createdAt: iso(created), assignedAt: iso(assigned), acceptedAt: null, startedAt: null, heldAt: null, resolvedAt: null, slaDeadline: iso(created + sla * M) }, slaStatus: 'on_track', activityLog: [] };
    const L = (at, type, actor, text) => t.activityLog.push({ at: iso(at), type, actor, text });
    L(created, 'created', 'مريم حسن', `إنشاء التيكيت — التصنيف: ${CATS[p.category][0]}`);
    L(created, 'route', 'النظام', `توجيه تلقائي إلى قسم ${DEPTS[t.department]}`);
    L(assigned, 'assigned', 'النظام', `إسناد تلقائي ← ${ag.name}`);
    if (accepted <= n) { t.status = 'accepted'; t.timestamps.acceptedAt = iso(accepted); L(accepted, 'accepted', ag.name, 'قبول الطلب (Accept Ticket)'); }
    if (started <= n && t.status === 'accepted') { t.status = 'in_progress'; t.timestamps.startedAt = iso(started); L(started, 'started', ag.name, 'بدء التنفيذ'); }
    if (p.hold && holdStart <= n && t.status === 'in_progress') {
      L(holdStart, 'hold', ag.name, 'تعليق الطلب — في انتظار رد العميل');
      if (holdEnd <= n) { L(holdEnd, 'resume', ag.name, 'استئناف العمل'); t.timestamps.slaDeadline = iso(Date.parse(t.timestamps.slaDeadline) + p.hold * M); t.pausedMs = p.hold * M; }
      else { t.status = 'on_hold'; t.timestamps.heldAt = iso(holdStart); }
    }
    if (resolveAt <= n && t.status === 'in_progress') {
      t.status = 'resolved'; t.timestamps.resolvedAt = iso(resolveAt); t.resolution = 'تم تنفيذ الطلب وتأكيد الحل مع الجهة الطالبة.';
      L(resolveAt, 'resolved', ag.name, `إغلاق الطلب — ملخص الحل: ${t.resolution}`);
      t.slaStatus = resolveAt > Date.parse(t.timestamps.slaDeadline) ? 'breached' : 'on_track';
    }
    engine.insert(t);
  });
}
