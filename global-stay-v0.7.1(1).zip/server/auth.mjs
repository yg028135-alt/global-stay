import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';

export const hashPassword = (pw, salt = randomBytes(16).toString('hex')) =>
  ({ salt, hash: scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex') });
export function verifyPassword(pw, salt, hash) {
  const a = Buffer.from(hashPassword(pw, salt).hash, 'hex'), b = Buffer.from(hash, 'hex');
  return a.length === b.length && timingSafeEqual(a, b);
}
export const sha256 = (s) => createHash('sha256').update(s).digest('hex');
export const newToken = () => randomBytes(32).toString('base64url');
export const newId = (p) => `${p}_${randomBytes(5).toString('hex')}`;
export const randomPassword = (n = 12) => { const c = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'; return Array.from(randomBytes(n), (b) => c[b % c.length]).join(''); };

// محدّد معدل بسيط في الذاكرة
export function makeLimiter(max, windowMs) {
  const hits = new Map();
  return {
    blocked(key) { const now = Date.now(); const a = (hits.get(key) || []).filter((t) => now - t < windowMs); hits.set(key, a); return a.length >= max; },
    hit(key) { const a = hits.get(key) || []; a.push(Date.now()); hits.set(key, a); },
    clear(key) { hits.delete(key); },
    sweep() { const now = Date.now(); for (const [k, a] of hits) { const f = a.filter((t) => now - t < windowMs); f.length ? hits.set(k, f) : hits.delete(k); } }
  };
}
