const form = document.querySelector('#req-form'), err = document.querySelector('#err'), ok = document.querySelector('#ok');
const room = new URLSearchParams(location.search).get('room');
if (room) form.room.value = room.slice(0, 8);
form.addEventListener('submit', async (e) => {
  e.preventDefault(); err.hidden = true;
  const btn = form.querySelector('button[type=submit]'); btn.disabled = true;
  try {
    const body = Object.fromEntries(new FormData(form).entries());
    const r = await fetch('/api/public/request', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'gs' }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'تعذر إرسال الطلب');
    document.querySelector('#tid').textContent = d.ticketId || '';
    form.hidden = true; ok.hidden = false;
  } catch (x) { err.textContent = x.message; err.hidden = false; }
  btn.disabled = false;
});
document.querySelector('#again').addEventListener('click', () => { form.message.value = ''; form.hidden = false; ok.hidden = true; });
