const form = document.querySelector('#login-form'), err = document.querySelector('#err');
fetch('/api/me', { credentials: 'same-origin' }).then((r) => { if (r.ok) location.replace('/'); }).catch(() => {});
form.addEventListener('submit', async (e) => {
  e.preventDefault(); err.hidden = true;
  const btn = form.querySelector('button'); btn.disabled = true;
  try {
    const r = await fetch('/api/login', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'gs' }, body: JSON.stringify({ username: form.username.value, password: form.password.value }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'تعذر تسجيل الدخول');
    location.replace('/');
  } catch (x) { err.textContent = x.message; err.hidden = false; btn.disabled = false; }
});
