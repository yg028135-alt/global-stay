/* Global Stay — نظام التذاكر و SLA
 * يعمل فوق app.js دون تعديل بنية التخزين: البيانات تُحفظ في state.data (tickets / agents / ticketSettings)
 * ويُحفظ كل شيء في نفس مفتاح LocalStorage الحالي. يُحمَّل هذا الملف بعد app.js. */
(() => {
'use strict';
const M = 60000;
const DAY = 24 * 60 * M;

/* ---------- ثوابت النظام ---------- */
const DEPTS = {
  customer_service: { label: 'خدمة العملاء', en: 'Customer Service', color: 'var(--cyan)' },
  reception: { label: 'الاستقبال', en: 'Reception', color: 'var(--blue)' },
  operations: { label: 'إدارة التشغيل', en: 'Operations Management', color: 'var(--amber)' }
};
// التصنيف -> القسم المختص (Auto-Routing)
const CATS = {
  complaint: { label: 'شكوى', dept: 'customer_service' },
  inquiry: { label: 'استفسار', dept: 'customer_service' },
  booking: { label: 'حجز', dept: 'reception' },
  checkin: { label: 'تسكين', dept: 'reception' },
  checkout: { label: 'مغادرة', dept: 'reception' },
  maintenance: { label: 'صيانة', dept: 'operations' },
  cleaning: { label: 'نظافة', dept: 'operations' },
  preparation: { label: 'تجهيز', dept: 'operations' }
};
const PRI = {
  urgent: { label: 'عاجل', en: 'Urgent', color: 'var(--red)' },
  high: { label: 'مرتفع', en: 'High', color: 'var(--amber)' },
  medium: { label: 'متوسط', en: 'Medium', color: 'var(--blue)' },
  low: { label: 'منخفض', en: 'Low', color: 'var(--muted)' }
};
const ST = {
  new: { label: 'بانتظار الإسناد', color: 'var(--muted)' },
  assigned: { label: 'تم الإسناد', color: 'var(--amber)' },
  accepted: { label: 'تم القبول', color: 'var(--cyan)' },
  in_progress: { label: 'قيد التنفيذ', color: 'var(--blue)' },
  on_hold: { label: 'معلق', color: 'var(--purple)' },
  resolved: { label: 'تم التنفيذ', color: 'var(--green)' }
};
const TONE = { green: 'var(--green)', gold: 'var(--gold)', amber: 'var(--amber)', red: 'var(--red)', muted: 'var(--muted)' };

const TK = { filter: 'active', dept: 'all', period: 'weekly', from: '', to: '' };

/* ---------- أدوات مساعدة ---------- */
const D = () => state.data;
const esc = (v) => escapeHtml(v);
const iso = (ms) => new Date(ms).toISOString();
const ms = (s) => Date.parse(s);
const find = (id) => D().tickets.find((t) => t.id === id);
const agentOf = (id) => D().agents.find((a) => a.id === id);
const isActive = (t) => t.status !== 'resolved';
const clock = (v) => { const s = Math.floor(Math.abs(v) / 1000); return `${Math.floor(s / 3600)}:${String(Math.floor(s % 3600 / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
function human(v) {
  if (v == null || Number.isNaN(v)) return '—';
  const m = Math.round(v / M);
  if (m < 1) return 'أقل من دقيقة';
  if (m < 60) return `${m} د`;
  const h = Math.floor(m / 60), r = m % 60;
  if (h < 24) return r ? `${h} س ${r} د` : `${h} س`;
  return `${Math.floor(h / 24)} ي ${h % 24} س`;
}
const stamp = (s) => s ? new Date(s).toLocaleString('ar-EG-u-nu-latn', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
const ago = (s) => { const d = nowMs() - ms(s); return d < M ? 'الآن' : `منذ ${human(d)}`; };
const pct = (v) => v == null ? '—' : `${Math.round(v * 100)}%`;
const avg = (arr) => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null;


/* ---------- محرك SLA ---------- */
function slaInfo(t, now = nowMs()) {
  const total = t.slaSpanMs || t.slaMinutes * M;
  const deadline = ms(t.timestamps.slaDeadline);
  const done = t.status === 'resolved';
  const paused = t.status === 'on_hold' && !!t.timestamps.heldAt;
  const ref = done ? ms(t.timestamps.resolvedAt) : paused ? ms(t.timestamps.heldAt) : now;
  const remaining = deadline - ref;
  const ratio = Math.max(0, Math.min(1, remaining / total));
  const level = remaining < 0 ? 'breached' : ratio < 0.25 ? 'warning' : 'on_track';
  const tone = remaining < 0 ? 'red' : ratio < 0.25 ? 'amber' : ratio < 0.5 ? 'gold' : 'green';
  return { remaining, ratio, level, tone, paused, done };
}
const isBreached = (t) => t.status === 'resolved' ? ms(t.timestamps.resolvedAt) > ms(t.timestamps.slaDeadline) : (!!t.breachedAt || slaInfo(t).remaining < 0);
function accInfo(t, now = nowMs()) {
  const left = ms(t.timestamps.assignedAt) + D().ticketSettings.acceptMinutes * M - now;
  return { left, overdue: left < 0 };
}
function slaBlock(t) {
  const s = slaInfo(t);
  const label = s.done ? (s.level === 'breached' ? 'أُغلق بعد انتهاء SLA' : 'أُغلق ضمن SLA')
    : s.paused ? 'SLA متوقف مؤقتًا'
    : s.level === 'breached' ? 'SLA Breached — تم تجاوز الوقت'
    : s.level === 'warning' ? 'اقتراب انتهاء SLA' : 'SLA — الوقت آمن';
  const time = `${s.remaining < 0 ? '−' : ''}${clock(s.remaining)}`;
  return `<div class="tk-sla tk-${s.tone}"><div class="tk-sla-top"><span>${label}</span><b class="tk-clock">${time}</b></div><div class="tk-bar"><i style="width:${Math.round(s.ratio * 100)}%"></i></div></div>`;
}
function accBlock(t) {
  if (t.status !== 'assigned') return '';
  const a = accInfo(t);
  return `<div class="tk-acc ${a.overdue ? 'late' : ''}"><span>${a.overdue ? 'تأخر في القبول' : 'مهلة القبول'}</span><b class="tk-clock">${a.overdue ? '−' : ''}${clock(a.left)}</b></div>`;
}
const slaWrap = (t) => `<div class="tk-live" ${isActive(t) && t.status !== 'on_hold' ? `data-sla-id="${t.id}"` : ''}>${slaBlock(t)}</div>`;
const accWrap = (t) => t.status === 'assigned' ? `<div class="tk-live" data-acc-id="${t.id}">${accBlock(t)}</div>` : '';

/* ---------- الاتصال بالخادم (الخادم هو مصدر الحقيقة والوقت) ---------- */
const _dn = Date.now.bind(Date);
const nowMs = () => _dn() + (window.GS?.offset || 0);
const me = () => GS.me;
const isMgr = () => GS.me.role === 'manager';
const canAct = (t) => isMgr() || t.assignedAgentId === me().id;
const viewerName = () => me().name;
function merge(t) { const i = D().tickets.findIndex((x) => x.id === t.id); if (i >= 0) D().tickets[i] = t; else D().tickets.unshift(t); }
let refreshing = false;
async function refresh() {
  if (refreshing) return; refreshing = true;
  try {
    const d = await api('GET', '/api/tickets');
    GS.offset = d.now - _dn(); D().tickets = d.tickets; D().agents = d.agents;
    const el = document.activeElement, typing = el && el !== document.body && /INPUT|SELECT|TEXTAREA/.test(el.tagName);
    if (['tickets', 'reports', 'dashboard'].includes(state.view) && !typing) render(); else updateCounts();
  } catch { /* سيُعاد الاتصال تلقائيًا */ }
  refreshing = false;
}
async function call(path, body, id) {
  try {
    const d = await api('POST', `/api/tickets${path}`, body || {});
    if (d.ticket) merge(d.ticket);
    render(); if (id && modalRoot.querySelector('.tk-modal')) openDetail(id);
    return d.ticket;
  } catch (e) { showToast(e.message); refresh(); }
}
const doAccept = (id) => call(`/${id}/accept`, {}, id).then((t) => t && showToast(`تم قبول ${id}`));
const doStart = (id) => call(`/${id}/start`, {}, id);
const doHold = (id, reason) => call(`/${id}/hold`, { reason }, id);
const doResume = (id) => call(`/${id}/resume`, {}, id);
const doResolve = (id, summary) => call(`/${id}/resolve`, { summary }, id).then((t) => t && showToast(`تم إغلاق ${id}`));
const doTransfer = (id, dept, reason) => call(`/${id}/transfer`, { dept, reason }, id);
const doReassign = (id) => call(`/${id}/reassign`, {}, id);
const doNote = (id, text) => call(`/${id}/note`, { text }, id);
async function fromRequest(id) {
  const r = D().requests.find((x) => x.id === id); if (!r || r.ticketId) return;
  const category = { housekeeping: 'cleaning', maintenance: 'maintenance', food: 'preparation', guest: 'inquiry' }[r.type] || 'inquiry';
  const priority = { urgent: 'urgent', high: 'high', normal: 'medium', low: 'low' }[r.priority] || 'medium';
  try {
    const d = await api('POST', '/api/tickets', { title: r.title, description: `${r.description || ''} (من الطلب ${r.id})`.trim(), category, priority, room: r.room, fromRequest: r.id });
    r.ticketId = d.ticket.id; save(); showToast(`تم إنشاء ${d.ticket.id} → ${DEPTS[d.ticket.department].label}`); refresh(); render();
  } catch (e) { showToast(e.message); }
}
function tickDom() {
  document.querySelectorAll('[data-sla-id]').forEach((el) => { const t = find(el.dataset.slaId); if (t) el.innerHTML = slaBlock(t); });
  document.querySelectorAll('[data-acc-id]').forEach((el) => { const t = find(el.dataset.accId); if (t) el.innerHTML = accBlock(t); });
}

/* ---------- الواجهة: التذاكر ---------- */
const deptChip = (d) => `<span class="tk-dept-chip" style="--c:${DEPTS[d].color}">${DEPTS[d].label}</span>`;
const stBadge = (s) => `<span class="status-badge" style="--badge-color:${ST[s].color};--badge-bg:color-mix(in srgb,${ST[s].color} 9%,transparent)"><i></i>${ST[s].label}</span>`;
const priBadge = (p) => `<span class="priority-badge" style="--badge-color:${PRI[p].color};--badge-bg:color-mix(in srgb,${PRI[p].color} 9%,transparent)">${PRI[p].label}</span>`;
function visibleTickets() { return D().tickets; }
function sortTickets(list) {
  const n = nowMs();
  return [...list].sort((a, b) => (isActive(b) - isActive(a)) || (isActive(a) ? slaInfo(a, n).remaining - slaInfo(b, n).remaining : ms(b.timestamps.resolvedAt) - ms(a.timestamps.resolvedAt)));
}
function filterMatch(t) {
  const f = TK.filter;
  const ok = f === 'all' || (f === 'active' && isActive(t)) || (f === 'assigned' && ['new', 'assigned'].includes(t.status)) || (f === 'working' && ['accepted', 'in_progress'].includes(t.status)) || t.status === f;
  return ok && (TK.dept === 'all' || t.department === TK.dept);
}
function primaryAction(t) {
  const b = (a, label, cls = 'primary') => `<button class="btn small ${cls}" data-tk-act="${a}" data-id="${t.id}">${label}</button>`;
  if (t.status === 'assigned') return b('accept', `${icon('check')}قبول الطلب (Accept Ticket)`) + (accInfo(t).overdue ? b('reassign', 'إعادة توجيه', '') : '');
  if (t.status === 'accepted') return b('start', 'بدء التنفيذ');
  if (t.status === 'in_progress') return b('resolve-form', 'إغلاق الطلب');
  if (t.status === 'on_hold') return b('resume', 'استئناف');
  return '';
}
function ticketCard(t) {
  const ag = agentOf(t.assignedAgentId);
  return `<article class="tk-card ${isBreached(t) && isActive(t) ? 'is-breached' : ''}" data-tk-act="open" data-id="${t.id}" tabindex="0">
  <div class="tk-card-main">
    <div class="tk-card-head"><span class="tk-id">${esc(t.id)}</span>${priBadge(t.priority)}${stBadge(t.status)}${deptChip(t.department)}<span class="tk-cat">${CATS[t.category].label}</span></div>
    <h3>${esc(t.title)}</h3>
    <p>${esc(t.description || '')}</p>
    <div class="tk-meta"><span>${ag ? `<i class="tk-avatar">${esc(ag.name[0])}</i>${esc(ag.name)}` : 'غير مُسند'}</span>${t.room ? `<span>غرفة ${esc(t.room)}</span>` : ''}<span>${ago(t.timestamps.createdAt)}</span>${t.transfers ? `<span>محوَّل ×${t.transfers}</span>` : ''}</div>
  </div>
  <div class="tk-card-side">${slaWrap(t)}${accWrap(t)}<div class="tk-card-actions">${primaryAction(t)}<button class="btn small ghost" data-tk-act="open" data-id="${t.id}">التفاصيل</button></div></div>
</article>`;
}
function kpi(label, value, unit, foot, iconName, color) {
  return kpiCard(label, value, unit, foot, '—', iconName, color, 'M2 20 C12 16,18 19,26 13 S40 15,48 9 S62 12,78 4');
}
function renderTickets() {
  const all = visibleTickets(), n = nowMs();
  const act = all.filter(isActive);
  const KPI = [
    kpi('تذاكر نشطة', act.length, 'تيكيت', 'غير مُغلقة حاليًا', 'ticket', 'var(--blue)'),
    kpi('بانتظار القبول', act.filter((t) => t.status === 'assigned').length, 'تيكيت', `منها ${act.filter((t) => t.status === 'assigned' && accInfo(t, n).overdue).length} متأخر في القبول`, 'clock', 'var(--amber)'),
    kpi('اقتراب انتهاء SLA', act.filter((t) => slaInfo(t, n).level === 'warning').length, 'تيكيت', 'أقل من 25% من الوقت', 'flag', 'var(--gold)'),
    kpi('تجاوز SLA', act.filter((t) => slaInfo(t, n).level === 'breached').length, 'تيكيت', 'تحتاج تدخلاً فوريًا', 'shield', 'var(--red)')
  ].join('');
  const S = D().ticketSettings;
  const depts = Object.entries(DEPTS).map(([k, d]) => {
    const list = D().tickets.filter((t) => t.department === k && isActive(t));
    const ags = D().agents.filter((a) => a.dept === k).map((a) => {
      const load = D().tickets.filter((t) => t.assignedAgentId === a.id && isActive(t)).length;
      return `<button class="tk-agent ${a.online ? 'on' : ''}" data-tk-act="toggle-agent" data-id="${a.id}" title="${a.online ? 'متاح — اضغط لتحويله إلى غير متاح' : 'غير متاح — اضغط لتفعيله'}"><i></i>${esc(a.name)}<b>${load}</b></button>`;
    }).join('');
    return `<div class="tk-dept" style="--c:${d.color}"><div class="tk-dept-top"><div><strong>${d.label}</strong><small dir="ltr">${d.en}</small></div><span class="tk-dept-count">${list.length}</span></div><div class="tk-agents">${ags}</div></div>`;
  }).join('');
  const counts = { active: all.filter(isActive).length, assigned: all.filter((t) => ['new', 'assigned'].includes(t.status)).length, working: all.filter((t) => ['accepted', 'in_progress'].includes(t.status)).length, on_hold: all.filter((t) => t.status === 'on_hold').length, resolved: all.filter((t) => t.status === 'resolved').length, all: all.length };
  const chips = [['active', 'نشطة'], ['assigned', 'بانتظار القبول'], ['working', 'قيد العمل'], ['on_hold', 'معلقة'], ['resolved', 'مكتملة'], ['all', 'الكل']].map(([k, l]) => `<button class="filter-chip ${TK.filter === k ? 'active' : ''}" data-tk-act="filter" data-v="${k}">${l} <b>${counts[k]}</b></button>`).join('');
  const list = sortTickets(all.filter((t) => filterMatch(t) && matches(t.id, t.title, t.description, t.room, CATS[t.category].label, DEPTS[t.department].label, agentOf(t.assignedAgentId)?.name || '')));
  const actions = `${isMgr() ? `<button class="btn" data-tk-act="settings">${icon('settings')}إعدادات</button>` : ''}<button class="btn" data-tk-act="export-tickets">${icon('download')}CSV</button><button class="btn primary" data-tk-act="new">${icon('plus')}تيكيت جديد</button>`;
  return `${pageHead('التذاكر و SLA', 'توزيع تلقائي على الأقسام والإيجينتس، وتتبع القبول والتنفيذ مع عدّاد SLA مباشر.', actions)}${demoNotice()}
<div class="kpi-grid">${KPI}</div>
<div class="tk-depts">${depts}</div>
<section class="section-card"><div class="panel-toolbar"><div class="filter-row">${chips}</div><select class="select-compact" data-tk-dept aria-label="القسم"><option value="all">كل الأقسام</option>${Object.entries(DEPTS).map(([k, d]) => `<option value="${k}" ${TK.dept === k ? 'selected' : ''}>${d.label}</option>`).join('')}</select></div>
<div class="tk-list">${list.length ? list.map(ticketCard).join('') : `<div class="empty-state">${icon('ticket')}<b>لا توجد تذاكر مطابقة</b>عدّلي الفلتر أو أنشئي تيكيتًا جديدًا.</div>`}</div></section>
<div class="prototype-warning"><b>${isMgr() ? 'كل التذاكر' : 'تذاكرك أنتِ'}:</b> نمط التوزيع الحالي <b>${S.strategy === 'round_robin' ? 'Round-Robin' : 'Least Busy'}</b> · مهلة القبول ${S.acceptMinutes} دقائق. الحالة تتحدّث لحظيًا بين كل المستخدمين.</div>`;
}

/* ---------- نوافذ التفاصيل والنماذج ---------- */
function field(label, input) { return `<div class="form-field"><label>${label}</label>${input}</div>`; }
function openNew() {
  const opts = Object.entries(DEPTS).map(([k, d]) => `<optgroup label="${d.label}">${Object.entries(CATS).filter(([, c]) => c.dept === k).map(([ck, c]) => `<option value="${ck}">${c.label}</option>`).join('')}</optgroup>`).join('');
  openModal('تيكيت جديد', 'سيُوجَّه إلى القسم المختص ويُسند تلقائيًا لإيجينت متاح.', `<form data-tk-form="new">
  ${field('عنوان الطلب', '<input name="title" required maxlength="90" placeholder="مثال: المكيف لا يبرد">')}
  ${field('التفاصيل', '<textarea name="description" maxlength="300" placeholder="تفاصيل الطلب"></textarea>')}
  ${field('نوع الطلب / التصنيف (Category)', `<select name="category">${opts}</select>`)}
  ${field('الأولوية', `<select name="priority">${Object.entries(PRI).map(([k, p]) => `<option value="${k}" ${k === 'medium' ? 'selected' : ''}>${p.label} (${p.en})</option>`).join('')}</select>`)}
  ${field('الغرفة (اختياري)', `<select name="room"><option value="">—</option>${D().rooms.map((r) => `<option value="${esc(r.id)}">${esc(r.id)} — ${esc(r.type)}</option>`).join('')}</select>`)}
  <div class="tk-route-preview" data-tk-preview></div>
  <div class="form-actions"><button class="btn primary" type="submit">${icon('plus')}إنشاء التيكيت</button><button class="btn ghost" type="button" data-action="close-modal">إلغاء</button></div></form>`);
  modalRoot.querySelector('.modal').classList.add('tk-modal');
  updatePreview();
}
function updatePreview() {
  const f = modalRoot.querySelector('[data-tk-form="new"]'); if (!f) return;
  const c = f.category.value, p = f.priority.value, dept = CATS[c].dept;
  const online = D().agents.filter((a) => a.dept === dept && a.online).length;
  modalRoot.querySelector('[data-tk-preview]').innerHTML = `<b>القسم:</b> ${DEPTS[dept].label} · <b>SLA:</b> ${human(D().ticketSettings.sla[p] * M)} · <b>المتاحون الآن:</b> ${online || 'لا يوجد (قائمة انتظار)'}`;
}
function openSmall(title, sub, name, id, body, submit) {
  openModal(title, sub, `<form data-tk-form="${name}" data-id="${id}">${body}<div class="form-actions"><button class="btn primary" type="submit">${submit}</button><button class="btn ghost" type="button" data-tk-act="open" data-id="${id}">رجوع</button></div></form>`);
}
function openDetail(id) {
  const t = find(id); if (!t) return;
  const ag = agentOf(t.assignedAgentId), T = t.timestamps;
  const row = (k, v) => `<div><small>${k}</small><b>${v}</b></div>`;
  const times = [['أُنشئ', T.createdAt], ['أُسند', T.assignedAt], ['قُبل', T.acceptedAt], ['بدأ التنفيذ', T.startedAt], ['علِّق', T.heldAt], ['أُغلق', T.resolvedAt], ['موعد انتهاء SLA', T.slaDeadline]].filter(([, v]) => v).map(([k, v]) => row(k, stamp(v))).join('');
  const btn = (a, label, cls = '') => `<button class="btn small ${cls}" data-tk-act="${a}" data-id="${t.id}">${label}</button>`;
  let actions = primaryAction(t);
  if (['accepted', 'in_progress'].includes(t.status)) actions += btn('hold-form', 'تعليق (On Hold)');
  if (t.status === 'accepted') actions += btn('resolve-form', 'إغلاق الطلب');
  if (t.status === 'on_hold') actions += btn('resolve-form', 'إغلاق الطلب');
  if (isActive(t)) actions += btn('transfer-form', 'تحويل لقسم آخر');
  const logs = [...(t.activityLog || [])].reverse().map((l) => `<li><time>${stamp(l.at)}</time><span><b>${esc(l.actor)}</b> — ${esc(l.text)}</span></li>`).join('');
  openModal(`${esc(t.id)} — ${esc(t.title)}`, `${DEPTS[t.department].label} · ${CATS[t.category].label}`, `
  <div class="tk-detail-grid">${row('الأولوية', priBadge(t.priority))}${row('الحالة', stBadge(t.status))}${row('الإيجينت', ag ? esc(ag.name) : 'غير مُسند')}${row('الغرفة', t.room ? esc(t.room) : '—')}${row('مدة SLA', human(t.slaMinutes * M))}${row('مدة التوقف', human(t.pausedMs || 0))}</div>
  <p class="tk-desc">${esc(t.description || '')}</p>
  ${slaWrap(t)}${accWrap(t)}
  ${t.resolution ? `<div class="tk-resolution"><small>ملخص الحل</small>${esc(t.resolution)}</div>` : ''}
  ${actions ? `<div class="tk-card-actions tk-detail-actions">${actions}</div>` : ''}
  <h4 class="tk-h">التوقيتات</h4><div class="tk-detail-grid">${times}</div>
  ${isActive(t) ? `<form data-tk-form="note" data-id="${t.id}" class="tk-note"><input name="text" required maxlength="200" placeholder="أضيفي ملاحظة داخلية (Internal Note)…"><button class="btn small primary" type="submit">إضافة</button></form>` : ''}
  <h4 class="tk-h">سجل النشاط</h4><ul class="tk-log">${logs}</ul>`);
  modalRoot.querySelector('.modal').classList.add('tk-modal');
}
const DAYS = [[6, 'السبت'], [0, 'الأحد'], [1, 'الاثنين'], [2, 'الثلاثاء'], [3, 'الأربعاء'], [4, 'الخميس'], [5, 'الجمعة']];
const TZS = [['Africa/Cairo', 'القاهرة'], ['Asia/Riyadh', 'الرياض'], ['Asia/Kuwait', 'الكويت'], ['Asia/Dubai', 'دبي'], ['Asia/Amman', 'عمّان'], ['Asia/Baghdad', 'بغداد'], ['Africa/Casablanca', 'الدار البيضاء'], ['UTC', 'UTC']];
function openSettings() {
  const S = D().ticketSettings, B = S.business || { enabled: false, tz: 'Africa/Cairo', start: '08:00', end: '22:00', days: [0, 1, 2, 3, 4, 5, 6], urgent24x7: true };
  openModal('إعدادات التذاكر', 'التغييرات تسري على التذاكر المنشأة بعد الحفظ فقط.', `<form data-tk-form="settings">
  ${field('نمط التوزيع على الإيجينتس', `<select name="strategy"><option value="least_busy" ${S.strategy === 'least_busy' ? 'selected' : ''}>الأقل انشغالًا (Least Busy)</option><option value="round_robin" ${S.strategy === 'round_robin' ? 'selected' : ''}>توزيع عادل بالتناوب (Round-Robin)</option></select>`)}
  ${field('مهلة القبول (دقائق)', `<input name="acceptMinutes" type="number" min="1" max="120" value="${S.acceptMinutes}">`)}
  ${field('عند تأخر القبول', `<select name="autoReassign"><option value="0" ${!S.autoReassign ? 'selected' : ''}>إظهار تنبيه «تأخر في القبول» فقط</option><option value="1" ${S.autoReassign ? 'selected' : ''}>إعادة التوجيه تلقائيًا لإيجينت آخر</option></select>`)}
  ${Object.entries(PRI).map(([k, p]) => field(`SLA — ${p.label} (${p.en}) بالدقائق`, `<input name="sla_${k}" type="number" min="5" max="10080" value="${S.sla[k]}">`)).join('')}
  <h4 class="tk-h">ساعات العمل (SLA يُحسب داخلها فقط)</h4>
  ${field('تفعيل ساعات العمل', `<select name="bh_enabled"><option value="0" ${!B.enabled ? 'selected' : ''}>معطّل — الـ SLA يعدّ على مدار الساعة</option><option value="1" ${B.enabled ? 'selected' : ''}>مفعّل — لا يُحتسب وقت الإغلاق</option></select>`)}
  <div class="tk-detail-grid">${field('من', `<input name="bh_start" type="time" value="${B.start}">`)}${field('إلى', `<input name="bh_end" type="time" value="${B.end}">`)}${field('المنطقة الزمنية', `<select name="bh_tz">${TZS.map(([k, l]) => `<option value="${k}" ${B.tz === k ? 'selected' : ''}>${l}</option>`).join('')}</select>`)}</div>
  <div class="tk-days">${DAYS.map(([n, l]) => `<label><input type="checkbox" name="bh_day" value="${n}" ${B.days.includes(n) ? 'checked' : ''}> ${l}</label>`).join('')}</div>
  ${field('التذاكر العاجلة (Urgent)', `<select name="bh_urgent"><option value="1" ${B.urgent24x7 ? 'selected' : ''}>تعمل 24/7 خارج ساعات العمل</option><option value="0" ${!B.urgent24x7 ? 'selected' : ''}>تلتزم بساعات العمل أيضًا</option></select>`)}
  <div class="form-actions"><button class="btn primary" type="submit">حفظ الإعدادات</button><button class="btn ghost" type="button" data-action="close-modal">إلغاء</button></div></form>`);
}

/* ---------- الواجهة: التقارير ---------- */
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function range() {
  const d = new Date(), sod = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  if (TK.period === 'daily') return [sod, sod + DAY];
  if (TK.period === 'weekly') return [sod - 6 * DAY, sod + DAY];
  if (TK.period === 'monthly') return [sod - 29 * DAY, sod + DAY];
  let a = TK.from ? new Date(`${TK.from}T00:00:00`).getTime() : sod - 6 * DAY;
  let b = TK.to ? new Date(`${TK.to}T00:00:00`).getTime() + DAY : sod + DAY;
  if (a >= b) [a, b] = [b - DAY, a + DAY];
  return [a, b];
}
function stats(list) {
  const resolved = list.filter((t) => t.status === 'resolved');
  const accepted = list.filter((t) => t.timestamps.acceptedAt);
  const compliant = resolved.filter((t) => ms(t.timestamps.resolvedAt) <= ms(t.timestamps.slaDeadline)).length;
  return {
    total: list.length, accepted: accepted.length, inProgress: list.filter((t) => t.status === 'in_progress').length, resolved: resolved.length,
    active: list.filter(isActive).length, breached: list.filter(isBreached).length,
    avgAccept: avg(accepted.map((t) => ms(t.timestamps.acceptedAt) - ms(t.timestamps.assignedAt))),
    avgResolve: avg(resolved.filter((t) => t.timestamps.acceptedAt).map((t) => ms(t.timestamps.resolvedAt) - ms(t.timestamps.acceptedAt))),
    compliance: resolved.length ? compliant / resolved.length : null,
    completion: list.length ? resolved.length / list.length : null,
    breachRate: list.length ? list.filter(isBreached).length / list.length : null
  };
}
function reportData() {
  const [a, b] = range();
  const list = D().tickets.filter((t) => { const c = ms(t.timestamps.createdAt); return c >= a && c < b; });
  return {
    a, b, list, all: stats(list),
    agents: D().agents.map((ag) => ({ ag, s: stats(list.filter((t) => t.assignedAgentId === ag.id)) })),
    depts: Object.keys(DEPTS).map((k) => ({ k, s: stats(list.filter((t) => t.department === k)) }))
  };
}
const complianceBadge = (v) => { if (v == null) return '—'; const c = v >= 0.9 ? 'var(--green)' : v >= 0.75 ? 'var(--amber)' : 'var(--red)'; return `<span class="status-badge" style="--badge-color:${c};--badge-bg:color-mix(in srgb,${c} 9%,transparent)">${pct(v)}</span>`; };
function renderReports() {
  if (!isMgr()) return `${pageHead('تقارير التذاكر', 'متاحة للإدارة فقط.', '')}<div class="empty-state"><b>غير مصرح</b>التقارير متاحة لمديرة الفندق فقط.</div>`;
  const r = reportData(), s = r.all;
  const periods = [['daily', 'يومي (Daily)'], ['weekly', 'أسبوعي (Weekly)'], ['monthly', 'شهري (Monthly)'], ['custom', 'مخصص (Custom)']];
  const chips = periods.map(([k, l]) => `<button class="filter-chip ${TK.period === k ? 'active' : ''}" data-tk-act="period" data-v="${k}">${l}</button>`).join('');
  const [fa, fb] = range();
  const custom = TK.period === 'custom' ? `<div class="tk-dates"><label>من <input type="date" data-tk-from value="${TK.from || ymd(new Date(fa))}"></label><label>إلى <input type="date" data-tk-to value="${TK.to || ymd(new Date(fb - DAY))}"></label></div>` : '';
  const maxTotal = Math.max(1, ...r.depts.map((d) => d.s.total));
  const agentRows = r.agents.map(({ ag, s: x }) => `<tr><td><b>${esc(ag.name)}</b>${ag.online ? '' : ' <small class="dim">(غير متاح)</small>'}</td><td>${deptChip(ag.dept)}</td><td>${x.total}</td><td>${x.accepted}</td><td>${x.inProgress}</td><td>${x.resolved}</td><td>${human(x.avgAccept)}</td><td>${human(x.avgResolve)}</td><td>${complianceBadge(x.compliance)}</td></tr>`).join('');
  const deptRows = r.depts.map(({ k, s: x }) => `<tr><td>${deptChip(k)}</td><td><div class="tk-load"><i style="width:${Math.round(x.total / maxTotal * 100)}%;background:${DEPTS[k].color}"></i></div></td><td>${x.total}</td><td>${x.active}</td><td>${pct(x.completion)}</td><td>${x.breached} (${pct(x.breachRate)})</td><td>${human(x.avgAccept)}</td><td>${human(x.avgResolve)}</td><td>${complianceBadge(x.compliance)}</td></tr>`).join('');
  const actions = `<button class="btn" data-tk-act="export-report">${icon('download')}تصدير CSV / Excel</button><button class="btn primary" data-tk-act="print">طباعة</button>`;
  return `${pageHead('تقارير التذاكر', 'أداء الإيجينتس والتقرير العام للمنظومة حسب الفترة المحددة.', actions)}${demoNotice()}
<section class="section-card"><div class="panel-toolbar"><div class="filter-row">${chips}</div><span class="result-count">${stamp(r.a)} — ${stamp(r.b - 1)}</span></div>${custom}</section>
<div class="kpi-grid tk-report-kpis">
${kpi('إجمالي الطلبات', s.total, 'تيكيت', `${s.active} نشطة حاليًا`, 'ticket', 'var(--blue)')}
${kpi('نسبة الإنجاز', pct(s.completion), 'مكتملة', `${s.resolved} من ${s.total}`, 'check', 'var(--green)')}
${kpi('نسبة التجاوزات', pct(s.breachRate), 'Breached', `${s.breached} تيكيت تجاوز الـ SLA`, 'flag', 'var(--red)')}
${kpi('الالتزام بالـ SLA', pct(s.compliance), 'من المغلقة', `متوسط التنفيذ ${human(s.avgResolve)}`, 'shield', 'var(--gold)')}
</div>
<section class="section-card"><div class="section-head"><div><div class="section-title"><span>${icon('chart')}</span>مقارنة الأقسام</div><div class="section-sub">ضغط العمل والأداء بين الأقسام الثلاثة</div></div></div><div class="table-scroll"><table class="data-table tk-table"><thead><tr><th>القسم</th><th>ضغط العمل</th><th>الإجمالي</th><th>نشطة</th><th>الإنجاز</th><th>التجاوزات</th><th>متوسط القبول</th><th>متوسط التنفيذ</th><th>التزام SLA</th></tr></thead><tbody>${deptRows}</tbody></table></div></section>
<section class="section-card tk-gap"><div class="section-head"><div><div class="section-title"><span>${icon('users')}</span>أداء الإيجينتس (Agent Performance)</div><div class="section-sub">متوسط القبول = من الإسناد حتى الضغط على «قبول» · متوسط التنفيذ = من القبول حتى الإغلاق</div></div></div><div class="table-scroll"><table class="data-table tk-table"><thead><tr><th>الإيجينت</th><th>القسم</th><th>المسندة</th><th>المقبولة</th><th>قيد التنفيذ</th><th>المغلقة</th><th>متوسط القبول</th><th>متوسط التنفيذ</th><th>التزام SLA</th></tr></thead><tbody>${agentRows}</tbody></table></div></section>
<div class="prototype-warning"><b>طريقة الحساب:</b> التذاكر تُحتسب حسب تاريخ إنشائها داخل الفترة. التزام الـ SLA = المغلقة قبل الموعد النهائي ÷ إجمالي المغلقة (مدة التعليق لا تُحسب). عند تحويل تيكيت لقسم آخر يُنسب للإيجينت الجديد.</div>`;
}

/* ---------- التصدير ---------- */
const cell = (v) => { let s = String(v ?? ''); if (/^[=+\-@]/.test(s) && Number.isNaN(Number(s))) s = `'${s}`; return `"${s.replaceAll('"', '""')}"`; };
const csvRows = (rows) => rows.map((r) => r.map(cell).join(',')).join('\n');
function ticketRow(t) { const T = t.timestamps; return [t.id, t.title, CATS[t.category].label, PRI[t.priority].label, DEPTS[t.department].label, agentOf(t.assignedAgentId)?.name || '', ST[t.status].label, t.room, T.createdAt, T.assignedAt, T.acceptedAt, T.resolvedAt, T.slaDeadline, isBreached(t) ? 'نعم' : 'لا']; }
const TICKET_HEAD = ['ID', 'العنوان', 'التصنيف', 'الأولوية', 'القسم', 'الإيجينت', 'الحالة', 'الغرفة', 'أُنشئ', 'أُسند', 'قُبل', 'أُغلق', 'موعد SLA', 'تجاوز SLA'];
function exportTickets() { download('global-stay-tickets.csv', '\uFEFF' + csvRows([TICKET_HEAD, ...visibleTickets().map(ticketRow)]), 'text/csv;charset=utf-8'); showToast('تم تنزيل ملف CSV'); }
function exportReport() {
  const r = reportData(), m = (v) => v == null ? '' : Math.round(v / M * 10) / 10;
  const stat = (x) => [x.total, x.accepted, x.inProgress, x.resolved, m(x.avgAccept), m(x.avgResolve), x.compliance == null ? '' : Math.round(x.compliance * 100), x.breached];
  const H = ['إجمالي', 'مقبولة', 'قيد التنفيذ', 'مغلقة', 'متوسط القبول (دقيقة)', 'متوسط التنفيذ (دقيقة)', 'التزام SLA %', 'تجاوزات'];
  const out = [
    [`تقرير التذاكر`, ymd(new Date(r.a)), ymd(new Date(r.b - 1))], [],
    ['أداء الإيجينتس'], ['الإيجينت', 'القسم', ...H], ...r.agents.map(({ ag, s }) => [ag.name, DEPTS[ag.dept].label, ...stat(s)]), [],
    ['مقارنة الأقسام'], ['القسم', '', ...H], ...r.depts.map(({ k, s }) => [DEPTS[k].label, '', ...stat(s)]), [],
    ['المنظومة'], ['الكل', '', ...stat(r.all)], [],
    ['التذاكر'], TICKET_HEAD, ...r.list.map(ticketRow)
  ];
  download('global-stay-tickets-report.csv', '\uFEFF' + csvRows(out), 'text/csv;charset=utf-8'); showToast('تم تنزيل التقرير — يُفتح مباشرة في Excel');
}

/* ---------- الأحداث ---------- */
function onClick(e) {
  const el = e.target.closest('[data-tk-act]'); if (!el) return;
  const a = el.dataset.tkAct, id = el.dataset.id, v = el.dataset.v;
  if (a === 'open') { if (e.target.closest('button') && e.target.closest('button') !== el) return; openDetail(id); }
  else if (a === 'accept') doAccept(id);
  else if (a === 'start') doStart(id);
  else if (a === 'resume') doResume(id);
  else if (a === 'reassign') doReassign(id);
  else if (a === 'hold-form') openSmall('تعليق الطلب', 'يتوقف مؤقت الـ SLA حتى الاستئناف.', 'hold', id, field('سبب التعليق', '<input name="reason" required maxlength="120" placeholder="مثال: في انتظار رد العميل">'), 'تعليق الطلب');
  else if (a === 'resolve-form') openSmall('إغلاق الطلب', 'سجّلي ملخصًا لما تم تنفيذه.', 'resolve', id, field('ملخص الحل', '<textarea name="summary" required maxlength="240" placeholder="ماذا تم تنفيذه؟"></textarea>'), 'تأكيد الإغلاق');
  else if (a === 'transfer-form') { const t = find(id); openSmall('تحويل إلى قسم آخر', 'يُسند تلقائيًا لإيجينت متاح في القسم الجديد.', 'transfer', id, field('القسم', `<select name="dept">${Object.entries(DEPTS).filter(([k]) => k !== t.department).map(([k, d]) => `<option value="${k}">${d.label}</option>`).join('')}</select>`) + field('سبب التحويل (إلزامي)', '<textarea name="reason" required maxlength="200" placeholder="لماذا يُحوَّل التيكيت؟"></textarea>'), 'تحويل'); }
  else if (a === 'new') openNew();
  else if (a === 'settings') openSettings();
  else if (a === 'filter') { TK.filter = v; render(); }
  else if (a === 'period') { TK.period = v; render(); }
  else if (a === 'toggle-agent') toggleAgent(id);
  else if (a === 'export-tickets') exportTickets();
  else if (a === 'export-report') exportReport();
  else if (a === 'print') window.print();
  else if (a === 'from-request') fromRequest(id);
}
async function toggleAgent(id) {
  if (!isMgr() && me().id !== id) { showToast('يمكنك تغيير حالتك أنت فقط'); return; }
  const ag = agentOf(id); if (!ag) return;
  try { const d = await api('PUT', `/api/agents/${id}/online`, { online: !ag.online }); D().agents = d.agents; showToast(`${ag.name}: ${!ag.online ? 'متاح' : 'غير متاح'}`); refresh(); } catch (e) { showToast(e.message); }
}
async function onSubmit(e) {
  const f = e.target, kind = f.dataset?.tkForm; if (!kind) return;
  e.preventDefault();
  const v = Object.fromEntries(new FormData(f).entries()), id = f.dataset.id;
  if (kind === 'new') {
    try {
      const d = await api('POST', '/api/tickets', { title: v.title.trim(), description: v.description.trim(), category: v.category, priority: v.priority, room: v.room });
      const t = d.ticket; closeModal(); state.view = 'tickets'; state.query = ''; TK.filter = 'active';
      await refresh(); render();
      showToast(`${t.id} → ${DEPTS[t.department].label}${t.assignedAgentId ? ` / ${agentOf(t.assignedAgentId)?.name || ''}` : ' (قائمة الانتظار)'}`);
    } catch (x) { showToast(x.message); }
  } else if (kind === 'hold') { closeModal(); doHold(id, v.reason.trim()); }
  else if (kind === 'resolve') { closeModal(); doResolve(id, v.summary.trim()); }
  else if (kind === 'transfer') { closeModal(); doTransfer(id, v.dept, v.reason.trim()); }
  else if (kind === 'note') { doNote(id, v.text.trim()); }
  else if (kind === 'settings') {
    try {
      const d = await api('PUT', '/api/settings', { strategy: v.strategy, acceptMinutes: Number(v.acceptMinutes), autoReassign: v.autoReassign === '1', sla: Object.fromEntries(Object.keys(PRI).map((k) => [k, Number(v[`sla_${k}`])])), business: { enabled: v.bh_enabled === '1', tz: v.bh_tz, start: v.bh_start, end: v.bh_end, days: new FormData(f).getAll('bh_day').map(Number), urgent24x7: v.bh_urgent === '1' } });
      D().ticketSettings = d.settings; closeModal(); render(); showToast('تم حفظ إعدادات التذاكر');
    } catch (x) { showToast(x.message); }
  }
}
function onChange(e) {
  const t = e.target;
  if (t.matches('[data-tk-dept]')) { TK.dept = t.value; render(); }
  else if (t.matches('[data-tk-from]')) { TK.from = t.value; render(); }
  else if (t.matches('[data-tk-to]')) { TK.to = t.value; render(); }
  else if (t.closest('[data-tk-form="new"]') && ['category', 'priority'].includes(t.name)) updatePreview();
}
document.addEventListener('click', onClick);
document.addEventListener('submit', onSubmit);
document.addEventListener('change', onChange);
document.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches?.('.tk-card')) { e.preventDefault(); openDetail(e.target.dataset.id); } });

/* ---------- التسجيل داخل التطبيق ---------- */
Object.assign(ICONS, {
  ticket: '<path d="M3 9a2 2 0 0 0 0 6v3h18v-3a2 2 0 0 1 0-6V6H3v3Z"/><path d="M14 6v2m0 3v2m0 3v2"/>',
  report: '<path d="M6 3h9l4 4v14H6V3Z"/><path d="M14 3v5h5M9 13h7M9 17h5"/>'
});
Object.assign(VIEW_NAMES, { tickets: 'التذاكر و SLA', reports: 'تقارير التذاكر' });
window.EXTRA_VIEWS = { ...(window.EXTRA_VIEWS || {}), tickets: renderTickets, reports: renderReports };
D().tickets = GS.tickets; D().agents = GS.agents; D().ticketSettings = { ...GS.settings };
window.tkRefresh = refresh;
window.tkActiveCount = () => (D().tickets || []).filter(isActive).length;
renderNavIcons();
updateCounts();
setInterval(tickDom, 1000);
setInterval(refresh, 60000);
})();
