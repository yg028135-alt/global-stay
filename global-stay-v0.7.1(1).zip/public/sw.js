/* Service Worker: يخزّن واجهة التطبيق فقط. طلبات /api لا تُخزَّن أبدًا (بيانات حية وحساسة). */
const CACHE = 'gs-shell-v6';
const SHELL = ['/', '/index.html', '/login.html', '/styles.css', '/guest.css', '/boot.js', '/app.js', '/tickets.js', '/users.js', '/apartments.js', '/login.js', '/brand.svg', '/manifest.webmanifest', '/icon-192.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/') || u.pathname === '/healthz') return;
  e.respondWith(fetch(e.request).then((r) => { if (r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); } return r; }).catch(() => caches.match(e.request).then((m) => m || caches.match('/index.html'))));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((cs) => cs.length ? cs[0].focus() : self.clients.openWindow('/')));
});

// إشعارات Web Push: لا نعرض إشعارًا إن كان التطبيق مفتوحًا ومرئيًا (يظهر التنبيه داخله)
self.addEventListener('push', (e) => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch { d = { body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((cs) => {
    if (cs.some((c) => c.visibilityState === 'visible')) return;
    return self.registration.showNotification(d.title || 'Global Stay', { body: d.body || '', icon: '/icon-192.png', badge: '/icon-192.png', tag: d.tag, dir: 'rtl', lang: 'ar', renotify: true, data: { ticketId: d.ticketId } });
  }));
});
