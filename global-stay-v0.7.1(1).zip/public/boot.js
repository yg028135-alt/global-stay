/* إقلاع التطبيق: التحقق من الجلسة، جلب البيانات من الخادم، ثم تحميل باقي السكربتات بالترتيب */
(() => {
  window.api = async (method, url, body) => {
    const r = await fetch(url, { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'gs', ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
    let d = {}; try { d = await r.json(); } catch { /* غير JSON */ }
    if (r.status === 401 && !url.startsWith('/api/login')) { location.href = '/login.html'; throw new Error(d.error || 'انتهت الجلسة'); }
    if (!r.ok) throw new Error(d.error || 'حدث خطأ غير متوقع');
    return d;
  };
  const load = (src) => new Promise((ok, fail) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => fail(new Error(src)); document.body.append(s); });
  function offline(msg) {
    document.body.innerHTML = `<div style="min-height:100vh;display:grid;place-items:center;padding:24px;text-align:center;font-family:Cairo,system-ui,sans-serif"><div><h2>تعذر الاتصال بالخادم</h2><p style="color:#8594a8">${msg}</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button></div></div>`;
  }
  // مزامنة بيانات الفندق على مستوى الصف: نرسل المتغير فقط ونتجنب أن يمحو جهاز تعديلات جهاز آخر
  const KINDS = ['rooms', 'requests', 'tasks'];
  let snap = {}, timer;
  window.hotelSnapshot = (h) => { snap = {}; for (const k of KINDS) snap[k] = new Map((h?.[k] || []).map((r) => [r.id, JSON.stringify(r)])); };
  window.pushHotel = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const upsert = {}, remove = {}; let n = 0;
      for (const k of KINDS) {
        const cur = state.data[k] || [];
        upsert[k] = cur.filter((r) => snap[k].get(r.id) !== JSON.stringify(r));
        remove[k] = [...snap[k].keys()].filter((id) => !cur.some((r) => r.id === id));
        n += upsert[k].length + remove[k].length;
      }
      if (!n) return;
      api('PUT', '/api/hotel', { upsert, remove }).then(() => {
        for (const k of KINDS) { upsert[k].forEach((r) => snap[k].set(r.id, JSON.stringify(r))); remove[k].forEach((id) => snap[k].delete(id)); }
      }).catch((e) => showToast(e.message));
    }, 350);
  };
  (async () => {
    let d;
    try { d = await api('GET', '/api/bootstrap'); } catch (e) { if (!/الجلسة|تسجيل/.test(e.message)) offline('تأكد من اتصالك بالإنترنت ثم أعد المحاولة.'); return; }
    window.GS = { ...d, offset: d.now - Date.now() };
    document.documentElement.classList.add(`role-${d.me.role}`);
    try { for (const s of ['/app.js', '/tickets.js', '/users.js', '/apartments.js']) await load(s); } catch (e) { offline(`تعذر تحميل ${e.message}`); return; }
    hotelSnapshot(GS.hotel);
    if (!GS.hotel) save();           // أول تشغيل: ارفع بيانات الفندق الابتدائية للخادم
    render();
    const es = new EventSource('/api/events');
    es.addEventListener('change', () => window.tkRefresh && tkRefresh());
    es.addEventListener('notify', (e) => window.gsNotify && gsNotify(JSON.parse(e.data)));
    es.addEventListener('hotel', (e) => {
      if (JSON.parse(e.data).by === GS.me.id) return;
      api('GET', '/api/hotel').then(({ hotel }) => { if (!hotel) return; Object.assign(state.data, { rooms: hotel.rooms, requests: hotel.requests, tasks: hotel.tasks }); hotelSnapshot(hotel); const el = document.activeElement; if (!(el && /INPUT|SELECT|TEXTAREA/.test(el.tagName))) render(); updateCounts(); });
    });
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  })();
})();
