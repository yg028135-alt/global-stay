/* المستخدمون والإدارة + الملف الشخصي + الإشعارات + تثبيت التطبيق (PWA) */
(() => {
'use strict';
const esc = (v) => escapeHtml(v);
const ROLE = { manager: 'مدير', agent: 'إيجينت' };
const DEPT = { customer_service: 'خدمة العملاء', guest_relations: 'علاقات النزلاء', reception: 'الاستقبال', accounting: 'المحاسبة', housekeeping: 'التدبير المنزلي', maintenance: 'الصيانة', operations: 'إدارة التشغيل' };
const stamp = (s) => new Date(s).toLocaleString('ar-EG-u-nu-latn', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const ACTIONS = { login: 'تسجيل دخول', logout: 'تسجيل خروج', login_failed: 'محاولة دخول فاشلة', password_change: 'تغيير كلمة مرور', user_create: 'إنشاء مستخدم', user_update: 'تعديل مستخدم', settings: 'تعديل إعدادات التذاكر' };
const field = (label, input) => `<div class="form-field"><label>${label}</label>${input}</div>`;
const me = GS.me;
let unread = GS.unread || 0, users = [], auditRows = [], loadedAt = 0, installEvt = null;

/* ----- الهوية في الشريط العلوي ----- */
const roleLabel = () => me.role === 'manager' ? 'مدير النظام' : `إيجينت — ${DEPT[me.dept] || ''}`;
const chip = document.querySelector('.profile-chip');
chip.querySelector('.profile-avatar').textContent = me.name[0];
chip.querySelector('.profile-meta b').textContent = me.name;
chip.querySelector('.profile-meta small').textContent = roleLabel();
chip.setAttribute('role', 'button'); chip.setAttribute('tabindex', '0'); chip.setAttribute('aria-label', 'الملف الشخصي');
const bell = document.querySelector('#notifications-button');
const paintBell = () => { bell.classList.toggle('no-unread', unread === 0); bell.title = unread ? `${unread} تنبيه جديد` : 'التنبيهات'; };
paintBell();

/* ----- الإشعارات ----- */
window.gsNotify = (n) => {
  unread++; paintBell(); showToast(n.text);
  if (document.hidden && 'Notification' in window && Notification.permission === 'granted' && navigator.serviceWorker) {
    navigator.serviceWorker.ready.then((r) => r.showNotification('Global Stay', { body: n.text, icon: '/icon-192.png', tag: `gs-${n.id}`, dir: 'rtl', lang: 'ar' })).catch(() => {});
  }
};
async function openNotifications() {
  try {
    const { items } = await api('GET', '/api/notifications');
    openModal('التنبيهات', 'آخر 50 تنبيهًا', `<div class="tk-notif">${items.length ? items.map((n) => `<div class="tk-notif-item ${n.read ? '' : 'unread'}">${esc(n.text)}<small>${stamp(n.createdAt)}</small></div>`).join('') : '<div class="empty-state"><b>لا توجد تنبيهات</b></div>'}</div>`);
    if (unread) { await api('POST', '/api/notifications/read', {}); unread = 0; paintBell(); }
  } catch (e) { showToast(e.message); }
}
document.addEventListener('click', (e) => {
  if (e.target.closest('#notifications-button')) { e.stopImmediatePropagation(); e.preventDefault(); openNotifications(); }
}, true);

/* ----- الملف الشخصي ----- */
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); installEvt = e; });
const urlKey = (b64) => Uint8Array.from(atob(b64.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
const pushSupported = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
async function pushSub() { try { const r = await navigator.serviceWorker.ready; return await r.pushManager.getSubscription(); } catch { return null; } }
async function enablePush() {
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') { showToast('لم يتم السماح بالإشعارات'); return; }
  if (!pushSupported()) { showToast('تم تفعيل إشعارات المتصفح'); return; }
  try {
    const reg = await navigator.serviceWorker.ready, { key } = await api('GET', '/api/push/key');
    const sub = (await reg.pushManager.getSubscription()) || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlKey(key) });
    await api('POST', '/api/push/subscribe', sub.toJSON());
    showToast('تم تفعيل الإشعارات — ستصلك حتى والتطبيق مغلق');
  } catch (e) { showToast(`تعذر تفعيل الإشعارات: ${e.message}`); }
}
async function disablePush() {
  const sub = await pushSub();
  if (sub) { try { await api('POST', '/api/push/unsubscribe', { endpoint: sub.endpoint }); } catch { /* تجاهل */ } await sub.unsubscribe(); }
  showToast('تم إيقاف إشعارات هذا الجهاز');
}
async function openProfile() {
  const notif = 'Notification' in window ? Notification.permission : 'unsupported';
  const subscribed = notif === 'granted' && pushSupported() ? !!(await pushSub()) : false;
  openModal(esc(me.name), roleLabel(), `
    <div class="tk-card-actions" style="margin-bottom:14px">
      ${notif !== 'denied' && notif !== 'unsupported' ? (subscribed ? '<button class="btn small ghost" data-us-act="push-off">إيقاف إشعارات هذا الجهاز</button>' : '<button class="btn small" data-us-act="push-on">تفعيل الإشعارات على هذا الجهاز</button>') : ''}
      ${installEvt ? '<button class="btn small" data-us-act="install">تثبيت التطبيق على الجهاز</button>' : ''}
      <button class="btn small ghost" data-us-act="logout">تسجيل الخروج</button>
    </div>
    ${notif === 'denied' ? '<p class="tk-desc">الإشعارات محظورة من إعدادات المتصفح لهذا الموقع.</p>' : ''}
    ${/iphone|ipad/i.test(navigator.userAgent) ? '<p class="tk-desc">لتثبيت التطبيق على iPhone: زر المشاركة ← «إضافة إلى الشاشة الرئيسية».</p>' : ''}
    <h4 class="tk-h">تغيير كلمة المرور</h4>
    <form data-us-form="password">
      ${field('كلمة المرور الحالية', '<input name="current" type="password" autocomplete="current-password" required dir="ltr">')}
      ${field('كلمة المرور الجديدة (8 أحرف على الأقل)', '<input name="next" type="password" minlength="8" autocomplete="new-password" required dir="ltr">')}
      <div class="form-actions"><button class="btn primary" type="submit">حفظ</button></div>
    </form>`);
}
chip.addEventListener('click', openProfile);
chip.addEventListener('keydown', (e) => { if (e.key === 'Enter') openProfile(); });

/* ----- صفحة المستخدمين ----- */
async function load() {
  loadedAt = Date.now();
  try {
    const [u, a] = await Promise.all([api('GET', '/api/users'), api('GET', '/api/audit')]);
    users = u.users; auditRows = a.items;
    if (state.view === 'users') { const el = document.activeElement; if (!(el && /INPUT|SELECT|TEXTAREA/.test(el.tagName))) render(); }
  } catch (e) { showToast(e.message); }
}
function renderUsers() {
  if (me.role !== 'manager') return `${pageHead('المستخدمون والإدارة', 'متاحة للإدارة فقط.', '')}<div class="empty-state"><b>غير مصرح</b></div>`;
  if (Date.now() - loadedAt > 5000) load();
  const rows = users.map((u) => `<tr class="tk-user-row"><td><b>${esc(u.name)}</b><br><small class="dim" dir="ltr">${esc(u.username)}</small></td><td>${ROLE[u.role]}</td><td>${u.dept ? DEPT[u.dept] : '—'}</td><td>${u.active ? (u.role === 'agent' ? (u.online ? '<span class="status-badge" style="--badge-color:var(--green);--badge-bg:color-mix(in srgb,var(--green) 9%,transparent)"><i></i>متاح</span>' : 'غير متاح') : 'نشط') : '<span class="dim">معطّل</span>'}</td><td><button class="btn small" data-us-act="edit" data-id="${esc(u.id)}">تعديل</button></td></tr>`).join('');
  const links = state.data.rooms.map((r) => `<button class="btn small ghost" data-us-act="copy-link" data-room="${esc(r.id)}" title="نسخ رابط طلبات الغرفة">${esc(r.id)}</button>`).join('');
  const aud = auditRows.map((a) => `<tr><td>${stamp(a.at)}</td><td>${esc(a.name || '—')}</td><td>${ACTIONS[a.action] || esc(a.action)}</td><td class="dim" dir="ltr">${esc(a.detail || '').slice(0, 90)}</td><td class="dim" dir="ltr">${esc(a.ip || '')}</td></tr>`).join('');
  return `${pageHead('المستخدمون والإدارة', 'حسابات الفريق والصلاحيات وروابط طلبات النزلاء وسجل التدقيق.', `<button class="btn primary" data-us-act="new">${icon('plus')}مستخدم جديد</button>`)}
<section class="section-card"><div class="section-head"><div><div class="section-title"><span>${icon('users')}</span>الفريق (${users.length})</div><div class="section-sub">المدير يرى كل شيء، والإيجينت يرى تذاكره فقط. تعطيل الحساب يُنهي جلساته فورًا.</div></div></div><div class="table-scroll"><table class="data-table tk-table"><thead><tr><th>الاسم</th><th>الدور</th><th>القسم</th><th>الحالة</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></section>
<section class="section-card tk-gap"><div class="section-head"><div><div class="section-title"><span>${icon('ticket')}</span>روابط طلبات النزلاء (QR)</div><div class="section-sub">اضغطي على رقم الغرفة لنسخ رابطها، ثم حوّليه إلى QR بأي مولّد وألصقيه في الغرفة. الطلب يصل مباشرة كتيكيت.</div></div></div><div class="tk-links">${links}</div></section>
<section class="section-card tk-gap"><div class="section-head"><div><div class="section-title"><span>${icon('shield')}</span>سجل التدقيق</div><div class="section-sub">آخر 100 حدث أمني وإداري</div></div></div><div class="table-scroll"><table class="data-table tk-table"><thead><tr><th>الوقت</th><th>المستخدم</th><th>الحدث</th><th>تفاصيل</th><th>IP</th></tr></thead><tbody>${aud}</tbody></table></div></section>`;
}
function userForm(u) {
  const edit = !!u;
  openModal(edit ? `تعديل ${esc(u.name)}` : 'مستخدم جديد', edit ? 'اترك كلمة المرور فارغة إن لم ترغب بتغييرها.' : 'سيستخدم اسم المستخدم وكلمة المرور لتسجيل الدخول.', `<form data-us-form="user" data-id="${edit ? esc(u.id) : ''}">
    ${field('الاسم', `<input name="name" required maxlength="60" value="${edit ? esc(u.name) : ''}">`)}
    ${edit ? '' : field('اسم المستخدم (إنجليزي)', '<input name="username" required pattern="[A-Za-z0-9._\\-]{3,30}" dir="ltr" autocapitalize="none">')}
    ${field('الدور', `<select name="role"><option value="agent" ${!edit || u.role === 'agent' ? 'selected' : ''}>إيجينت</option><option value="manager" ${edit && u.role === 'manager' ? 'selected' : ''}>مدير</option></select>`)}
    ${field('القسم (للإيجينت)', `<select name="dept">${Object.entries(DEPT).map(([k, l]) => `<option value="${k}" ${edit && u.dept === k ? 'selected' : ''}>${l}</option>`).join('')}</select>`)}
    ${field(edit ? 'كلمة مرور جديدة (اختياري)' : 'كلمة المرور (8 أحرف على الأقل)', `<input name="password" type="password" minlength="8" autocomplete="new-password" ${edit ? '' : 'required'} dir="ltr">`)}
    ${edit ? field('الحساب', `<select name="active"><option value="1" ${u.active ? 'selected' : ''}>نشط</option><option value="0" ${!u.active ? 'selected' : ''}>معطّل</option></select>`) : ''}
    <div class="form-actions"><button class="btn primary" type="submit">حفظ</button><button class="btn ghost" type="button" data-action="close-modal">إلغاء</button></div></form>`);
  syncDept();
}
function syncDept() { const f = modalRoot.querySelector('[data-us-form="user"]'); if (f) f.dept.disabled = f.role.value === 'manager'; }

document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-us-act]'); if (!el) return;
  const a = el.dataset.usAct;
  if (a === 'new') userForm(null);
  else if (a === 'edit') userForm(users.find((u) => u.id === el.dataset.id));
  else if (a === 'copy-link') {
    const link = `${location.origin}/request.html?room=${encodeURIComponent(el.dataset.room)}`;
    try { await navigator.clipboard.writeText(link); showToast(`تم نسخ رابط الغرفة ${el.dataset.room}`); } catch { prompt('انسخي الرابط:', link); }
  }
  else if (a === 'logout') { try { await api('POST', '/api/logout', {}); } catch { /* تجاهل */ } location.href = '/login.html'; }
  else if (a === 'push-on') { closeModal(); enablePush(); }
  else if (a === 'push-off') { closeModal(); disablePush(); }
  else if (a === 'install' && installEvt) { installEvt.prompt(); installEvt = null; closeModal(); }
});
document.addEventListener('change', (e) => { if (e.target.closest('[data-us-form="user"]') && e.target.name === 'role') syncDept(); });
document.addEventListener('submit', async (e) => {
  const f = e.target, kind = f.dataset?.usForm; if (!kind) return;
  e.preventDefault();
  const v = Object.fromEntries(new FormData(f).entries());
  try {
    if (kind === 'password') { await api('POST', '/api/me/password', { current: v.current, next: v.next }); closeModal(); showToast('تم تغيير كلمة المرور'); }
    else if (kind === 'user') {
      const body = { name: v.name, role: v.role, dept: v.role === 'manager' ? null : v.dept };
      if (v.password) body.password = v.password;
      if (f.dataset.id) { body.active = v.active === '1'; await api('PATCH', `/api/users/${f.dataset.id}`, body); }
      else { body.username = v.username; await api('POST', '/api/users', body); }
      closeModal(); showToast('تم حفظ المستخدم'); await load(); render();
    }
  } catch (x) { showToast(x.message); }
});

Object.assign(VIEW_NAMES, { users: 'المستخدمون والإدارة' });
window.EXTRA_VIEWS = { ...(window.EXTRA_VIEWS || {}), users: renderUsers };
})();
