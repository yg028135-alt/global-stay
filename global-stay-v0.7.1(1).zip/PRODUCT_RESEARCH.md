# Product research: Nazeel feature categories

Reviewed the vendor's published feature page on 20 November 2026. It describes these PMS categories: advanced dashboard; reservations (list/unit/calendar views, OTA channel manager, group bookings/corporate accounts); receivables/payments (automated invoices/vouchers, credit/debit notes, multiple methods); housekeeping/task assignment/status updates; inventory levels and movement/low-stock alerts; role-based and multi-branch permissions; service outlets/POS with guest-folio charges; night audit; taxes/fees; activity log; and reporting with export/scheduling. These are vendor-published descriptions, not independent verification of implementation details.

The vendor's homepage also lists Shomoos, ZATCA, PayTabs and RateGain among integrations, plus a high-level integrated management/cloud/reporting/messaging narrative. Country-specific services should not be assumed appropriate for every Global Stay property.

This research informs independent product ideas in `FEATURE_ROADMAP.md` and the in-app roadmap. Global Stay does not copy Nazeel's source, screens, branding or proprietary design and is not integrated with or affiliated to Nazeel.

## Sources

- https://nazeel.net/visitor/system-features — official product feature categories.
- https://nazeel.net/ — official vendor/product overview and listed integrations.
