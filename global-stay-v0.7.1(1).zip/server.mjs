import { createServer } from 'node:http';
import { readFile, stat, readdir, unlink, writeFile } from 'node:fs/promises';
import { existsSync, mkdirSync, chmodSync } from 'node:fs';
import { extname, resolve, sep, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, makeTx } from './server/db.mjs';
import { hashPassword, verifyPassword, sha256, newToken, newId, randomPassword, makeLimiter } from './server/auth.mjs';
import { createEngine, HttpError, DEPTS, CATS } from './server/tickets.mjs';
import { seedTickets, DEMO_AGENTS } from './server/seed.mjs';
import { makeHotel } from './server/hotel.mjs';
import { makePush } from './server/push.mjs';
import { makeApartments } from './server/apartments.mjs';

const root = resolve(fileURLToPath(new URL('./public/', import.meta.url)));
const port = Number(process.env.PORT || 3000);
const dataDir = resolve(process.env.DATA_DIR || fileURLToPath(new URL('./data/', import.meta.url)));
const trustProxy = process.env.TRUST_PROXY === '1';
const SESSION_MS = 7 * 24 * 3600 * 1000;
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

const db = openDb(dataDir);
const tx = makeTx(db);
const now = () => new Date().toISOString();

/* ---------- البث اللحظي (SSE) والإشعارات ---------- */
const clients = new Map(); // userId -> Set(res)
const send = (res, type, data) => res.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`);
const emit = (type, data = {}) => { for (const set of clients.values()) for (const res of set) send(res, type, data); };
function notifyUser(userId, ticketId, kind, text) {
  const r = db.prepare('INSERT INTO notifications(user_id,ticket_id,kind,text,created_at) VALUES(?,?,?,?,?)').run(userId, ticketId, kind, text, now());
  for (const res of clients.get(userId) || []) send(res, 'notify', { id: Number(r.lastInsertRowid), ticketId, kind, text });
  if (typeof push !== 'undefined') push.sendTo(userId, { title: 'Global Stay', body: text, tag: `n-${r.lastInsertRowid}`, ticketId }).catch(() => {});
}
const engine = createEngine({ db, emit, notifyUser });
const hotel = makeHotel(db);
const apartments = makeApartments(db);
const push = makePush({ db, kvGet: engine.kvGet, kvSet: engine.kvSet, subject: process.env.VAPID_SUBJECT || 'mailto:admin@example.com' });
tx(() => { if (hotel.migrate(engine.kvGet, (k) => db.prepare('DELETE FROM kv WHERE key=?').run(k))) console.log('تم ترحيل بيانات الفندق إلى الجداول'); });
const audit = (userId, action, detail, ip) => db.prepare('INSERT INTO audit(at,user_id,action,detail,ip) VALUES(?,?,?,?,?)').run(now(), userId, action, detail || '', ip || '');

/* ---------- تهيئة أول تشغيل ---------- */
function bootstrapUsers() {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return;
  const lines = [];
  const add = (id, username, name, role, dept, pw) => {
    const { salt, hash } = hashPassword(pw);
    db.prepare('INSERT INTO users(id,username,name,role,dept,pass_salt,pass_hash,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id, username, name, role, dept, salt, hash, now());
    lines.push(`${username}\t${pw}\t${name} (${role}${dept ? '/' + dept : ''})`);
  };
  add('mgr_1', 'admin', 'مريم حسن', 'manager', null, process.env.ADMIN_PASSWORD || randomPassword());
  if (process.env.SEED_DEMO === '1') {
    const pw = process.env.DEMO_PASSWORD || randomPassword();
    for (const [id, u, name, dept] of DEMO_AGENTS) add(id, u, name, 'agent', dept, pw);
    seedTickets(engine, ['101', '102', '103', '104', '105', '201', '202', '203', '204', '205', '301', '302', '303', '304', '305', '401', '402', '403', '404', '405']);
  }
  const file = join(dataDir, 'initial-credentials.txt');
  writeFile(file, `# بيانات الدخول الأولية — احذف هذا الملف بعد حفظها وغيّر كلمات المرور\n${lines.join('\n')}\n`, { mode: 0o600 }).catch(() => {});
  console.log('\n=== تم إنشاء المستخدمين لأول مرة ===\n' + lines.join('\n') + `\n(محفوظة أيضًا في ${file})\n`);
}
tx(bootstrapUsers);

/* ---------- أدوات HTTP ---------- */
const json = (res, status, body, headers = {}) => { const s = JSON.stringify(body); res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers }); res.end(s); };
const clientIp = (req) => (trustProxy && req.headers['x-forwarded-for']?.split(',')[0].trim()) || req.socket.remoteAddress || '';
const isSecure = (req) => process.env.COOKIE_SECURE === '1' || (trustProxy && req.headers['x-forwarded-proto'] === 'https');
const cookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((c) => c.trim().split(/=(.*)/s)).filter((p) => p[0]).map((p) => [p[0], p[1]]));
const publicUser = (u) => ({ id: u.id, username: u.username, name: u.name, role: u.role, dept: u.dept, online: !!u.online, active: !!u.active });
const sessionCookie = (req, token, maxAge) => `gs_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${isSecure(req) ? '; Secure' : ''}`;
function readBody(req, limit = 1_000_000) {
  return new Promise((ok, fail) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > limit) { fail(new HttpError(413, 'الطلب أكبر من المسموح')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!size) return ok({}); try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); ok(v && typeof v === 'object' ? v : {}); } catch { fail(new HttpError(400, 'صيغة JSON غير صحيحة')); } });
    req.on('error', fail);
  });
}
function userFromReq(req) {
  const token = cookies(req).gs_session; if (!token) return null;
  const h = sha256(token);
  const row = db.prepare('SELECT s.expires_at, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND u.active=1').get(h);
  if (!row || row.expires_at < Date.now()) return null;
  if (row.expires_at - Date.now() < SESSION_MS / 2) db.prepare('UPDATE sessions SET expires_at=? WHERE token_hash=?').run(Date.now() + SESSION_MS, h);
  return row;
}

/* ---------- المسارات ---------- */
const routes = [];
const route = (method, path, auth, fn) => routes.push({ method, auth, fn, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') });
const loginLimiter = makeLimiter(6, 15 * 60 * 1000), publicLimiter = makeLimiter(5, 10 * 60 * 1000);
const dummy = hashPassword('dummy-password');
const hotelDoc = () => hotel.readAll();
const str = (v, max) => typeof v === 'string' ? v.trim().slice(0, max) : '';

route('GET', '/healthz', 'none', () => ({ ok: true }));

route('POST', '/api/login', 'none', ({ body, req, res, ip }) => {
  const username = str(body.username, 40).toLowerCase(), password = typeof body.password === 'string' ? body.password : '';
  const key = `${ip}|${username}`;
  if (loginLimiter.blocked(key)) throw new HttpError(429, 'محاولات كثيرة. حاول لاحقًا بعد بضع دقائق');
  const u = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(username);
  const ok = u ? verifyPassword(password, u.pass_salt, u.pass_hash) : (verifyPassword(password, dummy.salt, dummy.hash), false);
  if (!ok) { loginLimiter.hit(key); audit(u?.id || null, 'login_failed', username, ip); throw new HttpError(401, 'اسم المستخدم أو كلمة المرور غير صحيحة'); }
  loginLimiter.clear(key);
  const token = newToken();
  tx(() => {
    db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(sha256(token), u.id, Date.now() + SESSION_MS);
    if (u.role === 'agent') db.prepare('UPDATE users SET online=1 WHERE id=?').run(u.id);
    audit(u.id, 'login', '', ip);
  });
  if (u.role === 'agent') emit('change', {});
  res.setHeader('Set-Cookie', sessionCookie(req, token, SESSION_MS / 1000));
  return { user: publicUser({ ...u, online: u.role === 'agent' ? 1 : u.online }) };
});
route('POST', '/api/logout', 'user', ({ req, res, user, ip }) => {
  const t = cookies(req).gs_session;
  tx(() => { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha256(t)); if (user.role === 'agent') db.prepare('UPDATE users SET online=0 WHERE id=?').run(user.id); audit(user.id, 'logout', '', ip); });
  res.setHeader('Set-Cookie', sessionCookie(req, '', 0)); emit('change', {});
  return { ok: true };
});
route('GET', '/api/me', 'user', ({ user }) => ({ user: publicUser(user) }));
route('POST', '/api/me/password', 'user', ({ body, user, req, res, ip }) => {
  const cur = typeof body.current === 'string' ? body.current : '', next = typeof body.next === 'string' ? body.next : '';
  if (!verifyPassword(cur, user.pass_salt, user.pass_hash)) throw new HttpError(400, 'كلمة المرور الحالية غير صحيحة');
  if (next.length < 8) throw new HttpError(400, 'كلمة المرور الجديدة يجب ألا تقل عن 8 أحرف');
  const { salt, hash } = hashPassword(next), keep = sha256(cookies(req).gs_session);
  tx(() => { db.prepare('UPDATE users SET pass_salt=?,pass_hash=? WHERE id=?').run(salt, hash, user.id); db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash!=?').run(user.id, keep); audit(user.id, 'password_change', '', ip); });
  return { ok: true };
});

route('GET', '/api/bootstrap', 'user', ({ user }) => ({
  me: publicUser(user), now: Date.now(), hotel: hotelDoc(), tickets: engine.listFor(user), agents: engine.agents(), settings: engine.settings(),
  unread: db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND read=0').get(user.id).c
}));
route('GET', '/api/tickets', 'user', ({ user }) => ({ now: Date.now(), tickets: engine.listFor(user), agents: engine.agents() }));
route('POST', '/api/tickets', 'user', ({ body, user }) => ({ ticket: tx(() => engine.create(body, user)) }));
route('POST', '/api/tickets/:id/:op', 'user', ({ params, body, user }) => {
  const fn = engine.ops[params.op]; if (!fn || params.op === 'constructor') throw new HttpError(404, 'عملية غير معروفة');
  return { ticket: tx(() => fn(params.id, user, body)) };
});

route('GET', '/api/settings', 'user', () => ({ settings: engine.settings() }));
route('PUT', '/api/settings', 'manager', ({ body, user, ip }) => { const s = tx(() => { const r = engine.setSettings(body); audit(user.id, 'settings', JSON.stringify(r), ip); return r; }); return { settings: s }; });
route('GET', '/api/agents', 'user', () => ({ agents: engine.agents() }));
route('PUT', '/api/agents/:id/online', 'user', ({ params, body, user }) => {
  if (user.role !== 'manager' && user.id !== params.id) throw new HttpError(403, 'يمكنك تغيير حالتك أنت فقط');
  const a = db.prepare("SELECT * FROM users WHERE id=? AND role='agent' AND active=1").get(params.id); if (!a) throw new HttpError(404, 'الإيجينت غير موجود');
  const online = body.online ? 1 : 0;
  tx(() => {
    db.prepare('UPDATE users SET online=? WHERE id=?').run(online, a.id);
    if (!online) for (const r of db.prepare("SELECT id FROM tickets WHERE agent_id=? AND status='assigned'").all(a.id)) {
      const t = engine.load(r.id), n = engine.pickAgent(t.department, a.id);
      if (n) { engine.assign(t, n, `إعادة توجيه — ${a.name} أصبح غير متاح`); engine.store(t); }
    }
    engine.sweep();
  });
  emit('change', {});
  return { agents: engine.agents() };
});

route('GET', '/api/hotel', 'user', () => ({ hotel: hotelDoc() }));
route('PUT', '/api/hotel', 'user', ({ body, user }) => {
  if (user.role !== 'manager') {
    const allowed = ['operations','housekeeping','maintenance'].includes(user.dept) ? ['rooms','requests','tasks'] : user.dept === 'reception' ? ['rooms','requests'] : ['customer_service','guest_relations'].includes(user.dept) ? ['requests'] : [];
    for (const section of ['rooms','requests','tasks']) {
      if ((body?.upsert?.[section]?.length || 0) || (body?.remove?.[section]?.length || 0)) if (!allowed.includes(section)) throw new HttpError(403, 'لا تملك صلاحية تعديل هذا القسم');
    }
  }
  const n = tx(() => hotel.apply(body));
  if (n) emit('hotel', { by: user.id });
  return { ok: true, changed: n };
});
/* ---------- إدارة الشقق والحجوزات والحسابات ---------- */
route('GET', '/api/properties', 'user', () => ({ properties: apartments.properties() }));
route('POST', '/api/properties', 'manager', ({ body, user, ip }) => { const p = tx(() => apartments.createProperty(body)); audit(user.id, 'property_create', p.id, ip); return { property: p }; });
route('GET', '/api/units', 'user', ({ url }) => ({ units: apartments.units(url.searchParams.get('propertyId') || '') }));
route('POST', '/api/units', 'manager', ({ body, user, ip }) => { const u = tx(() => apartments.createUnit(body)); audit(user.id, 'unit_create', u.id, ip); return { unit: u }; });
route('GET', '/api/guests', 'user', ({ url, user }) => { const rows = apartments.guests(str(url.searchParams.get('q') || '', 100)); const contact = user.role === 'manager' || ['reception','accounting','guest_relations','customer_service'].includes(user.dept); const documents = user.role === 'manager' || user.dept === 'reception'; return { guests: rows.map(g => ({ ...g, ...(contact ? {} : { phone: undefined, email: undefined }), ...(documents ? {} : { document_type: undefined, document_last4: undefined }) })) }; });
route('POST', '/api/guests', 'user', ({ body, user, ip }) => { if (user.role !== 'manager' && !['reception','guest_relations','customer_service'].includes(user.dept)) throw new HttpError(403, 'لا تملك صلاحية إضافة نزيل'); const g = tx(() => apartments.createGuest(body)); audit(user.id, 'guest_create', g.id, ip); return { guest: g }; });
route('GET', '/api/reservations', 'user', ({ url, user }) => { const rows = apartments.listReservations({ from: url.searchParams.get('from') || '', to: url.searchParams.get('to') || '', unitId: url.searchParams.get('unitId') || '', status: url.searchParams.get('status') || '' }); if (user.role !== 'manager' && user.dept !== 'accounting') rows.forEach(r => { r.total = undefined; r.currency = undefined; }); if (user.role !== 'manager' && !['reception','accounting','guest_relations','customer_service'].includes(user.dept)) rows.forEach(r => { r.guestName = undefined; }); return { reservations: rows }; });
route('POST', '/api/reservations', 'user', ({ body, user, ip }) => { if (user.role !== 'manager' && user.dept !== 'reception') throw new HttpError(403, 'إنشاء الحجوزات متاح للاستقبال والإدارة فقط'); const r = tx(() => apartments.createReservation(body, user)); audit(user.id, 'reservation_create', r.id, ip); emit('change', {}); return { reservation: r }; });
route('GET', '/api/reservations/:id', 'user', ({ params, user }) => { const r = apartments.reservation(params.id); if (user.role !== 'manager' && !['reception','accounting'].includes(user.dept)) { r.guestPhone = undefined; r.entries = []; r.paid = undefined; r.balance = undefined; r.depositHeld = undefined; r.total = undefined; } else if (user.role !== 'manager' && user.dept !== 'accounting') { r.entries = []; r.paid = undefined; r.balance = undefined; r.depositHeld = undefined; } return { reservation: r }; });
route('POST', '/api/reservations/:id/update', 'user', ({ params, body, user, ip }) => { if (user.role !== 'manager' && user.dept !== 'reception') throw new HttpError(403, 'تعديل الحجوزات متاح للاستقبال والإدارة فقط'); const r = tx(() => apartments.updateReservation(params.id, body)); audit(user.id, 'reservation_update', `${params.id}/${JSON.stringify(body)}`, ip); emit('change', {}); return { reservation: r }; });
const financeAccess = user => user.role === 'manager' || user.dept === 'accounting';
route('GET', '/api/finance/summary', 'user', ({ url, user }) => { if (!financeAccess(user)) throw new HttpError(403, 'التقارير المالية متاحة للمحاسبة والإدارة فقط'); return { summary: apartments.financialSummary({ from: url.searchParams.get('from') || '', to: url.searchParams.get('to') || '' }) }; });
route('POST', '/api/expenses', 'user', ({ body, user, ip }) => { const e = tx(() => apartments.createExpense(body, user)); audit(user.id, 'expense_request', e.id, ip); return { expense: e }; });
route('GET', '/api/expenses', 'user', ({ url, user }) => { if (!financeAccess(user)) throw new HttpError(403, 'قائمة المصروفات متاحة للمحاسبة والإدارة فقط'); return { expenses: apartments.listExpenses({ status:url.searchParams.get('status')||'', from:url.searchParams.get('from')||'', to:url.searchParams.get('to')||'' }) }; });
route('POST', '/api/expenses/:id/review', 'user', ({ params, body, user, ip }) => { if (!financeAccess(user)) throw new HttpError(403, 'اعتماد المصروفات متاح للمحاسبة والإدارة فقط'); const e = tx(() => apartments.reviewExpense(params.id, body.decision, user)); audit(user.id, 'expense_review', `${params.id}/${body.decision}`, ip); return { expense: e }; });
route('POST', '/api/expenses/:id/pay', 'user', ({ params, user, ip }) => { if (!financeAccess(user)) throw new HttpError(403, 'صرف المصروفات متاح للمحاسبة والإدارة فقط'); const e = tx(() => apartments.payExpense(params.id, user)); audit(user.id, 'expense_paid', params.id, ip); return { expense: e }; });
route('GET', '/api/cash/preview', 'user', ({ url, user }) => { if (!financeAccess(user)) throw new HttpError(403, 'إغلاق الوردية متاح للمحاسبة والإدارة فقط'); return { preview: apartments.cashClosingPreview(user.id, url.searchParams.get('date') || new Date().toISOString().slice(0,10), url.searchParams.get('currency') || 'EGP') }; });
route('POST', '/api/cash/close', 'user', ({ body, user, ip }) => { if (!financeAccess(user)) throw new HttpError(403, 'إغلاق الوردية متاح للمحاسبة والإدارة فقط'); const closing = tx(() => apartments.createCashClosing(body, user)); audit(user.id, 'cash_close', `${closing.businessDate}/${closing.currency}/${closing.difference}`, ip); return { closing }; });
route('GET', '/api/cash/closings', 'user', ({ url, user }) => { if (!financeAccess(user)) throw new HttpError(403, 'سجل إغلاقات الوردية متاح للمحاسبة والإدارة فقط'); return { closings: apartments.listCashClosings({ from:url.searchParams.get('from')||'', to:url.searchParams.get('to')||'' }) }; });
route('GET', '/api/owners', 'user', ({ user }) => { if (!financeAccess(user)) throw new HttpError(403, 'بيانات الملاك متاحة للمحاسبة والإدارة فقط'); return { owners: apartments.listOwners() }; });
route('POST', '/api/owners', 'user', ({ body, user, ip }) => { if (user.role !== 'manager') throw new HttpError(403, 'إضافة الملاك متاحة للإدارة فقط'); const owner=tx(()=>apartments.createOwner(body)); audit(user.id,'owner_create',owner.id,ip); return { owner }; });
route('POST', '/api/property-owners', 'user', ({ body, user, ip }) => { if (user.role !== 'manager') throw new HttpError(403, 'توزيع الملكية متاح للإدارة فقط'); const link=tx(()=>apartments.assignOwner(body)); audit(user.id,'property_owner_assign',`${link.propertyId}/${link.ownerId}/${link.sharePercent}`,ip); return { assignment:link }; });
route('GET', '/api/owners/:id/statement', 'user', ({ params, url, user }) => { if (!financeAccess(user)) throw new HttpError(403, 'كشوف حساب الملاك متاحة للمحاسبة والإدارة فقط'); return { statement:apartments.ownerStatement(params.id,{from:url.searchParams.get('from')||'',to:url.searchParams.get('to')||'',propertyId:url.searchParams.get('propertyId')||''}) }; });
route('POST', '/api/owner-settlements', 'user', ({ body, user, ip }) => { if (!financeAccess(user)) throw new HttpError(403, 'صرف مستحقات الملاك متاح للمحاسبة والإدارة فقط'); const settlement=tx(()=>apartments.settleOwner(body,user)); audit(user.id,'owner_settlement',`${settlement.ownerId}/${settlement.amount}/${settlement.currency}`,ip); return { settlement }; });
route('GET', '/api/owner-settlements', 'user', ({ url, user }) => { if (!financeAccess(user)) throw new HttpError(403, 'سجل تسويات الملاك متاح للمحاسبة والإدارة فقط'); return { settlements:apartments.listOwnerSettlements({ownerId:url.searchParams.get('ownerId')||'',from:url.searchParams.get('from')||'',to:url.searchParams.get('to')||''}) }; });
route('POST', '/api/reservations/:id/documents', 'user', ({ params, body, user, ip }) => { if (user.role !== 'manager' && !['reception','accounting'].includes(user.dept)) throw new HttpError(403, 'إصدار مستندات الإقامة متاح للاستقبال والمحاسبة والإدارة فقط'); const document=tx(()=>apartments.reservationDocument(params.id,body.kind||'invoice',body.entryId||'',user)); audit(user.id,'reservation_document',`${params.id}/${document.documentNumber}`,ip); return { document }; });
route('POST', '/api/reservations/:id/entries', 'user', ({ params, body, user, ip }) => { if (user.role !== 'manager' && user.dept !== 'accounting') throw new HttpError(403, 'تسجيل الحركات المالية متاح للمحاسبة والإدارة فقط'); const r = tx(() => apartments.addEntry(params.id, body, user)); audit(user.id, 'folio_entry', `${params.id}/${body.type}/${body.amount}`, ip); return { reservation: r }; });
route('POST', '/api/reservations/:id/transfer', 'user', ({ params, body, user, ip }) => { if (user.role !== 'manager' && user.dept !== 'reception') throw new HttpError(403, 'نقل الإقامة متاح للاستقبال والإدارة فقط'); const result=tx(()=>apartments.transferReservation(params.id,body,user)); audit(user.id,'reservation_transfer',`${params.id}/${result.transferHistory.at(-1)?.fromUnitCode}/${result.transferHistory.at(-1)?.toUnitCode}`,ip); emit('change',{}); return result; });
route('GET', '/api/reservations/:id/transfers', 'user', ({ params, user }) => { if (user.role !== 'manager' && !['reception','accounting'].includes(user.dept)) throw new HttpError(403,'سجل نقل الإقامة غير متاح لهذا القسم'); return { transfers:apartments.transferHistory(params.id) }; });
route('GET', '/api/housekeeping/tasks', 'user', ({ url, user }) => { if(user.role!=='manager'&&!['housekeeping','operations','reception'].includes(user.dept)) throw new HttpError(403,'قائمة مهام النظافة غير متاحة لهذا القسم'); return { tasks:apartments.listHousekeepingTasks({status:url.searchParams.get('status')||'',propertyId:url.searchParams.get('propertyId')||''}) }; });
route('POST', '/api/housekeeping/tasks/:id/status', 'user', ({ params, body, user, ip }) => { if(user.role!=='manager'&&!['housekeeping','operations'].includes(user.dept)) throw new HttpError(403,'تحديث مهام النظافة متاح للتدبير الفندقي والعمليات فقط'); const task=tx(()=>apartments.updateHousekeepingTask(params.id,body.status,user)); audit(user.id,'housekeeping_task_status',`${params.id}/${body.status}`,ip); emit('change',{}); return { task }; });
route('GET', '/api/reports/property-units', 'user', ({ url, user }) => { if(!financeAccess(user)) throw new HttpError(403,'تقارير العقارات والوحدات متاحة للمحاسبة والإدارة فقط'); return { report:apartments.propertyUnitReport({from:url.searchParams.get('from'),to:url.searchParams.get('to'),propertyId:url.searchParams.get('propertyId')||''}) }; });
route('POST', '/api/reservations/:id/status', 'user', ({ params, body, user, ip }) => { if (user.role !== 'manager' && user.dept !== 'reception') throw new HttpError(403, 'تغيير حالة الإقامة متاح للاستقبال والإدارة فقط'); const r = tx(() => apartments.updateStatus(params.id, body.status)); audit(user.id, 'reservation_status', `${params.id}/${body.status}`, ip); emit('change', {}); return { reservation: r }; });

route('GET', '/api/push/key', 'user', () => ({ key: push.publicKey }));
route('POST', '/api/push/subscribe', 'user', ({ body, user }) => { if (!push.subscribe(user.id, body)) throw new HttpError(400, 'اشتراك الإشعارات غير صالح'); return { ok: true }; });
route('POST', '/api/push/unsubscribe', 'user', ({ body, user }) => { push.unsubscribe(user.id, body.endpoint); return { ok: true }; });

route('GET', '/api/notifications', 'user', ({ user }) => ({ items: db.prepare('SELECT id,ticket_id ticketId,kind,text,created_at createdAt,read FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50').all(user.id) }));
route('POST', '/api/notifications/read', 'user', ({ user }) => { db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(user.id); return { ok: true }; });

/* المستخدمون (للمدير فقط) */
const userRow = (id) => db.prepare('SELECT * FROM users WHERE id=?').get(id);
const validUser = (b, creating) => {
  const out = {};
  if (creating || b.name !== undefined) { out.name = str(b.name, 60); if (!out.name) throw new HttpError(400, 'الاسم مطلوب'); }
  if (creating) { out.username = str(b.username, 30).toLowerCase(); if (!/^[a-z0-9._-]{3,30}$/.test(out.username)) throw new HttpError(400, 'اسم المستخدم: 3–30 حرفًا إنجليزيًا أو أرقامًا'); }
  if (creating || b.role !== undefined) { out.role = b.role; if (!['manager', 'agent'].includes(out.role)) throw new HttpError(400, 'دور غير صالح'); }
  if (creating || b.dept !== undefined) { out.dept = b.dept || null; }
  if (b.password !== undefined && (typeof b.password !== 'string' || b.password.length < 8)) throw new HttpError(400, 'كلمة المرور يجب ألا تقل عن 8 أحرف');
  return out;
};
route('GET', '/api/users', 'manager', () => ({ users: db.prepare('SELECT * FROM users ORDER BY role,name').all().map(publicUser) }));
route('POST', '/api/users', 'manager', ({ body, user, ip }) => {
  const v = validUser(body, true); if (v.role === 'agent' && !DEPTS[v.dept]) throw new HttpError(400, 'القسم مطلوب للإيجينت'); if (v.role === 'manager') v.dept = null;
  if (typeof body.password !== 'string' || body.password.length < 8) throw new HttpError(400, 'كلمة المرور يجب ألا تقل عن 8 أحرف');
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(v.username)) throw new HttpError(409, 'اسم المستخدم مستخدم بالفعل');
  const id = newId(v.role === 'manager' ? 'mgr' : 'agent'), { salt, hash } = hashPassword(body.password);
  tx(() => { db.prepare('INSERT INTO users(id,username,name,role,dept,pass_salt,pass_hash,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id, v.username, v.name, v.role, v.dept, salt, hash, now()); audit(user.id, 'user_create', `${v.username}/${v.role}`, ip); });
  emit('change', {}); return { user: publicUser(userRow(id)) };
});
route('PATCH', '/api/users/:id', 'manager', ({ params, body, user, ip }) => {
  const u = userRow(params.id); if (!u) throw new HttpError(404, 'المستخدم غير موجود');
  const v = validUser(body, false);
  const role = v.role ?? u.role, dept = role === 'manager' ? null : (v.dept ?? u.dept), active = body.active === undefined ? u.active : (body.active ? 1 : 0);
  if (role === 'agent' && !DEPTS[dept]) throw new HttpError(400, 'القسم مطلوب للإيجينت');
  if (u.id === user.id && (role !== 'manager' || !active)) throw new HttpError(400, 'لا يمكنك إلغاء صلاحياتك أو تعطيل حسابك');
  tx(() => {
    db.prepare('UPDATE users SET name=?,role=?,dept=?,active=?,online=CASE WHEN ?=0 THEN 0 ELSE online END WHERE id=?').run(v.name ?? u.name, role, dept, active, active, u.id);
    if (body.password !== undefined) { const { salt, hash } = hashPassword(body.password); db.prepare('UPDATE users SET pass_salt=?,pass_hash=? WHERE id=?').run(salt, hash, u.id); db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id); }
    if (!active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
    if (u.role === 'agent' && (!active || role !== 'agent' || dept !== u.dept)) for (const r of db.prepare("SELECT id FROM tickets WHERE agent_id=? AND status='assigned'").all(u.id)) { const t = engine.load(r.id), n = engine.pickAgent(t.department, u.id); if (n) { engine.assign(t, n, `إعادة توجيه — تغيير بيانات ${u.name}`); engine.store(t); } }
    audit(user.id, 'user_update', `${u.username}: ${JSON.stringify({ ...v, password: body.password !== undefined ? '***' : undefined, active })}`, ip);
  });
  emit('change', {}); return { user: publicUser(userRow(u.id)) };
});
route('GET', '/api/audit', 'manager', () => ({ items: db.prepare('SELECT a.at, a.action, a.detail, a.ip, u.name FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100').all() }));

/* بوابة طلبات النزلاء (بدون تسجيل دخول) */
const GUEST_CATS = ['cleaning', 'maintenance', 'inquiry', 'complaint'];
route('POST', '/api/public/request', 'none', ({ body, ip }) => {
  if (body.website) return { ok: true }; // honeypot
  if (publicLimiter.blocked(ip)) throw new HttpError(429, 'تم إرسال طلبات كثيرة، حاول لاحقًا');
  const room = str(body.room, 8), name = str(body.name, 40), message = str(body.message, 250), category = body.category;
  if (!GUEST_CATS.includes(category)) throw new HttpError(400, 'نوع الطلب غير صالح');
  if (!message) throw new HttpError(400, 'اكتب تفاصيل الطلب');
  if (!/^[0-9A-Za-z-]{1,8}$/.test(room) || (hotel.roomCount() && !hotel.roomExists(room))) throw new HttpError(400, 'رقم الغرفة غير صحيح');
  publicLimiter.hit(ip);
  const t = tx(() => {
    const t = engine.create({ title: `${CATS[category][0]} — غرفة ${room}`, description: `${message}${name ? `\nالنزيل: ${name}` : ''}`, category, priority: category === 'complaint' ? 'high' : 'medium', room, source: 'guest' }, { id: null, name: 'نزيل (بوابة الطلبات)', role: 'guest' });
    db.prepare("SELECT id FROM users WHERE role='manager' AND active=1").all().forEach((m) => notifyUser(m.id, t.id, 'guest', `طلب نزيل جديد ${t.id} — غرفة ${room}`));
    return t;
  });
  return { ok: true, ticketId: t.id };
});

/* ---------- الخادم ---------- */
const CSP = "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; script-src 'self'; connect-src 'self'; manifest-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
const secHeaders = (req) => ({ 'Content-Security-Policy': CSP, 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin', ...(isSecure(req) ? { 'Strict-Transport-Security': 'max-age=31536000' } : {}) });

async function handleApi(req, res, url) {
  const ip = clientIp(req);
  const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
  if (!r) { if (url.pathname === '/api/events' && req.method === 'GET') return handleEvents(req, res); throw new HttpError(404, 'غير موجود'); }
  if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'gs') throw new HttpError(403, 'طلب غير مسموح');
  const user = userFromReq(req);
  if (r.auth !== 'none' && !user) throw new HttpError(401, 'يجب تسجيل الدخول');
  if (r.auth === 'manager' && user.role !== 'manager') throw new HttpError(403, 'هذه العملية للإدارة فقط');
  const params = r.re.exec(url.pathname).groups || {};
  const body = req.method === 'GET' ? {} : await readBody(req);
  const out = await r.fn({ req, res, url, params, body, user, ip });
  json(res, 200, out ?? { ok: true });
}
function handleEvents(req, res) {
  const user = userFromReq(req);
  if (!user) return json(res, 401, { error: 'يجب تسجيل الدخول' });
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.write('retry: 3000\n\n');
  if (!clients.has(user.id)) clients.set(user.id, new Set());
  clients.get(user.id).add(res);
  req.on('close', () => { const s = clients.get(user.id); s?.delete(res); if (s && !s.size) clients.delete(user.id); });
}
async function handleStatic(req, res, url) {
  const requested = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const file = resolve(root, `.${requested}`);
  if (file !== root && !file.startsWith(root + sep)) { res.writeHead(403).end('Forbidden'); return; }
  const info = await stat(file); if (!info.isFile()) throw new Error('Not a file');
  const body = await readFile(file);
  res.writeHead(200, { 'Content-Type': mime[extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store', ...secHeaders(req) });
  res.end(body);
}
createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://localhost');
    if (url.pathname === '/healthz' || url.pathname.startsWith('/api/')) {
      for (const [k, v] of Object.entries(secHeaders(req))) res.setHeader(k, v);
      return await handleApi(req, res, url);
    }
    await handleStatic(req, res, url);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof HttpError) return json(res, e.status, { error: e.message });
    if (req.url && req.url.startsWith('/api/')) { console.error(e); return json(res, 500, { error: 'خطأ في الخادم' }); }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }); res.end('Not found');
  }
}).listen(port, '0.0.0.0', () => console.log(`Global Stay listening on 0.0.0.0:${port}`));

/* ---------- مهام دورية ---------- */
setInterval(() => { try { tx(() => engine.sweep()); } catch (e) { console.error('sweep', e); } }, 10_000);
setInterval(() => { db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now()); loginLimiter.sweep(); publicLimiter.sweep(); }, 3600_000);
setInterval(() => { for (const set of clients.values()) for (const res of set) res.write(': ping\n\n'); }, 25_000);
async function backup() {
  try {
    const dir = join(dataDir, 'backups'); mkdirSync(dir, { recursive: true });
    const file = join(dir, `globalstay-${new Date().toISOString().slice(0, 10)}.db`);
    if (!existsSync(file)) db.exec(`VACUUM INTO '${file.replaceAll("'", "''")}'`);
    const old = (await readdir(dir)).filter((f) => f.endsWith('.db')).sort().slice(0, -7);
    for (const f of old) await unlink(join(dir, f));
  } catch (e) { console.error('backup', e); }
}
backup(); setInterval(backup, 6 * 3600_000);
process.on('SIGTERM', () => { db.close(); process.exit(0); });
