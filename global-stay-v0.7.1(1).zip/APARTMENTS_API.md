# Global Stay — Apartment PMS API (Phase 2)

This phase adds a normalized apartment-management data model while preserving the existing ticketing, hotel operations, SSE, Web Push, PWA and user-management modules.

## Roles and permissions

Existing `manager` users retain full access. Agent departments now include `reception`, `accounting`, `guest_relations`, `customer_service`, `housekeeping`, `maintenance` and `operations`.

- Managers: create properties/units; all PMS operations.
- Reception: create guests and reservations; check-in/check-out; read reservations.
- Accounting: record stay payments, deposits and refunds; read reservation folios.
- Guest Relations / Customer Service: create guest profiles; read reservation lists.
- Operations / Housekeeping / Maintenance: retain their scoped access to operational rooms, requests and tasks.

Full per-field privacy policies and granular permission administration are still planned; do not store full passport or identity numbers. The current guest profile stores only an optional document type and last four characters.

## Endpoints

All API requests except login/public request require the existing `X-Requested-With: gs` header and an authenticated session cookie.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET/POST | `/api/properties` | All / Manager | List or create a property |
| GET/POST | `/api/units` | All / Manager | List or create units; optional `?propertyId=` |
| GET/POST | `/api/guests` | All / Reception, Guest Relations, Customer Service, Manager | Search or create guest profiles |
| GET/POST | `/api/reservations` | All / Reception, Manager | List or create reservations |
| GET | `/api/reservations/:id` | All | Reservation details and folio |
| POST | `/api/reservations/:id/update` | Reception, Manager | Edit reservation dates, unit (except occupied stay transfer), guest, rate and commission; recalculates totals and checks conflicts |
| POST | `/api/reservations/:id/entries` | Accounting, Manager | Record a financial entry |
| GET | `/api/finance/summary` | Accounting, Manager | Finance summary grouped by currency; optional `?from=YYYY-MM-DD&to=YYYY-MM-DD` (to is exclusive) |
| POST | `/api/reservations/:id/status` | Reception, Manager | Change reservation status; checkout creates a housekeeping task automatically |
| POST | `/api/reservations/:id/transfer` | Reception, Manager | Transfer a checked-in guest to a ready unit; records from/to units and creates a cleaning task for the previous unit |
| GET | `/api/reservations/:id/transfers` | Reception, Accounting, Manager | Read transfer history |
| GET | `/api/housekeeping/tasks` | Housekeeping, Operations, Reception, Manager | List housekeeping tasks; optional `?status=&propertyId=` |
| POST | `/api/housekeeping/tasks/:id/status` | Housekeeping, Operations, Manager | Set task to `in_progress` or `done`; completing a task returns the unit to ready only if it is not occupied or under maintenance |
| GET | `/api/reports/property-units?from=&to=&propertyId=` | Accounting, Manager | Unit occupancy and reservation performance plus separate property-level paid expense totals; end date exclusive |
| POST | `/api/expenses` | Authenticated staff | Submit an expense request; optionally link a property |
| GET | `/api/expenses` | Accounting, Manager | List expenses; optional `?status=&from=&to=` |
| POST | `/api/expenses/:id/review` | Accounting, Manager | Approve or reject a pending expense (`{\"decision\":\"approved\"}`) |
| POST | `/api/expenses/:id/pay` | Accounting, Manager | Mark an approved expense as paid |
| GET | `/api/cash/preview` | Accounting, Manager | Preview cash movement for the current user/date/currency; accepts `?date=&currency=` |
| POST | `/api/cash/close` | Accounting, Manager | Save counted cash, expected cash and variance; one close per user/date/currency |
| GET | `/api/cash/closings` | Accounting, Manager | List saved cash closings; optional `?from=&to=` |

## Reservation calculation

- Dates are local calendar dates in `YYYY-MM-DD`; checkout is exclusive.
- Nights are calculated from checkout minus check-in.
- `subtotal = nightly rate × nights`.
- Default company commission is 10%; it is stored separately and added to the stay total.
- Currency is stored per reservation and every folio entry must use that same currency. Supported currencies: EGP, USD, EUR, SAR.
- A reservation conflict is rejected when an active reservation for the same unit overlaps the requested interval. Cancelled and checked-out reservations do not block new reservations.
- `stay_payment` reduces the outstanding stay balance. `stay_charge` and `adjustment` increase it. `deposit_received` and `deposit_refund` are tracked separately and do not reduce the stay balance.

## Example payloads

Create property:

```json
{"name":"Global Stay New Cairo","city":"New Cairo","country":"Egypt","timezone":"Africa/Cairo"}
```

Create unit:

```json
{"propertyId":"prop_...","code":"A-101","type":"apartment","bedrooms":2,"bathrooms":1,"capacity":4,"currency":"USD"}
```

Create reservation:

```json
{"unitId":"unit_...","guestId":"guest_...","checkIn":"2026-12-01","checkOut":"2026-12-05","nightlyRate":100,"currency":"USD","source":"direct","commissionRate":10}
```

Record payment:

```json
{"type":"stay_payment","amount":200,"currency":"USD","method":"instapay","reference":"TX-123"}
```

## Phase 2 interface and finance summary

- The PMS interface provides weekly and monthly availability views by unit. A booking card spans the nights from check-in through the day before checkout.
- Reception/Manager can edit pending, confirmed and checked-in reservations. The server revalidates the date range and unit availability and recalculates nights, subtotal, commission and total. A checked-in reservation cannot be moved to another unit until a dedicated transfer process exists.
- Reception/Manager can cancel pending or confirmed reservations. Cancellation retains the reservation and its ledger history.
- Reservation details expose the folio according to role permissions.
- `/api/finance/summary` groups ledger activity and created-booking totals by currency; it never adds different currencies together. Booking totals are grouped by reservation creation date; ledger activity is grouped by transaction creation date. Deposits are reported separately and are not treated as stay revenue.

## Phase 5 — Transfers, housekeeping and unit reports

- A checked-in reservation can be transferred to a different ready unit only. The server checks active reservation conflicts over the full stay period and updates the reservation's property/unit.
- Transfer history records the old unit, new unit, reason, user and timestamp. The old unit enters cleaning and gets a housekeeping task.
- Checkout also creates a housekeeping task automatically. Tasks move through `open`, `in_progress`, and `done`; only completion can return a cleaning unit to ready, and never if the unit is occupied or under maintenance.
- Housekeeping task responses omit guest name and contact details. Only housekeeping/operations/manager can update task status.
- Property/unit report calculates bookings, accommodation subtotal, company commission, overlapping occupied nights and occupancy percentage per currency. Dates are clipped to the selected interval. Reservation subtotal is the full booking subtotal for any reservation overlapping the report period; it is not prorated by nights.
- Property-level expenses are returned in a separate summary and are not duplicated across units or allocated without an approved allocation policy.
- The UI exports unit performance and property expense summaries as separate CSV files compatible with Excel.

## Remaining boundaries

Native XLSX export, owner statement PDF, secure expense attachments, external payment integrations, foreign-exchange conversion, guest-facing booking and external backup storage remain future work.


## Phase 3A — Expenses and cash closing

- Staff can submit an expense request. Approval/rejection and payment are separate, and the API rejects payment before approval.
- Expenses support EGP, USD, EUR and SAR and may be linked to a property. Financial reports group expense amounts by currency and status.
- Cash preview is scoped to the authenticated accounting user, date and currency. Cash receipts include cash stay payments and cash deposits; cash out includes cash deposit refunds and expenses marked paid in cash.
- Expected cash is compared with counted cash. The difference is stored as counted minus expected. A duplicate close for the same user/date/currency is rejected.
- Deposits remain separate from stay revenue. Cash closing is an operational reconciliation, not a bank reconciliation or tax report.


## Phase 3B — Owners, settlements and documents

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/owners` | Accounting, Manager | List owners |
| POST | `/api/owners` | Manager | Create owner (`fullName`, optional `phone`, `email`, `nationalIdLast4`, `notes`) |
| POST | `/api/property-owners` | Manager | Assign ownership (`propertyId`, `ownerId`, `sharePercent`); property total cannot exceed 100% |
| GET | `/api/owners/:id/statement?from=&to=&propertyId=` | Accounting, Manager | Owner statement, end date exclusive |
| POST | `/api/owner-settlements` | Accounting, Manager | Record an owner payment; amount is checked against outstanding entitlement |
| GET | `/api/owner-settlements?ownerId=&from=&to=` | Accounting, Manager | Settlement history |
| POST | `/api/reservations/:id/documents` with `{"kind":"invoice"}` | Reception, Accounting, Manager | Issue/retrieve a numbered invoice |
| POST | `/api/reservations/:id/documents` with `{"kind":"receipt","entryId":"folio_..."}` | Reception, Accounting, Manager | Issue/retrieve a receipt for a folio entry; omitted entryId selects latest eligible transaction |

Document numbers are sequential and persistent (`GS-INV-000001`, `GS-RCT-000001`). An invoice number is stable per reservation; each receipt is stable per folio entry. The interface uses a print-ready browser document; select “Save as PDF” in the print dialog.

Owner statement period policy: reservations are included by checkout date (`check_out >= from` and `< to`) unless cancelled; expenses are included by payment date and only after paid. Each currency is reported separately. For each property/currency, the owner's entitlement is their ownership percentage multiplied by accommodation subtotal less company commission and paid property expenses. Owner payments are deducted from outstanding entitlement and cannot exceed it. This calculation is an operational owner statement, not a tax or audited statement.
